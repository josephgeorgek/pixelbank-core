package com.example.agtstaffintent.domain;

import java.util.List;
import java.util.Map;

public record LlmIntentExtractionResult(
        String selectedIntent,
        Double confidence,
        String rationale,
        Map<String, Object> entities,
        List<ServiceCandidate> serviceCandidates,
        List<String> candidateIntents
) {
}
