package com.company.workforce.contracts.api;

import com.company.workforce.contracts.enums.ExecutionStatus;
import java.util.Map;

public record IntentExecutionResponse(
        String executionId,
        String intentId,
        ExecutionStatus status,
        String currentNode,
        Map<String, Object> finalOutput,
        Map<String, Object> metadata,
        String error
) {
}
