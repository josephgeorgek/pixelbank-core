package com.joseph.deepwiki.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "workspaces")
public class WorkspaceEntity {
    @Id public String id;
    @Column(length = 8000) public String repoUrls;
    public String branch;
    @Lob @Column(columnDefinition = "CLOB") public String summary;
    @Lob @Column(columnDefinition = "CLOB") public String overview;
    public Instant generatedAt;
    public Instant createdAt;
    public Instant updatedAt;
    @Lob @Column(columnDefinition = "CLOB") public String jsonPayload;
    public WorkspaceEntity() {}
}
