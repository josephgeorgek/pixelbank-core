package com.joseph.deepwiki.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "diagram_artifacts")
public class DiagramArtifactEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String wikiId;
    public String workspaceId;
    public String diagramType;
    @Lob @Column(columnDefinition = "CLOB") public String mermaidText;
    public String status;
    public String confidenceLevel;
    public int nodeCount;
    public int edgeCount;
    @Lob @Column(columnDefinition = "CLOB") public String evidenceSummary;
    @Lob @Column(columnDefinition = "CLOB") public String notes;
    public Instant generatedAt;
    public DiagramArtifactEntity() {}
}
