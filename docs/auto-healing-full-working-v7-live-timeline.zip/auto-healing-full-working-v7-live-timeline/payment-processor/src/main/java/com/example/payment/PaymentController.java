package com.example.payment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {
  private static final Logger log = LoggerFactory.getLogger(PaymentController.class);

  private final Map<String, Double> feeTable = new HashMap<>();
  private final RestClient healerClient;

  public PaymentController(@Value("${healer.agent.url}") String healerUrl) {
    feeTable.put("DOMESTIC", 0.02);
    feeTable.put("ACH", 0.01);
    this.healerClient = RestClient.builder().baseUrl(healerUrl).build();
  }

  @PostMapping("/process")
  public Map<String, Object> process(@RequestBody Map<String,Object> payload) {
    String type = String.valueOf(payload.get("type"));
    double amount = Double.parseDouble(String.valueOf(payload.get("amount")));
    Double feeRate = feeTable.get(type);

    if (feeRate == null) {
      String message = "threw exception [Request processing failed: java.lang.IllegalStateException: NullPointerException during fee calculation: missing fee mapping for " + type + "]";
      log.error(message);

      try {
        healerClient.post()
          .uri("/api/healing/ingest-error")
          .body(Map.of(
              "service", "payment-ms",
              "incidentId", "PAY-99283",
              "transactionType", type,
              "amount", amount,
              "error", message,
              "timestamp", LocalDateTime.now().toString()
          ))
          .retrieve()
          .toBodilessEntity();
      } catch (Exception notifyError) {
        log.warn("Unable to notify healer-agent: {}", notifyError.getMessage());
      }

      throw new IllegalStateException("NullPointerException during fee calculation: missing fee mapping for " + type);
    }

    double total = amount + (amount * feeRate) + (amount * 0.05);
    return Map.of("status","SUCCESS","type",type,"amount",amount,"feeRate",feeRate,"total",total,"timestamp", LocalDateTime.now().toString());
  }

  @GetMapping("/fees")
  public Map<String,Object> fees() {
    return Map.of("baseFeeTable", feeTable);
  }
}
