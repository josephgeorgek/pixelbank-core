package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentTaxonomy;
import com.example.agtstaffintent.domain.RankedIntent;
import com.example.agtstaffintent.util.TextNormalizer;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class IntentSimilarityService {

    private static final double MIN_SHORTLIST_SCORE = 0.45d;
    private static final int MIN_MATCHED_SIGNALS = 2;

    public List<RankedIntent> rank(String prompt, String userRole, List<IntentTaxonomy> taxonomies, int topK) {
        List<RankedIntent> ranked = taxonomies.stream()
                .map(taxonomy -> score(prompt, userRole, taxonomy))
                .sorted(Comparator.comparingDouble(RankedIntent::similarityScore).reversed())
                .limit(topK)
                .toList();

        return ranked.stream()
                .map(item -> new RankedIntent(
                        item.taxonomy(),
                        item.similarityScore(),
                        item.matchedSignals(),
                        item.rejectedSignals(),
                        isShortlisted(item)))
                .toList();
    }

    private RankedIntent score(String prompt, String userRole, IntentTaxonomy taxonomy) {
        String expandedPrompt = TextNormalizer.normalizeAndExpand(prompt);
        Set<String> promptTokens = TextNormalizer.tokens(expandedPrompt);
        Set<String> corpus = buildCorpus(taxonomy);

        double jaccard = jaccard(promptTokens, corpus);
        double keywordBoost = overlap(promptTokens, taxonomy.keywords()) * 0.20d;
        double synonymBoost = overlap(promptTokens, taxonomy.synonyms()) * 0.35d;
        double exampleBoost = overlap(promptTokens, taxonomy.examples()) * 0.15d;
        double personaBoost = matchesRole(userRole, taxonomy.persona()) ? 0.20d : -0.35d;
        double negativePenalty = overlap(promptTokens, taxonomy.negativeKeywords()) * -0.40d;
        double anchorBoost = overlap(promptTokens, taxonomy.requiredKeywordsAny()) * 0.30d;

        List<String> matchedSignals = new ArrayList<>();
        List<String> rejectedSignals = new ArrayList<>();

        nullSafe(taxonomy.keywords()).stream()
                .filter(keyword -> containsPhrase(expandedPrompt, keyword))
                .forEach(keyword -> matchedSignals.add("keyword:" + keyword));
        nullSafe(taxonomy.synonyms()).stream()
                .filter(synonym -> containsPhrase(expandedPrompt, synonym))
                .forEach(synonym -> matchedSignals.add("synonym:" + synonym));

        List<String> anchorMatches = nullSafe(taxonomy.requiredKeywordsAny()).stream()
                .filter(anchor -> containsPhrase(expandedPrompt, anchor))
                .toList();
        anchorMatches.forEach(anchor -> matchedSignals.add("anchor:" + anchor));

        if (matchesRole(userRole, taxonomy.persona())) {
            matchedSignals.add("persona:" + taxonomy.persona().toUpperCase(Locale.ROOT));
        } else {
            rejectedSignals.add("persona-mismatch:" + taxonomy.persona());
        }

        nullSafe(taxonomy.negativeKeywords()).stream()
                .filter(negative -> containsPhrase(expandedPrompt, negative))
                .forEach(negative -> rejectedSignals.add("negativeKeyword:" + negative));

        if (!nullSafe(taxonomy.requiredKeywordsAny()).isEmpty() && anchorMatches.isEmpty()) {
            rejectedSignals.add("missing-anchor:" + String.join("|", taxonomy.requiredKeywordsAny()));
        }

        double finalScore = Math.max(0.0d, jaccard + keywordBoost + synonymBoost + exampleBoost + personaBoost + negativePenalty + anchorBoost);
        return new RankedIntent(taxonomy, round(finalScore), distinct(matchedSignals), distinct(rejectedSignals), false);
    }

    private boolean isShortlisted(RankedIntent item) {
        return item.rejectedSignals().isEmpty()
                && item.similarityScore() >= MIN_SHORTLIST_SCORE
                && item.matchedSignals().size() >= MIN_MATCHED_SIGNALS;
    }

    private Set<String> buildCorpus(IntentTaxonomy taxonomy) {
        return Stream.of(
                        List.of(taxonomy.intent(), taxonomy.description(), taxonomy.persona()),
                        nullSafe(taxonomy.synonyms()),
                        nullSafe(taxonomy.keywords()),
                        nullSafe(taxonomy.examples()),
                        nullSafe(taxonomy.requiredKeywordsAny()))
                .flatMap(List::stream)
                .flatMap(value -> TextNormalizer.tokens(value).stream())
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private double overlap(Set<String> promptTokens, List<String> values) {
        long matches = nullSafe(values).stream()
                .filter(value -> containsPhrase(String.join(" ", promptTokens), value) || promptTokens.contains(TextNormalizer.normalize(value)))
                .count();
        return matches == 0 ? 0.0d : (double) matches / Math.max(1, values.size());
    }

    private boolean containsPhrase(String prompt, String phrase) {
        String normalizedPrompt = TextNormalizer.normalizeAndExpand(prompt);
        String normalizedPhrase = TextNormalizer.normalizeAndExpand(phrase);
        return !normalizedPhrase.isBlank() && normalizedPrompt.contains(normalizedPhrase);
    }

    private boolean matchesRole(String userRole, String persona) {
        String normalizedRole = userRole == null ? "" : userRole.trim().toUpperCase(Locale.ROOT);
        String normalizedPersona = persona == null ? "" : persona.trim().toUpperCase(Locale.ROOT);
        return "ANY".equals(normalizedPersona) || normalizedRole.equals(normalizedPersona);
    }

    private List<String> nullSafe(List<String> values) {
        return values == null ? List.of() : values;
    }

    private List<String> distinct(List<String> values) {
        return values.stream().distinct().toList();
    }

    private double jaccard(Set<String> left, Set<String> right) {
        if (left.isEmpty() || right.isEmpty()) {
            return 0.0d;
        }
        Set<String> intersection = new LinkedHashSet<>(left);
        intersection.retainAll(right);
        Set<String> union = new LinkedHashSet<>(left);
        union.addAll(right);
        return (double) intersection.size() / union.size();
    }

    private double round(double value) {
        return Math.round(value * 1000.0d) / 1000.0d;
    }
}
