package com.company.workforce.contracts.api;

import com.company.workforce.contracts.enums.TaskType;
import java.util.Map;

public record TaskExecutionRequest(
        String executionId,
        String intentId,
        String taskId,
        TaskType taskType,
        String targetService,
        String targetEndpoint,
        String method,
        Map<String, Object> input,
        Map<String, Object> metadata
) {
}
