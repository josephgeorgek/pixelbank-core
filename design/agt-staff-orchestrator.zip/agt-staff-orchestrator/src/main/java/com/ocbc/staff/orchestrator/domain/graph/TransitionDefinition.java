package com.ocbc.staff.orchestrator.domain.graph;

public record TransitionDefinition(
        String kind,
        String path,
        String operator,
        Object value,
        String next
) {
}
