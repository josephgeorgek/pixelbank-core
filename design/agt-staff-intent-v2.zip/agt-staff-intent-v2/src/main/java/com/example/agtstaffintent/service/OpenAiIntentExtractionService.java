package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentRequest;
import com.example.agtstaffintent.domain.LlmIntentExtractionResult;
import com.example.agtstaffintent.domain.RankedIntent;
import com.example.agtstaffintent.util.TextNormalizer;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class OpenAiIntentExtractionService {

    private static final Logger log = LoggerFactory.getLogger(OpenAiIntentExtractionService.class);
    private static final String UNKNOWN_INTENT = "UNKNOWN_OR_UNSUPPORTED_REQUEST";

    private final ChatClient chatClient;
    private final IntentPromptFactory promptFactory;
    private final ObjectMapper objectMapper;
    private final TaxonomyRepository taxonomyRepository;

    public OpenAiIntentExtractionService(ChatClient.Builder chatClientBuilder,
                                         IntentPromptFactory promptFactory,
                                         ObjectMapper objectMapper,
                                         TaxonomyRepository taxonomyRepository) {
        this.chatClient = chatClientBuilder.build();
        this.promptFactory = promptFactory;
        this.objectMapper = objectMapper;
        this.taxonomyRepository = taxonomyRepository;
    }

    public LlmIntentExtractionResult extract(IntentRequest request, List<RankedIntent> shortlisted) {
        try {
            String raw = chatClient.prompt()
                    .system(promptFactory.systemPrompt())
                    .user(promptFactory.userPrompt(request, shortlisted))
                    .call()
                    .content();
            LlmIntentExtractionResult result = objectMapper.readValue(raw, LlmIntentExtractionResult.class);
            if (result == null || result.selectedIntent() == null || result.selectedIntent().isBlank()) {
                return fallbackUnknown(request, shortlisted, "LLM returned empty selection");
            }
            return result;
        } catch (Exception ex) {
            log.warn("LLM extraction failed, falling back to deterministic selection. cause={}", ex.getMessage());
            return fallback(request, shortlisted, ex);
        }
    }

    private LlmIntentExtractionResult fallback(IntentRequest request, List<RankedIntent> shortlisted, Exception ex) {
        if (shortlisted.isEmpty() || UNKNOWN_INTENT.equals(shortlisted.getFirst().taxonomy().intent())) {
            return fallbackUnknown(request, shortlisted, "Fallback used because LLM call failed: " + ex.getClass().getSimpleName());
        }

        RankedIntent winner = shortlisted.getFirst();
        String normalizedPrompt = TextNormalizer.normalizeAndExpand(request.prompt());
        Map<String, Object> entities = new LinkedHashMap<>();
        entities.put("scope", normalizedPrompt.contains("all") ? "ALL" : normalizedPrompt.contains("my") ? "SELF" : null);
        entities.put("team", null);
        entities.put("leaveApplicationId", extractByRegex(request.prompt(), "(LA-[0-9]+)"));
        entities.put("decision", normalizedPrompt.contains("reject") ? "REJECTED"
                : normalizedPrompt.contains("approve") ? "APPROVED" : null);
        entities.put("status", normalizedPrompt.contains("pending") ? "PENDING" : normalizedPrompt.contains("status") ? "REQUESTED" : null);
        entities.put("certificateStatus", normalizedPrompt.contains("certificate pending") ? "PENDING" : null);
        entities.put("caseId", extractByRegex(request.prompt(), "([A-Z]{2,}-[0-9]+)"));
        entities.put("issueType", normalizedPrompt.contains("hip") ? "HIP" : normalizedPrompt.contains("ticket") ? "TICKET" : null);

        return new LlmIntentExtractionResult(
                winner.taxonomy().intent(),
                0.56d,
                "Fallback selection used because LLM call failed: " + ex.getClass().getSimpleName(),
                entities,
                winner.taxonomy().serviceCandidates(),
                shortlisted.stream().map(item -> item.taxonomy().intent()).toList()
        );
    }

    public LlmIntentExtractionResult fallbackUnknown(IntentRequest request, List<RankedIntent> shortlisted, String rationale) {
        var unknown = taxonomyRepository.requireByIntent(UNKNOWN_INTENT);
        String normalizedPrompt = TextNormalizer.normalizeAndExpand(request.prompt());
        Map<String, Object> entities = new LinkedHashMap<>();
        entities.put("scope", normalizedPrompt.contains("my") ? "SELF" : null);
        entities.put("team", null);
        entities.put("leaveApplicationId", null);
        entities.put("decision", null);
        entities.put("status", normalizedPrompt.contains("status") ? "UNKNOWN" : null);
        entities.put("certificateStatus", null);
        entities.put("caseId", extractByRegex(request.prompt(), "([A-Z]{2,}-[0-9]+)"));
        entities.put("issueType", normalizedPrompt.contains("hip") ? "HIP" : normalizedPrompt.contains("ticket") ? "TICKET" : null);

        return new LlmIntentExtractionResult(
                unknown.intent(),
                0.31d,
                rationale,
                entities,
                unknown.serviceCandidates(),
                shortlisted.stream().map(item -> item.taxonomy().intent()).toList()
        );
    }

    private String extractByRegex(String input, String regex) {
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(regex, java.util.regex.Pattern.CASE_INSENSITIVE).matcher(input);
        return matcher.find() ? matcher.group(1) : null;
    }
}
