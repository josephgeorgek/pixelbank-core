package com.ocbc.staff.mcp.leave.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ToolModels {
    public static class ToolExecuteRequest {
        @NotBlank
        private String toolName;
        private Map<String, Object> arguments = new LinkedHashMap<>();
        public String getToolName() { return toolName; }
        public void setToolName(String toolName) { this.toolName = toolName; }
        public Map<String, Object> getArguments() { return arguments; }
        public void setArguments(Map<String, Object> arguments) { this.arguments = arguments; }
    }

    public static class ToolExecuteResponse {
        private String serverName;
        private String toolName;
        private boolean success;
        private Object result;
        private String error;
        private Instant executedAt;
        public String getServerName() { return serverName; }
        public void setServerName(String serverName) { this.serverName = serverName; }
        public String getToolName() { return toolName; }
        public void setToolName(String toolName) { this.toolName = toolName; }
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public Object getResult() { return result; }
        public void setResult(Object result) { this.result = result; }
        public String getError() { return error; }
        public void setError(String error) { this.error = error; }
        public Instant getExecutedAt() { return executedAt; }
        public void setExecutedAt(Instant executedAt) { this.executedAt = executedAt; }
    }

    public static class ListPendingMedicalLeavesArgs {
        @NotBlank
        private String managerId;
        private String status = "PENDING";
        private boolean certificateRequired = true;
        private boolean fetchAll = true;
        private Integer maxRecords = 100;
        public String getManagerId() { return managerId; }
        public void setManagerId(String managerId) { this.managerId = managerId; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public boolean isCertificateRequired() { return certificateRequired; }
        public void setCertificateRequired(boolean certificateRequired) { this.certificateRequired = certificateRequired; }
        public boolean isFetchAll() { return fetchAll; }
        public void setFetchAll(boolean fetchAll) { this.fetchAll = fetchAll; }
        public Integer getMaxRecords() { return maxRecords; }
        public void setMaxRecords(Integer maxRecords) { this.maxRecords = maxRecords; }
    }

    public static class GetMedicalLeaveDocumentsArgs {
        @NotEmpty
        private List<String> leaveIds = new ArrayList<>();
        public List<String> getLeaveIds() { return leaveIds; }
        public void setLeaveIds(List<String> leaveIds) { this.leaveIds = leaveIds; }
    }

    public static class ApproveMedicalLeavesArgs {
        @NotBlank
        private String approverId;
        @NotEmpty
        private List<Map<String, Object>> leaveApplications = new ArrayList<>();
        private String approvalMode = "MATCH_TRUE_ONLY";
        public String getApproverId() { return approverId; }
        public void setApproverId(String approverId) { this.approverId = approverId; }
        public List<Map<String, Object>> getLeaveApplications() { return leaveApplications; }
        public void setLeaveApplications(List<Map<String, Object>> leaveApplications) { this.leaveApplications = leaveApplications; }
        public String getApprovalMode() { return approvalMode; }
        public void setApprovalMode(String approvalMode) { this.approvalMode = approvalMode; }
    }

    public static class ToolDescriptor {
        private String name;
        private String description;
        private Map<String, Object> inputSchema = new LinkedHashMap<>();
        public ToolDescriptor() {}
        public ToolDescriptor(String name, String description, Map<String, Object> inputSchema) {
            this.name = name;
            this.description = description;
            this.inputSchema = inputSchema;
        }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public Map<String, Object> getInputSchema() { return inputSchema; }
        public void setInputSchema(Map<String, Object> inputSchema) { this.inputSchema = inputSchema; }
    }
}
