package com.ocbc.staff.orchestrator.domain.runtime;

public enum NodeExecutionStatus {
    SUCCESS,
    FAILED
}
