package com.ocbc.agentic.mcp.workplace.tool;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;
import java.util.function.Function;

@Configuration
public class WorkplaceToolsConfig {

    @Bean("workplace.hotdesk.book")
    public Function<Map<String, Object>, Map<String, Object>> bookHotDeskTool() {
        return input -> Map.of(
                "bookingId", "HD-20260318-0001",
                "status", "BOOKED",
                "location", input.getOrDefault("location", "OCBC Changi"),
                "date", input.getOrDefault("date", "2026-03-18"),
                "timeSlot", input.getOrDefault("timeSlot", "MORNING"),
                "message", "Hot desk booked by MCP workplace tool"
        );
    }
}
