package com.example.healer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/healing")
public class HealerController {
  private static final Logger log = LoggerFactory.getLogger(HealerController.class);

  private final AiHealingPlanner aiPlanner;
  private final PlanValidator planValidator;
  private final McpGitHubClient gitHubClient;
  private final String repoUrl;

  private final HealingStatus status = new HealingStatus();

  private int stage = 0;
  private boolean prCreated = false;
  private long lastAdvanceMs = 0;

  public HealerController(AiHealingPlanner aiPlanner,
                          PlanValidator planValidator,
                          McpGitHubClient gitHubClient,
                          @Value("${repo.url}") String repoUrl) {
    this.aiPlanner = aiPlanner;
    this.planValidator = planValidator;
    this.gitHubClient = gitHubClient;
    this.repoUrl = repoUrl;
    trace("BOOT", "healer-agent started. repoUrl=" + repoUrl);
  }

  @PostMapping("/ingest-error")
  public Map<String,Object> ingestError(@RequestBody ErrorEvent event) {
    log.warn("[HEALER] Error ingested service={} txType={} error={}",
        event.service(), event.transactionType(), event.error());

    status.status = "INCIDENT_DETECTED";
    status.incidentId = event.incidentId() == null ? "INCIDENT-" + System.currentTimeMillis() : event.incidentId();
    status.title = "Runtime Fault";
    status.service = event.service() == null ? "Unknown-Service" : event.service();
    status.severity = "HIGH";
    status.affectedContainers = "3 of 12";
    status.error = event.error();
    status.transactionType = event.transactionType();
    status.actionRequired = "OPEN_INCIDENT";
    status.classification = null;
    status.branch = null;
    status.pullRequestUrl = null;
    status.aiRequestPrompt = null;
    status.aiResponseRaw = null;
    status.aiPlanJson = null;
    status.aiRationale = null;
    status.validationStatus = null;
    status.timeline.clear();
    status.trace.clear();

    trace("INGEST", "Incident received at " + LocalDateTime.now());
    trace("INPUT", "service=" + status.service + ", transactionType=" + status.transactionType + ", incidentId=" + status.incidentId);
    trace("ERROR", status.error);

    add("[DETECT] Runtime fault detected in " + status.service);
    add("[COLLECT_EVIDENCE] Error, payload summary, service context, and repo reference collected");

    stage = 1;
    prCreated = false;
    lastAdvanceMs = System.currentTimeMillis();

    return Map.of("status", "INGESTED", "incidentId", status.incidentId);
  }

  @GetMapping("/status")
  public HealingStatus getStatus() {
    autoAdvance();
    return status;
  }

  @PostMapping("/promote")
  public HealingStatus promote() {
    trace("PROMOTE", "Human promotion approved by Josh | Commander");
    add("[PROMOTE] PROD deployment approved by Josh | Commander");
    add("[RESTORE] Service restored. Promotion completed.");
    status.status = "RESTORED";
    status.severity = "NORMAL";
    status.affectedContainers = "0 of 12";
    status.actionRequired = "NONE";
    return status;
  }

  @PostMapping("/reset")
  public HealingStatus reset() {
    stage = 0;
    prCreated = false;
    lastAdvanceMs = 0;
    status.status = "HEALTHY";
    status.incidentId = null;
    status.title = null;
    status.service = "Payment-Service";
    status.severity = "NORMAL";
    status.classification = null;
    status.affectedContainers = "0 of 12";
    status.branch = null;
    status.pullRequestUrl = null;
    status.error = null;
    status.transactionType = null;
    status.actionRequired = "NONE";
    status.aiRequestPrompt = null;
    status.aiResponseRaw = null;
    status.aiPlanJson = null;
    status.aiRationale = null;
    status.validationStatus = null;
    status.timeline.clear();
    status.trace.clear();
    trace("RESET", "Healer state reset to HEALTHY");
    return status;
  }

  @PostMapping("/analyze")
  public String analyze(@RequestBody String error) {
    AiPlanResult result = aiPlanner.createPlan(error, repoUrl, "manual-test", "unknown");
    return result.responseJson();
  }

  private void autoAdvance() {
    if (stage == 0 || "RESTORED".equals(status.status)) return;

    long now = System.currentTimeMillis();
    if (now - lastAdvanceMs < 3500) return;
    lastAdvanceMs = now;

    switch (stage) {
      case 1 -> {
        status.status = "AI_ANALYZING";
        add("[AI_ANALYZE] Spring AI/OpenAI analyzing evidence using Auto-Healing SKILL.md");
        trace("AI_ANALYZE", "Calling AI planner with evidence and SKILL.md");
        AiPlanResult result = aiPlanner.createPlan(status.error, repoUrl, status.service, status.transactionType);
        status.aiRequestPrompt = result.requestPrompt();
        status.aiResponseRaw = result.responseJson();
        status.aiPlanJson = result.responseJson();
        status.aiRationale = result.rationale();
        trace("AI_RESPONSE_STORED", "AI response and rationale stored in /api/healing/status");
        stage = 2;
      }
      case 2 -> {
        status.status = "CLASSIFIED";
        status.classification = inferClassification(status.aiPlanJson);
        trace("CLASSIFY", status.classification);
        trace("ROOT_CAUSE", "Root cause details are available inside aiPlanJson");
        add("[CLASSIFY] " + status.classification);
        add("[ROOT_CAUSE] AI-generated root cause available in healing plan JSON");
        stage = 3;
      }
      case 3 -> {
        status.status = "PLAN_READY";
        trace("PLAN", "AI-generated healing plan prepared. Rationale=" + status.aiRationale);
        add("[PLAN] AI-generated healing plan prepared with patch proposal, rollback, and test plan");
        stage = 4;
      }
      case 4 -> {
        status.status = "VALIDATING_PLAN";
        var result = planValidator.validate(status.aiPlanJson);
        status.validationStatus = result.message();
        trace("VALIDATE_PLAN", result.message());
        add("[VALIDATE_PLAN] " + result.message());

        if (!result.passed()) {
          status.status = "ESCALATED";
          status.actionRequired = "MANUAL_REVIEW";
          trace("ESCALATE", "Plan failed guardrail validation");
          add("[ESCALATE] Plan failed guardrail validation. Human investigation required.");
          stage = 99;
        } else {
          stage = 5;
        }
      }
      case 5 -> {
        status.status = "CREATING_GITHUB_PR";
        trace("GITOPS", "Creating review PR through MCP GitHub Tool");
        add("[GITOPS] Creating review PR through MCP GitHub Tool");
        createGitHubPr();
        stage = 6;
      }
      case 6 -> {
        status.status = "AWAITING_PROD_APPROVAL";
        status.actionRequired = "PROMOTE_TO_PROD";
        trace("PR_CREATED", status.pullRequestUrl);
        add("[GITOPS] Hotfix branch created and PR opened for review");
        add("[PROMOTE] Awaiting PROD approval via GitHub PR");
        stage = 7;
      }
      default -> {}
    }
  }

  private void createGitHubPr() {
    if (prCreated) return;
    prCreated = true;

    Map result = gitHubClient.createReviewPr(status.incidentId, status.aiPlanJson);
    status.branch = String.valueOf(result.get("branch"));
    status.pullRequestUrl = String.valueOf(result.get("pullRequestUrl"));

    trace("GITHUB_RESULT", "branch=" + status.branch + ", pullRequestUrl=" + status.pullRequestUrl);
  }

  private String inferClassification(String json) {
    if (json == null || json.isBlank()) return "UNKNOWN_REQUIRES_INVESTIGATION";
    String upper = json.toUpperCase();

    String[] known = {
        "CONFIG_DEFAULT_GAP",
        "REFERENCE_DATA_GAP",
        "ENVIRONMENT_CONFIG_GAP",
        "DOWNSTREAM_UNAVAILABLE",
        "TIMEOUT_OR_RETRY_POLICY_GAP",
        "API_CONTRACT_MISMATCH",
        "DATABASE_SCHEMA_MISMATCH",
        "AUTHENTICATION_FAILURE",
        "AUTHORIZATION_FAILURE",
        "DEPLOYMENT_STARTUP_FAILURE",
        "RESOURCE_EXHAUSTION",
        "DATA_VALIDATION_GAP",
        "CODE_DEFECT_REQUIRES_DEV",
        "UNKNOWN_REQUIRES_INVESTIGATION"
    };

    for (String k : known) {
      if (upper.contains(k)) return k;
    }
    return "UNKNOWN_REQUIRES_INVESTIGATION";
  }

  private void add(String line) {
    if (!status.timeline.contains(line)) status.timeline.add(line);
  }

  private void trace(String stage, String message) {
    String line = "[" + stage + "] " + message;
    status.trace.add(line);
    HealerTraceLogger.step(stage, message);
  }
}
