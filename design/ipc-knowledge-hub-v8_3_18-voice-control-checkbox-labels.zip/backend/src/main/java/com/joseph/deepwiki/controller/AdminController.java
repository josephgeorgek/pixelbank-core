package com.joseph.deepwiki.controller;

import com.joseph.deepwiki.service.PersistenceService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {
    private final PersistenceService persistenceService;
    public AdminController(PersistenceService persistenceService) { this.persistenceService = persistenceService; }
    @GetMapping("/storage/stats")
    public Map<String, Object> stats() { return persistenceService.storageStats(); }
}
