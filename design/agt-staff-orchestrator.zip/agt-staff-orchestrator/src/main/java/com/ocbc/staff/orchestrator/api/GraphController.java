package com.ocbc.staff.orchestrator.api;

import com.ocbc.staff.orchestrator.domain.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.service.GraphRegistryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
public class GraphController {

    private final GraphRegistryService graphRegistryService;

    public GraphController(GraphRegistryService graphRegistryService) {
        this.graphRegistryService = graphRegistryService;
    }

    @GetMapping("/v1/graphs")
    public Collection<GraphDefinition> listGraphs() {
        return graphRegistryService.findAll();
    }
}
