import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowLeft, ArrowRight, BookOpen, Bot, Bookmark, Box, Braces, ChevronDown, ChevronRight, Clock, Code2, Compass, Database, ExternalLink, Eye, FileCode, FileText, Flag, GitBranch, Github, History, Home, Layers, Loader2, MessageSquare, Mic, Moon, MoreVertical, Network, Palette, Play, Radio, RefreshCw, Search, Settings, Share2, Shield, Sparkles, Star, Sun, Terminal, Users, Webhook, Zap } from 'lucide-react';
import mermaid from 'mermaid';
import { marked } from 'marked';
import { askWiki, getCapabilities, getRepoInsights, getWorkspaceJob, listWorkspaces, searchGitHubRepositories, searchWiki, startWorkspaceIndex } from './api/wikiApi';
import { useSpeechToText } from './hooks/useSpeechToText';
import './styles.css';

mermaid.initialize({ startOnLoad: false, theme: 'neutral', securityLevel: 'loose' });

const CACHE_PREFIX = 'ipc-knowledge-hub:v8_3_18:';
const RECENT_KEY = `${CACHE_PREFIX}recent-workspaces`;
const TTL = 1000 * 60 * 60 * 24 * 2;

const DOC_SECTIONS = [
  ['title', 'Title'],
  ['repo-about-overview', 'Overview'],
  ['ai-purpose-scope', 'Purpose, and Scope'],
  ['ai-dev2dev-info', 'Dev 2 Dev Info'],
  ['ai-architecture', 'Architecture'],
  ['security-aspects', 'Security Aspects'],
  ['code-insights', 'Code Insights'],
  ['design-elevation', 'Design Elevation'],
  ['roadmap-features-extension-options', 'Roadmap Features and Extension Options']
];

function normalizeUrls(input) {
  return (input || '')
    .split(/[,\n\r\t ]+/)
    .map(s => s.trim())
    .filter(Boolean)
    .filter(s => s.startsWith('https://'))
    .map(s => s.replace(/\/+$/, ''));
}

function cacheKey(repoInput, branch) {
  return `${CACHE_PREFIX}${normalizeUrls(repoInput).join('|').toLowerCase()}::${(branch || '').trim().toLowerCase()}`;
}

function saveWorkspace(repoInput, branch, workspace) {
  const key = cacheKey(repoInput, branch);
  const payload = { key, repoInput, branch: branch || '', workspace, savedAt: Date.now() };
  localStorage.setItem(key, JSON.stringify(payload));
  const recent = recentWorkspaces().filter(item => item.key !== key);
  recent.unshift({ key, repoInput, branch: branch || '', savedAt: payload.savedAt, title: workspace.repositories?.map(r => r.name).join(' + ') || 'Workspace' });
  localStorage.setItem(RECENT_KEY, JSON.stringify(recent.slice(0, 8)));
}

function getCached(repoInput, branch) {
  const raw = localStorage.getItem(cacheKey(repoInput, branch));
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (Date.now() - parsed.savedAt > TTL) return null;
    return parsed.workspace;
  } catch {
    return null;
  }
}

function recentWorkspaces() {
  try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); } catch { return []; }
}

function repoTitle(workspace) {
  const names = workspace?.repositories?.map(r => r.name).filter(Boolean) || [];
  if (names.length === 0) return 'Workspace';
  if (names.length === 1) return names[0];
  return 'Multi-repo Workspace';
}

function shortRepoList(workspace) {
  const names = workspace?.repositories?.map(r => r.name).filter(Boolean) || [];
  return names.length <= 2 ? names.join(' + ') : `${names.slice(0, 2).join(' + ')} +${names.length - 2}`;
}

function firstWiki(workspace) {
  return workspace?.wikis?.[0] || null;
}

function allChunks(workspace) {
  return (workspace?.wikis || []).flatMap(w => (w.chunks || []).map(c => ({ ...c, repoUrl: w.repoUrl, wikiId: w.id })));
}

function allFiles(workspace) {
  return (workspace?.wikis || []).flatMap(w => (w.files || []).map(f => ({ ...f, repoUrl: w.repoUrl, wikiId: w.id })));
}

function allSymbols(workspace) {
  return (workspace?.wikis || []).flatMap(w => (w.symbols || []).map(s => ({ ...s, repoUrl: w.repoUrl, wikiId: w.id })));
}

function sourceRefs(workspace, keywords = [], limit = 5) {
  const keys = keywords.map(k => k.toLowerCase());
  const chunks = allChunks(workspace);
  const scored = chunks.map(c => {
    const hay = `${c.path || ''} ${c.content || ''} ${(c.symbols || []).join(' ')}`.toLowerCase();
    const score = keys.reduce((acc, k) => acc + (hay.includes(k) ? 1 : 0), 0);
    return { ...c, score };
  }).sort((a, b) => b.score - a.score || (a.path || '').localeCompare(b.path || ''));
  return scored.filter(c => c.score > 0).slice(0, limit).length ? scored.filter(c => c.score > 0).slice(0, limit) : chunks.slice(0, limit);
}

function detectTechStack(workspace) {
  const files = allFiles(workspace);
  const paths = files.map(f => (f.path || '').toLowerCase());
  const languages = workspace?.combinedLanguageStats || workspace?.languageStats || {};
  const stack = { Frontend: [], Backend: [], Integration: [], Data: [], DevOps: [] };
  if (languages.JavaScript || languages.TypeScript || paths.some(p => p.includes('package.json'))) stack.Frontend.push('React / JavaScript / TypeScript');
  if (languages.Java || paths.some(p => p.includes('pom.xml') || p.includes('build.gradle'))) stack.Backend.push('Java / Spring Boot candidate');
  if (paths.some(p => p.includes('kafka') || p.includes('stream'))) stack.Integration.push('Kafka / event streaming candidate');
  if (paths.some(p => p.includes('openapi') || p.includes('swagger'))) stack.Integration.push('OpenAPI / Swagger');
  if (paths.some(p => p.includes('application.yml') || p.includes('application.properties'))) stack.Backend.push('Spring configuration');
  if (paths.some(p => p.includes('dockerfile') || p.includes('docker-compose'))) stack.DevOps.push('Docker / Compose');
  if (paths.some(p => p.includes('jenkins'))) stack.DevOps.push('Jenkins');
  if (paths.some(p => p.includes('postgres'))) stack.Data.push('PostgreSQL candidate');
  if (paths.some(p => p.includes('redis'))) stack.Data.push('Redis candidate');
  if (paths.some(p => p.includes('oracle'))) stack.Data.push('Oracle candidate');
  Object.keys(stack).forEach(k => { if (stack[k].length === 0) stack[k].push('Not detected'); });
  return stack;
}

function detectApis(workspace) {
  const symbols = allSymbols(workspace);
  const routeSymbols = symbols.filter(s => /mapping|route|endpoint|controller/i.test(`${s.kind || ''} ${s.symbol || ''}`));
  if (routeSymbols.length) return routeSymbols.slice(0, 12).map(s => ({ repo: repoName(s.repoUrl), endpoint: s.symbol, path: s.path }));
  const chunks = sourceRefs(workspace, ['@GetMapping', '@PostMapping', '@RequestMapping', 'openapi', 'swagger'], 12);
  return chunks.map(c => ({ repo: repoName(c.repoUrl), endpoint: evidenceLabel(c), path: c.path }));
}

function repoName(url) {
  try {
    const parts = new URL(url).pathname.replace(/^\/+|\/+$/g, '').split('/');
    return parts.length >= 2 ? `${parts[0]}/${parts[1].replace(/\.git$/, '')}` : url;
  } catch { return url || 'Repository'; }
}

function evidenceLabel(chunk) {
  const content = chunk.content || '';
  const match = content.match(/@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|RequestMapping)\s*(\([^\n]*\))?/);
  return match ? match[0].slice(0, 90) : `${chunk.path}:${chunk.startLine || 1}-${chunk.endLine || '?'}`;
}

function detectEntryPoints(workspace) {
  const chunks = allChunks(workspace);
  const entry = chunks.filter(c => /@SpringBootApplication|public static void main|createRoot\(|ReactDOM\.render|main\.(jsx|tsx|js|ts)|index\.(jsx|tsx|js|ts)|ENTRYPOINT|CMD/i.test(`${c.path || ''} ${c.content || ''}`));
  return entry.slice(0, 8);
}

function detectDomains(workspace) {
  const text = `${workspace?.summary || ''} ${workspace?.overview || ''} ${allFiles(workspace).map(f => f.path).join(' ')}`.toLowerCase();
  const candidates = [
    ['Customer', ['customer', 'profile', 'entitlement', 'notification']],
    ['Payments', ['payment', 'funds', 'transfer', 'approval', 'settlement', 'transaction']],
    ['Operations', ['audit', 'monitoring', 'exception', 'ops', 'logging']],
    ['Security', ['security', 'auth', 'jwt', 'oauth', 'permission']],
    ['Data', ['repository', 'entity', 'database', 'migration', 'schema']]
  ];
  return candidates
    .map(([domain, terms]) => ({ domain, features: terms.filter(t => text.includes(t)).map(capitalize) }))
    .filter(d => d.features.length > 0)
    .slice(0, 6);
}

function capitalize(s) { return String(s || '').replace(/^./, ch => ch.toUpperCase()); }

function cleanNavLabel(value) {
  let label = stripMarkdownLabel(value || '');
  label = label.replace(/^\[[ xX]\]\s*/, '').trim();
  label = label.split(/[:–—-]\s+/)[0].trim() || label;
  label = label.replace(/\.$/, '').trim();
  return label.length > 64 ? `${label.slice(0, 61)}...` : label;
}

function sanitizeMermaidLabel(value) {
  return String(value || '')
    .replace(/[\[\]{}()"'`]/g, '')
    .replace(/[:;]/g, '')
    .trim()
    .slice(0, 80) || 'Node';
}

function pumlToMermaid(source) {
  const lines = String(source || '').split(/\r?\n/);
  const out = ['flowchart TD'];
  let count = 0;
  const ids = new Map();
  const idFor = (label) => {
    const clean = sanitizeMermaidLabel(label);
    if (!ids.has(clean)) ids.set(clean, `N${ids.size + 1}`);
    return { id: ids.get(clean), label: clean };
  };
  const stripNode = (value) => String(value || '')
    .replace(/^\s*\[/, '')
    .replace(/\]\s*$/, '')
    .replace(/^"|"$/g, '')
    .trim();
  for (const line of lines) {
    let trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("'") || trimmed.startsWith('//')) continue;
    if (/^@startuml|^@enduml/i.test(trimmed)) continue;
    if (/^package\b/i.test(trimmed) || trimmed === '{' || trimmed === '}') continue;
    trimmed = trimmed.replace(/;$/, '').trim();

    const participant = trimmed.match(/^(participant|actor|boundary|control|entity|database|component|queue)\s+"?([^"\n]+)"?/i);
    if (participant) {
      const n = idFor(participant[2]);
      out.push(`  ${n.id}["${n.label}"]`);
      count++;
      continue;
    }

    const arrowMatch = trimmed.match(/^(.+?)\s*(-->|->|\.\.>|==>|--|\.\.)\s*(.+?)(?:\s*:\s*(.+))?$/);
    if (arrowMatch) {
      const left = stripNode(arrowMatch[1]);
      const right = stripNode(arrowMatch[3]);
      const label = arrowMatch[4] ? sanitizeMermaidLabel(arrowMatch[4]) : '';
      if (left && right) {
        const a = idFor(left);
        const b = idFor(right);
        const edge = label ? ` -->|${label}| ` : ' --> ';
        out.push(`  ${a.id}["${a.label}"]${edge}${b.id}["${b.label}"]`);
        count++;
      }
      continue;
    }

    const bracket = trimmed.match(/^\[([^\]]+)\]$/);
    if (bracket) {
      const n = idFor(bracket[1]);
      out.push(`  ${n.id}["${n.label}"]`);
      count++;
    }
  }
  return count ? out.join('\n') : '';
}

function normalizeDiagramSource(language, source) {
  const lang = String(language || '').toLowerCase();
  const text = String(source || '').trim();
  if (lang === 'mermaid') return { type: 'mermaid', chart: text };
  if (lang === 'puml' || lang === 'plantuml' || text.startsWith('@startuml')) {
    const converted = pumlToMermaid(text);
    return converted ? { type: 'mermaid', chart: converted } : { type: 'code', language: 'puml', code: text };
  }
  return { type: 'code', language: lang || 'text', code: text };
}

function Mermaid({ chart }) {
  const ref = useRef(null);
  const [zoom, setZoom] = useState(1);
  const [error, setError] = useState('');
  useEffect(() => {
    let mounted = true;
    async function render() {
      if (!chart || !ref.current) return;
      setError('');
      const id = `mermaid-${Math.random().toString(36).slice(2)}`;
      const { svg } = await mermaid.render(id, chart);
      if (mounted && ref.current) ref.current.innerHTML = svg;
    }
    render().catch((err) => {
      setError(err?.message || 'Mermaid render failed');
      if (ref.current) ref.current.textContent = chart || 'Diagram unavailable.';
    });
    return () => { mounted = false; };
  }, [chart]);
  return <div className="diagram-viewer">
    <div className="diagram-toolbar">
      <span>Interactive diagram</span>
      <button type="button" onClick={() => setZoom(z => Math.max(0.5, +(z - 0.1).toFixed(1)))}>-</button>
      <strong>{Math.round(zoom * 100)}%</strong>
      <button type="button" onClick={() => setZoom(z => Math.min(2.5, +(z + 0.1).toFixed(1)))}>+</button>
      <button type="button" onClick={() => setZoom(1)}>Reset</button>
    </div>
    {error && <div className="diagram-error">Mermaid could not render this diagram. Showing source text. {error}</div>}
    <div className="mermaid-scroll">
      <div className="mermaid-box" style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }} ref={ref} />
    </div>
  </div>;
}

function cleanDisplayMarkdown(value) {
  return String(value || '')
    .replace(/Business Analyst Notes/g, 'Business Capability')
    .replace(/New Developer Reading Path/g, 'New developer Hangout')
    .replace(/(^|\n)(#{1,6}\s*)?Light Tutorial for\s+/g, '$1$2Deep Dive into ');
}

function Markdown({ text }) {
  const parts = useMemo(() => {
    const value = cleanDisplayMarkdown(text);
    const out = [];
    const regex = /```([a-zA-Z0-9_-]*)\s*\n([\s\S]*?)```/g;
    let last = 0;
    let match;
    while ((match = regex.exec(value)) !== null) {
      if (match.index > last) out.push({ type: 'markdown', text: value.slice(last, match.index) });
      out.push(normalizeDiagramSource(match[1], match[2]));
      last = regex.lastIndex;
    }
    if (last < value.length) out.push({ type: 'markdown', text: value.slice(last) });
    return out.length ? out : [{ type: 'markdown', text: value }];
  }, [text]);
  return <div className="markdown">
    {parts.map((part, index) => {
      if (part.type === 'mermaid') return <div key={index}><Mermaid chart={part.chart} /></div>;
      if (part.type === 'code') return <pre key={index} className={`readable-code language-${part.language || 'text'}`}><code>{part.code}</code></pre>;
      return <div key={index} dangerouslySetInnerHTML={{ __html: marked.parse(part.text || '') }} />;
    })}
  </div>;
}

function StatusPill({ children, tone = 'neutral' }) { return <span className={`status-pill ${tone}`}>{children}</span>; }
function Stat({ label, value }) { return <div className="stat"><span>{label}</span><b>{value ?? '—'}</b></div>; }

function SourceAccordion({ title = 'Relevant source files', refs = [] }) {
  return <details className="source-accordion">
    <summary>{title}</summary>
    <div className="source-list">
      {refs.length === 0 && <span className="muted">No direct source evidence detected for this section.</span>}
      {refs.map((r, i) => <code key={`${r.path}-${i}`}>{r.path}:{r.startLine || 1}-{r.endLine || '?'}</code>)}
    </div>
  </details>;
}

function EvidenceTag({ refItem }) {
  if (!refItem) return null;
  return <span className="source-tag">{refItem.path}:{refItem.startLine || 1}-{refItem.endLine || '?'}</span>;
}

function DataTable({ headers, rows }) {
  return <div className="table-wrap"><table><thead><tr>{headers.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>)}</tbody></table></div>;
}

function plainText(markdown = '') {
  return String(markdown)
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[#>*_~\-|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}


function formatRepoAbout(insights) {
  if (!insights || insights.length === 0) return 'No repository overview returned.';
  return insights.map(item => {
    const about = item.about || {};
    const topics = Array.isArray(about.topics) && about.topics.length ? `\n\n**Topics:** ${about.topics.map(t => `\`${t}\``).join(', ')}` : '';
    const homepage = about.homepage ? `\n\n**Homepage:** ${about.homepage}` : '';
    const language = about.language ? `\n\n**Primary language:** ${about.language}` : '';
    return `### ${item.repo || item.repoUrl}\n\n${about.description || 'No About description returned from GitHub.'}${language}${topics}${homepage}`;
  }).join('\n\n');
}

function formatSecurityAspects(insights) {
  if (!insights || insights.length === 0) return 'No GitHub Security metadata was returned.';
  return insights.map(item => {
    const s = item.security || {};
    return `### ${item.repo || item.repoUrl}\n\n| Security Signal | Extracted Value |\n|---|---|\n| Community health | ${s.healthPercentage !== undefined && s.healthPercentage !== -1 ? `${s.healthPercentage}%` : 'Not reported'} |\n| Security policy | ${s.securityPolicy || 'Not detected'} |\n| Code of conduct | ${s.codeOfConduct || 'Not detected'} |\n| License | ${s.license || 'Not detected'} |\n| Contributing guide | ${s.contributing || 'Not detected'} |\n| Issue template | ${s.issueTemplate || 'Not detected'} |\n| Pull request template | ${s.pullRequestTemplate || 'Not detected'} |`;
  }).join('\n\n');
}

function formatPulse(insights) {
  if (!insights || insights.length === 0) return 'No Pulse metadata returned.';
  return insights.map(item => {
    const p = item.pulse || {};
    return `**${item.repo || item.repoUrl}**\n\n- Last 30 days commits: ${p.last30DaysCommits ?? 'Not available'}\n- Recent PRs sample: ${p.recentPullRequests ?? 'Not available'}\n- Recent issues/PRs sample: ${p.recentIssuesAndPRs ?? 'Not available'}\n- Note: ${p.summary || 'Pulse data not available.'}`;
  }).join('\n\n');
}

function formatPerformance(insights) {
  if (!insights || insights.length === 0) return 'No Actions performance metadata returned.';
  return insights.map(item => {
    const p = item.performance || {};
    return `**${item.repo || item.repoUrl}**\n\n- Workflow runs sampled: ${p.workflowRunsSample ?? 'Not available'}\n- Successful runs: ${p.successfulRuns ?? 'Not available'}\n- Failed/cancelled runs: ${p.failedOrCancelledRuns ?? 'Not available'}\n- In progress runs: ${p.inProgressRuns ?? 'Not available'}\n- Average run minutes: ${p.averageRunMinutes ?? 'Not available'}\n- Note: ${p.summary || 'Actions performance data not available.'}`;
  }).join('\n\n');
}

async function askAcrossWorkspace(workspace, prompt) {
  const wikis = (workspace?.wikis || []).slice(0, 3);
  if (wikis.length === 0) return 'No indexed wiki context is available for AI generation.';
  const context = `Workspace: ${(workspace.repositories || []).map(r => r.name).join(', ')}\nSummary: ${workspace.summary || ''}\nOverview: ${workspace.overview || ''}`;
  const answers = await Promise.all(wikis.map(async wiki => {
    const response = await askWiki({ wikiId: wiki.id, question: prompt, selectedContext: context });
    const citations = (response.citations || []).slice(0, 8).map(c => `- \`${c}\``).join('\n');
    return `### ${repoName(wiki.repoUrl)}\n\n${response.answer || 'No answer returned.'}${citations ? `\n\n#### Source references\n${citations}` : ''}`;
  }));
  return answers.join('\n\n---\n\n');
}

function useWorkspaceEnhancements(workspace) {
  const [insights, setInsights] = useState([]);

  useEffect(() => {
    let cancelled = false;
    async function loadInsights() {
      const repos = (workspace?.repoUrls || []).slice(0, 5);
      if (repos.length === 0) { setInsights([]); return; }
      const loaded = await Promise.all(repos.map(async repoUrl => {
        try { return await getRepoInsights(repoUrl); }
        catch (e) { return { repo: repoName(repoUrl), repoUrl, about: { description: 'GitHub metadata unavailable.' }, security: {}, pulse: {}, performance: {}, notes: [e.message] }; }
      }));
      if (!cancelled) setInsights(loaded);
    }
    loadInsights();
    return () => { cancelled = true; };
  }, [workspace?.id]);

  const generated = workspace?.aiGeneratedSections || {};
  const aiSections = {
    loading: false,
    purpose: generated.purposeAndScope || '',
    dev: generated.dev2DevInfo || '',
    architecture: generated.architecture || '',
    codeInsights: generated.codeInsights || '',
    designElevation: generated.designElevation || '',
    roadmapFeatures: generated.roadmapFeatures || '',
    error: workspace?.aiGeneratedSections ? '' : 'Documentation is not available for this workspace. Re-index with a valid configuration.'
  };

  return { insights, aiSections };
}

function AdditiveMainContentSections({ workspace, insights, aiSections }) {
  const names = workspace.repositories?.map(r => r.name).join(' + ') || 'Repository';
  const refsOverview = sourceRefs(workspace, ['readme', 'about', 'package', 'pom'], 6);
  const refsArch = sourceRefs(workspace, ['controller', 'service', 'repository', 'entity', 'model', 'openapi', 'swagger', 'component'], 8);
  return <>
    <Section id="repo-about-overview" title="Overview" refs={refsOverview}>
      <Markdown text={formatRepoAbout(insights)} />
    </Section>

    <Section id="ai-purpose-scope" title="Purpose, and Scope" refs={refsOverview}>
      {aiSections.loading ? <div className="empty-box">Preparing Purpose and Scope...</div> : <Markdown text={aiSections.purpose || aiSections.error || 'No Purpose and Scope available.'} />}
    </Section>

    <Section id="ai-dev2dev-info" title="Dev 2 Dev Info" refs={sourceRefs(workspace, ['pom.xml', 'package.json', 'dockerfile', 'application.yml', 'readme', 'env'], 8)}>
      {aiSections.loading ? <div className="empty-box">Preparing Dev 2 Dev Info...</div> : <Markdown text={aiSections.dev || aiSections.error || 'No Dev 2 Dev Info available.'} />}
    </Section>

    <Section id="ai-architecture" title="Architecture" refs={refsArch}>
      {aiSections.loading ? <div className="empty-box">Preparing Architecture...</div> : <Markdown text={aiSections.architecture || aiSections.error || 'No Architecture section available.'} />}
    </Section>

    <Section id="security-aspects" title="Security Aspects" refs={sourceRefs(workspace, ['security', 'auth', 'policy', 'permission', 'jwt', 'oauth'], 8)}>
      <Markdown text={formatSecurityAspects(insights)} />
    </Section>

    <Section id="code-insights" title="Code Insights" refs={sourceRefs(workspace, ['controller', 'service', 'repository', 'component', 'route', 'main', 'entity'], 10)}>
      {aiSections.loading ? <div className="empty-box">Preparing Code Insights...</div> : <Markdown text={aiSections.codeInsights || aiSections.error || 'No Code Insights available.'} />}
    </Section>

    <Section id="design-elevation" title="Design Elevation" refs={sourceRefs(workspace, ['pattern', 'factory', 'adapter', 'repository', 'service', 'controller', 'smell', 'todo'], 10)}>
      {aiSections.loading ? <div className="empty-box">Preparing Design Elevation...</div> : <Markdown text={aiSections.designElevation || aiSections.error || 'No Design Elevation available.'} />}
    </Section>

    <Section id="roadmap-features-extension-options" title="Roadmap Features and Extension Options" refs={sourceRefs(workspace, ['roadmap', 'feature', 'extension', 'integration', 'api', 'consumer', 'client'], 10)}>
      {aiSections.loading ? <div className="empty-box">Preparing Roadmap Features and Extension Options...</div> : <Markdown text={aiSections.roadmapFeatures || aiSections.error || 'No Roadmap Features and Extension Options available.'} />}
    </Section>
  </>;
}

function GitHubContextTopCards({ insights }) {
  return <>
    <div className="context-card priority-card">
      <h3>What's happening</h3>
      <Markdown text={formatPulse(insights)} />
    </div>
    <div className="context-card priority-card">
      <h3>Actions Performance</h3>
      <Markdown text={formatPerformance(insights)} />
    </div>
  </>;
}

function Landing({ repoInput, setRepoInput, branch, setBranch, accessToken, setAccessToken, onIndex, onIndexRepoInput, loading, capabilities, recent, onUseRecent, indexedWorkspaces, onOpenIndexedWorkspace, indexedLoading }) {
  const [searchQuery, setSearchQuery] = useState('microservices demo');
  const [searchResults, setSearchResults] = useState([]);
  const [selectedRepos, setSelectedRepos] = useState(new Set());
  const [searching, setSearching] = useState(false);
  const [searchMessage, setSearchMessage] = useState('');

  async function runGitHubSearch(e) {
    e?.preventDefault?.();
    setSearchMessage('');
    setSearching(true);
    try {
      const data = await searchGitHubRepositories(searchQuery);
      setSearchResults(data.results || []);
      setSelectedRepos(new Set());
      if (data.message) setSearchMessage(data.message);
      if (!data.results?.length && !data.message) setSearchMessage('No repositories found. Try another search term.');
    } catch (err) {
      setSearchMessage(err.message || 'GitHub search failed.');
    } finally {
      setSearching(false);
    }
  }

  function toggleRepo(url) {
    setSelectedRepos(prev => {
      const next = new Set(prev);
      if (next.has(url)) next.delete(url); else next.add(url);
      return next;
    });
  }

  function indexSelectedRepos() {
    const urls = Array.from(selectedRepos);
    if (!urls.length) {
      setSearchMessage('Select at least one repository from the search results.');
      return;
    }
    const joined = urls.join('\n');
    setRepoInput(joined);
    onIndexRepoInput(joined);
  }

  return <main className="app-shell landing-search-shell">
    <header className="landing-header premium-header">
      <div className="brand premium-brand"><span className="brand-mark"><Database size={19}/></span><span>Live Docs Knowledge Hub</span><em>v8.3.18</em></div>
      <StatusPill tone={capabilities?.llmConfigured ? 'success' : 'neutral'}><span className="online-dot" />{capabilities?.llmConfigured ? 'OpenAI ChatClient Online' : 'Static mode'}</StatusPill>
    </header>

    <section className="landing-hero premium-hero">
      <h1>Let&apos;s re-learn from the golden source</h1>
      <p>Discover VCS- Code repositories, index documentation, and generate evidence-gated diagrams in seconds.</p>
    </section>

    <section className="landing-console">
      <div className="console-tabs" aria-label="Repository input mode">
        <button type="button" className="console-tab active"><Search size={22}/>Search GitHub</button>
        <button type="button" className="console-tab"><Github size={20}/>Paste URL directly</button>
      </div>

      <form onSubmit={runGitHubSearch} className="github-search-panel premium-search-form">
        <div className="github-search-row premium-search-row">
          <Search size={25}/>
          <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search for repositories (e.g. 'microservices demo')..." />
          <button disabled={searching}>{searching ? <Loader2 className="spin" size={16}/> : null} Search</button>
        </div>
        <div className="github-search-note"><Terminal size={14}/> Uses GitHub REST search. Limits results to top 3 relevant repositories.</div>
        {searchMessage && <div className="search-inline-message">{searchMessage}</div>}
      </form>

      {searchResults.length > 0 && <section className="github-results premium-results">
        <div className="github-results-head"><strong>{searchResults.length} results</strong><span>Select repositories to index</span></div>
        {searchResults.map((repo, index) => {
          const repoSelectWords = ['one', 'two', 'three'];
          const repoSelectWord = repoSelectWords[index] || String(index + 1);
          const repoCheckboxId = `repo-${repoSelectWord}`;
          return <div className={`github-result-card ${selectedRepos.has(repo.htmlUrl) ? 'selected' : ''}`} key={repo.fullName}>
            <div className="repo-select-control">
              <input id={repoCheckboxId} type="checkbox" checked={selectedRepos.has(repo.htmlUrl)} onChange={() => toggleRepo(repo.htmlUrl)} />
              <label htmlFor={repoCheckboxId}>Select {repoSelectWord}</label>
            </div>
            <div className="repo-result-body">
              <div className="repo-result-title"><strong>{repo.fullName}</strong><span className="star-pill"><Star size={14}/>{compactNumber(repo.stars)}</span></div>
              <p>{repo.description || 'No description returned from GitHub.'}</p>
              <div className="repo-result-tags">
                {(repo.topics || []).slice(0, 5).map(topic => <span key={topic}>{topic}</span>)}
              </div>
              <div className="repo-result-meta"><span>{repo.language || 'Language not reported'}</span><span>{repo.forks} forks</span><span>{formatUpdated(repo.updatedAt)}</span></div>
            </div>
          </div>;
        })}
        <button className="index-selected-button" onClick={indexSelectedRepos} disabled={loading || selectedRepos.size === 0}><ArrowRight size={16}/> Index selected repositories</button>
      </section>}

      <div className="direct-input-card">
        <div className="direct-input-title"><Github size={16}/><span>Paste GitHub URL(s) directly</span></div>
        <form onSubmit={onIndex} className="command-card premium-command-card">
          <textarea value={repoInput} onChange={e => setRepoInput(e.target.value)} placeholder="https://github.com/org/repo-a&#10;https://github.com/org/repo-b" />
          <div className="form-row premium-form-row">
            <input value={branch} onChange={e => setBranch(e.target.value)} placeholder="Branch: leave blank for default" />
            <input value={accessToken} onChange={e => setAccessToken(e.target.value)} type="password" placeholder="GitHub PAT optional for private clone" />
            <button disabled={loading}>{loading ? <Loader2 className="spin" size={18}/> : <ArrowRight size={18}/>} Index</button>
          </div>
        </form>
      </div>

      <div className="console-mini-tabs"><span className="active">RECENT CARDS</span><span>DIRECT URL</span><span><MessageSquare size={15}/>ASK MASTER SHIFU</span></div>
    </section>

    <section className="workspace-card-section premium-workspaces">
      <div className="workspace-card-header premium-workspace-head">
        <div>
          <h2>Indexed workspaces</h2>
          <p>Reopen persisted workspaces from the backend.</p>
        </div>
        <button className="view-all-link" type="button">View all <ChevronRight size={18}/></button>
      </div>
      {indexedLoading && <div className="indexed-loading-row"><StatusPill><Loader2 className="spin" size={14}/> Loading</StatusPill></div>}
      {indexedWorkspaces.length > 0 ? <div className="workspace-card-grid premium-workspace-grid">
        {indexedWorkspaces.map(ws => <button key={ws.id} onClick={() => onOpenIndexedWorkspace(ws)} className="indexed-workspace-card premium-indexed-card">
          <div className="workspace-icon"><Github size={21}/></div>
          <div className="workspace-status ready"><span />READY</div>
          <MoreVertical className="workspace-more" size={18}/>
          <strong>{repoTitle(ws)}</strong>
          <p>{shortRepoList(ws)}</p>
          <div className="indexed-card-meta"><span>{Object.keys(ws.combinedLanguageStats || ws.languageStats || {}).slice(0, 3).join(' · ') || 'Languages pending'}</span><span>{ws.repositories?.length || 0} repo{(ws.repositories?.length || 0) === 1 ? '' : 's'}</span></div>
        </button>)}
      </div> : <div className="empty-indexed-card">No backend-indexed workspaces yet. Search or paste a repo above to create the first one.</div>}
    </section>

    {recent.length > 0 && <section className="workspace-card-section compact-section premium-recent-section">
      <div className="workspace-card-header"><div><h2>Recent browser workspaces</h2><p>Local cache from this browser, valid for two days.</p></div></div>
      <div className="recent-grid">
        {recent.map(item => <button key={item.key} onClick={() => onUseRecent(item)} className="recent-card"><b>{item.title}</b><span>{new Date(item.savedAt).toLocaleString()}</span></button>)}
      </div>
    </section>}
  </main>;
}

function compactNumber(value) {
  const n = Number(value || 0);
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}m`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

function formatUpdated(value) {
  if (!value) return 'Updated date unavailable';
  try { return `Updated ${new Date(value).toLocaleDateString()}`; } catch { return value; }
}

function GlobalHeader({ workspace, onBack, onRefresh, onAskClick, theme, setTheme }) {
  const synced = 'Synced';
  return <header className="global-header app-topbar">
    <div className="product-mark" onClick={onBack} title="New workspace"><Layers size={20}/></div>
    <div className="topbar-title">Live Docs Knowledge Hub</div>
    <span className="topbar-divider" />
    <div className="topbar-version">v8.3.18</div>
    <div className="sync-pill"><span className="sync-dot" />{synced}</div>
    <div className="topbar-search"><Search size={18}/><input readOnly placeholder="Search documentation, components, APIs..."/><kbd>⌘ K</kbd></div>
    <button className="icon-action quiet" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} title="Theme">{theme === 'dark' ? <Sun size={18}/> : <Moon size={18}/>}</button>
    <button className="ask-button" onClick={onAskClick}><Sparkles size={16}/> Ask Master Shifu</button>
  </header>;
}


function stripMarkdownLabel(line) {
  return String(line || '')
    .replace(/^[-*\d.\s]+/, '')
    .replace(/[`*_#]/g, '')
    .trim();
}

function sectionLines(markdown, headingNames = []) {
  const lines = String(markdown || '').split(/\r?\n/);
  const names = headingNames.map(h => h.toLowerCase());
  let capture = false;
  const out = [];
  for (const line of lines) {
    const heading = line.match(/^#{1,4}\s+(.+)$/);
    if (heading) {
      const h = heading[1].replace(/[:`*_]/g, '').trim().toLowerCase();
      capture = names.some(n => h.includes(n));
      continue;
    }
    if (capture) out.push(line);
  }
  return out;
}

function extractBullets(markdown, headingNames = [], limit = 12) {
  const lines = sectionLines(markdown, headingNames);
  const source = lines.length ? lines : String(markdown || '').split(/\r?\n/);
  return source
    .filter(line => /^\s*[-*]\s+|^\s*\d+[.)]\s+/.test(line))
    .map(stripMarkdownLabel)
    .filter(Boolean)
    .slice(0, limit);
}

function extractFeaturesFromPurpose(workspace) {
  const text = workspace?.aiGeneratedSections?.purposeAndScope || '';
  const bullets = extractBullets(text, ['list of features', 'features'], 14);
  return bullets.length ? bullets : ['Re-index after Purpose and Scope generation to populate features'];
}

function extractApisFromArchitecture(workspace) {
  const text = workspace?.aiGeneratedSections?.architecture || '';
  const bullets = extractBullets(text, ['apis exposed', 'api exposed', 'endpoints'], 14);
  return bullets.length ? bullets : ['No API list extracted from Architecture section'];
}

function extractTechFromDevInfo(workspace) {
  const text = workspace?.aiGeneratedSections?.dev2DevInfo || '';
  const sectionBullets = extractBullets(text, [
    'tech stack', 'technology stack', 'technologies used', 'frameworks', 'libraries', 'backend', 'frontend', 'database', 'data', 'integration', 'devops', 'tools'
  ], 24);

  const candidates = [];
  const add = (value) => {
    const label = cleanNavLabel(value);
    if (label && !/^no tech stack extracted/i.test(label) && !candidates.some(v => v.toLowerCase() === label.toLowerCase())) candidates.push(label);
  };
  sectionBullets.forEach(add);

  const knownTech = [
    'Java 21', 'Java', 'Spring Boot', 'Spring Security', 'Spring Data JPA', 'Spring AI', 'Maven', 'Gradle',
    'Kafka', 'RabbitMQ', 'MQ', 'REST API', 'OpenAPI', 'Swagger', 'GraphQL', 'gRPC',
    'React', 'Vite', 'TypeScript', 'JavaScript', 'Angular', 'Vue', 'MUI', 'Tailwind',
    'PostgreSQL', 'MySQL', 'Oracle', 'MongoDB', 'Redis', 'H2', 'Elasticsearch',
    'Docker', 'Docker Compose', 'Kubernetes', 'OpenShift', 'Jenkins', 'GitHub Actions', 'Nginx'
  ];
  const hay = `${text}\n${allFiles(workspace).map(f => f.path).join('\n')}\n${JSON.stringify(workspace?.combinedLanguageStats || {})}`.toLowerCase();
  knownTech.forEach(tech => {
    const normalized = tech.toLowerCase();
    if (hay.includes(normalized)) add(tech);
  });

  // Additional filename-based fallback for common stacks.
  const paths = allFiles(workspace).map(f => (f.path || '').toLowerCase());
  if (paths.some(p => p.endsWith('pom.xml'))) add('Maven');
  if (paths.some(p => p.endsWith('build.gradle') || p.endsWith('build.gradle.kts'))) add('Gradle');
  if (paths.some(p => p.endsWith('package.json'))) add('Node.js / JavaScript');
  if (paths.some(p => p.includes('dockerfile') || p.includes('docker-compose'))) add('Docker');
  if (paths.some(p => p.includes('application.yml') || p.includes('application.properties'))) add('Spring configuration');

  return candidates.length ? candidates.slice(0, 14) : ['Tech stack not detected yet'];
}

function TreeGroup({ title, children, defaultOpen = true }) {
  return <details className="tree-group" open={defaultOpen}>
    <summary><ChevronDown size={14}/>{title}</summary>
    <div className="tree-content">{children}</div>
  </details>;
}

function NavItem({ icon, href, children, active = false }) {
  return <a className={`nav-item ${active ? 'active' : ''}`} href={href}>{icon}<span>{children}</span></a>;
}

function SidebarGroup({ title, children }) {
  return <div className="sidebar-group"><div className="sidebar-group-title">{title}</div><div className="sidebar-group-items">{children}</div></div>;
}

function LeftSidebar({ workspace }) {
  const features = extractFeaturesFromPurpose(workspace);
  const apis = extractApisFromArchitecture(workspace);
  const techStack = extractTechFromDevInfo(workspace);
  const entries = detectEntryPoints(workspace);
  return <aside className="left-sidebar" aria-label="Knowledge map navigation">
    <nav className="side-nav-top">
      <NavItem href="#title" icon={<Home size={16}/>} active>Home</NavItem>
      <NavItem href="#code-insights" icon={<Bookmark size={16}/>}>Bookmarks</NavItem>
      <NavItem href="#roadmap-features-extension-options" icon={<History size={16}/>}>Recently Viewed</NavItem>
    </nav>
    <SidebarGroup title="Feature Registry">
      {features.slice(0, 8).map((feature, i) => <NavItem href="#ai-purpose-scope" icon={<Box size={15}/>} key={`${feature}-${i}`}>{cleanNavLabel(feature)}</NavItem>)}
    </SidebarGroup>
    <SidebarGroup title="API Inventory">
      {apis.slice(0, 8).map((api, i) => <NavItem href="#ai-architecture" icon={<Braces size={15}/>} key={`${api}-${i}`}>{cleanNavLabel(api)}</NavItem>)}
    </SidebarGroup>
    <SidebarGroup title="Tech Stack Tree">
      {techStack.slice(0, 8).map((item, i) => <NavItem href="#ai-dev2dev-info" icon={<Network size={15}/>} key={`${item}-${i}`}>{cleanNavLabel(item)}</NavItem>)}
    </SidebarGroup>
    <SidebarGroup title="How to Use / Run">
      <NavItem href="#ai-dev2dev-info" icon={<Play size={15}/>}>Local Setup</NavItem>
      <NavItem href="#ai-dev2dev-info" icon={<Terminal size={15}/>}>Run Services</NavItem>
      <NavItem href="#ai-dev2dev-info" icon={<Settings size={15}/>}>Environment</NavItem>
    </SidebarGroup>
    <SidebarGroup title="Entry Point">
      {entries.length === 0 ? <NavItem href="#code-insights" icon={<Compass size={15}/>}>System Overview</NavItem> : entries.slice(0, 3).map((e, i) => <NavItem href="#code-insights" icon={<Compass size={15}/>} key={`${e.path}-${i}`}>{e.path.split('/').slice(-1)[0]}:{e.startLine || 1}</NavItem>)}
    </SidebarGroup>
  </aside>;
}

function RightSidebar({ workspace, activeSection, onRefresh, insights }) {
  const sectionLabel = DOC_SECTIONS.find(([id]) => id === activeSection)?.[1] || 'Overview';
  const refs = sourceRefs(workspace, sectionLabel.split(/\s+|\//).filter(Boolean), 5);
  const contributors = (workspace.keyContributors || []).slice(0, 5);
  const relatedRepos = workspace.repositories || [];
  return <aside className="right-sidebar" aria-label="Contextual intelligence">
    <GitHubContextTopCards insights={insights} />
    <div className="context-card">
      <h3>Key Contributors</h3>
      {contributors.length === 0 ? <p className="muted">No contributor names detected.</p> : contributors.map((c, i) => <div className="mini-row" key={i}><strong>{c.name}</strong><span>{c.repoName || 'Workspace'}</span></div>)}
    </div>
    <div className="context-card">
      <h3>Related Repositories</h3>
      {relatedRepos.slice(0, 5).map(r => <div className="mini-row" key={r.repoId || r.name}><strong>{r.name}</strong><span>{relatedRepos.length > 1 ? 'Workspace subsystem' : 'Current repository'}</span></div>)}
    </div>
    <div className="context-card">
      <h3>Page Context</h3>
      <dl>
        <dt>Current section</dt><dd>{sectionLabel}</dd>
        <dt>Related APIs</dt><dd>{detectApis(workspace).slice(0, 2).map(a => a.endpoint).join(', ') || 'Not detected'}</dd>
        <dt>Last updated</dt><dd>{workspace.generatedAt ? new Date(workspace.generatedAt).toLocaleDateString() : 'Current session'}</dd>
        <dt>Confidence</dt><dd>{workspace.totalChunks > 20 ? 'Medium / evidence-backed' : 'Low / limited evidence'}</dd>
      </dl>
    </div>
    <div className="context-card">
      <h3>Source Traceability</h3>
      <div className="source-mini-list">{refs.map((r, i) => <code key={`${r.path}-${i}`}>{r.path}:{r.startLine || 1}-{r.endLine || '?'}</code>)}</div>
    </div>
    <div className="context-card">
      <h3>Sync Utility</h3>
      <p className="muted">Refresh re-indexes repositories and updates H2-persisted workspace records.</p>
      <button onClick={onRefresh}><RefreshCw size={16}/> Refresh this wiki</button>
    </div>
  </aside>;
}

function Section({ id, title, subtitle, refs, children }) {
  return <section id={id} className="doc-section">
    <div className="section-title-row"><h2>{title}</h2>{refs?.[0] && <EvidenceTag refItem={refs[0]} />}</div>
    {subtitle && <p className="section-subtitle">{subtitle}</p>}
    <SourceAccordion refs={refs || []} />
    {children}
  </section>;
}

function DiagramBlock({ title, chart, status = 'Available', confidence = 'Evidence-backed', refs = [] }) {
  return <div className="diagram-block">
    <div className="diagram-meta"><strong>{title}</strong><span>Status: {status}</span><span>Confidence: {confidence}</span><span>Evidence: {refs.length || 'indexed graph'} source refs</span></div>
    {chart ? <Mermaid chart={chart} /> : <div className="empty-box">Diagram unavailable: insufficient evidence detected.</div>}
  </div>;
}

function DocumentationCard({ href, icon, title, description }) {
  return <a className="doc-nav-card" href={href}>
    <div className="card-icon">{icon}</div>
    <div><h3>{title}</h3><p>{description}</p></div>
    <ChevronRight className="card-chevron" size={20}/>
  </a>;
}

function DocumentationCardGrid() {
  return <section className="doc-card-grid" aria-label="Documentation quick navigation">
    <DocumentationCard href="#ai-architecture" icon={<Layers size={26}/>} title="Architecture Overview" description="High-level architecture, service boundaries, interaction and flow diagrams." />
    <DocumentationCard href="#ai-dev2dev-info" icon={<Users size={26}/>} title="New Developer Hangout" description="Onboarding guide, project walkthroughs, setup and configuration notes." />
    <DocumentationCard href="#security-aspects" icon={<Shield size={26}/>} title="Security Aspects" description="Security model, authentication, authorization and data protection notes." />
    <DocumentationCard href="#code-insights" icon={<Code2 size={26}/>} title="Code Insights" description="Source structure, core abstractions, key modules and implementation details." />
    <DocumentationCard href="#design-elevation" icon={<Palette size={26}/>} title="Design Elevation" description="Design patterns, decision smells, code smells and improvement priorities." />
    <DocumentationCard href="#roadmap-features-extension-options" icon={<Flag size={26}/>} title="Roadmap Features and Extension Options" description="Upcoming features, extension points and related repository options." />
  </section>;
}

function DocumentationMain({ workspace, insights, aiSections }) {
  const names = workspace.repositories?.map(r => r.name).join(' + ') || 'Repository';
  return <main className="main-doc">
    <section id="title" className="doc-title repo-hero">
      <div className="repo-breadcrumb">Repositories <ChevronRight size={14}/> {names.split('/')[0] || 'workspace'} <ChevronRight size={14}/> {names.split('/')[1] || names}</div>
      <div className="repo-title-row">
        <div className="repo-icon"><BookOpen size={22}/></div>
        <div className="repo-title-main">
          <h1>{names}</h1>
          <div className="repo-meta"><span>Repository</span><GitBranch size={14}/><span>{workspace.branch || 'main'}</span><Clock size={14}/><span>Updated {workspace.generatedAt ? new Date(workspace.generatedAt).toLocaleString() : 'current session'}</span></div>
        </div>
        <div className="repo-actions"><button><Eye size={16}/> Watch</button><button><MoreVertical size={16}/></button></div>
      </div>
    </section>

    <div className="purpose-preview" onClick={() => document.getElementById('ai-purpose-scope')?.scrollIntoView({ behavior: 'smooth' })}>
      <div className="purpose-accent" />
      <h2>Purpose & Scope</h2>
      <p>{plainText(aiSections.purpose || workspace.summary || workspace.overview || 'Repository purpose and scope will appear after indexing.').slice(0, 260)}{plainText(aiSections.purpose || workspace.summary || workspace.overview || '').length > 260 ? '...' : ''}</p>
    </div>

    <DocumentationCardGrid />

    <AdditiveMainContentSections workspace={workspace} insights={insights} aiSections={aiSections} />
  </main>;
}


function sanitizeMasterShifuCommand(value) {
  const cleaned = String(value || '')
    .replace(/\bmaster\s+shifu\b\s*[:,\-–—]?\s*/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  return cleaned || String(value || '').trim();
}

function SmartBar({ workspace, activeSection, open, setOpen }) {
  const [mode, setMode] = useState('ask');
  const [text, setText] = useState('Explain this repository like I am a new developer.');
  const [response, setResponse] = useState('');
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState([]);
  const { transcript, isListening, startListening, stopListening, error: speechError } = useSpeechToText();
  const wiki = firstWiki(workspace);
  const repoLabel = repoTitle(workspace);

  useEffect(() => {
    if (transcript) setText(transcript);
  }, [transcript]);

  if (!open) return null;

  const modes = [
    ['ask', 'General Ask'],
    ['explain-code', 'Explain Code'],
    ['find-source', 'Find Source'],
    ['api-journey', 'API Journey'],
    ['system-health', 'System Health']
  ];

  const modePrompt = {
    ask: '',
    'explain-code': 'Explain the relevant code and architecture context. Cite source files where possible. ',
    'find-source': 'Find the most relevant source files and explain why they matter. ',
    'api-journey': 'Trace the API journey, request flow, and source files involved. ',
    'system-health': 'Assess production readiness, risks, observability, resilience, and system health evidence. '
  };

  async function submit(e) {
    e.preventDefault();
    if (!wiki || busy) return;
    if (isListening) stopListening();
    const submittedText = sanitizeMasterShifuCommand(text);
    if (!submittedText) return;

    setText(submittedText);
    setBusy(true);
    setResponse('');
    setMessages(prev => [...prev, { role: 'user', content: submittedText, mode }]);
    try {
      if (mode === 'find-source') {
        const data = await searchWiki(wiki.id, submittedText, 8);
        const result = (data.results || []).map(r => `- \`${r.path}:${r.startLine}-${r.endLine}\` — ${r.preview}`).join('\n') || 'No source results found.';
        setResponse(result);
        setMessages(prev => [...prev, { role: 'assistant', content: result, mode }]);
      } else {
        const question = `${modePrompt[mode] || ''}Current section: ${activeSection}. ${submittedText}`;
        const data = await askWiki({ wikiId: wiki.id, question });
        const citations = (data.citations || []).map(c => `- \`${c}\``).join('\n');
        const result = `${data.answer || ''}${citations ? `\n\n### Citations\n${citations}` : ''}`;
        setResponse(result);
        setMessages(prev => [...prev, { role: 'assistant', content: result, mode }]);
      }
    } catch (err) {
      const result = err.message || 'Master Shifu request failed.';
      setResponse(result);
      setMessages(prev => [...prev, { role: 'assistant', content: result, mode, error: true }]);
    } finally {
      setBusy(false);
    }
  }

  function toggleSpeech() {
    if (isListening) stopListening();
    else startListening();
  }

  function applyMode(nextMode) {
    setMode(nextMode);
    if (nextMode === 'ask') setText('Explain this repository like I am a new developer.');
    if (nextMode === 'explain-code') setText('Explain the main code structure and cite source files.');
    if (nextMode === 'find-source') setText('Find the source files for the main business flow.');
    if (nextMode === 'api-journey') setText('Show the API journey for the main request flow.');
    if (nextMode === 'system-health') setText('Assess system health, observability, resilience, and risks.');
  }

  return <div className="shifu-overlay" role="dialog" aria-modal="true" aria-label="Ask Master Shifu">
    <div className="shifu-shell">
      <header className="shifu-header">
        <div className="shifu-brand-block">
          <div className="shifu-logo"><Sparkles size={22}/></div>
          <div>
            <div className="shifu-title-row"><h2>Master Shifu</h2><span className="shifu-version">v2.5 PRO</span></div>
            <div className="shifu-status"><span className="sync-dot"/>Connected to <code>{repoLabel}</code></div>
          </div>
        </div>
        <div className="shifu-header-actions">
          <button className="icon-action quiet" title="Clear conversation" onClick={() => { setMessages([]); setResponse(''); }}><RefreshCw size={17}/></button>
          <button className="icon-action quiet" title="Settings"><Settings size={17}/></button>
          <button className="shifu-close" onClick={() => setOpen(false)}>Close</button>
        </div>
      </header>

      <div className="shifu-mode-row">
        {modes.map(([id, label]) => <button key={id} className={`shifu-mode ${mode === id ? 'active' : ''}`} onClick={() => applyMode(id)}>{label}</button>)}
      </div>

      <section className="shifu-canvas">
        {messages.length === 0 && <div className="shifu-intro-message">
          <div className="shifu-avatar"><Sparkles size={18}/></div>
          <div>
            <p>I am <strong>Master Shifu</strong>, your System Architect AI. I have analyzed the <code>{repoLabel}</code> repository.</p>
            <p>How can I help you navigate the architecture or resolve a technical hurdle today?</p>
          </div>
        </div>}

        {messages.map((message, index) => <div key={`${message.role}-${index}`} className={`shifu-message ${message.role} ${message.error ? 'error' : ''}`}>
          <div className="shifu-message-role">{message.role === 'user' ? 'You' : 'Master Shifu'}</div>
          <Markdown text={message.content}/>
        </div>)}
        {busy && <div className="shifu-thinking"><Loader2 className="spin" size={18}/> Master Shifu is reasoning over the indexed repository...</div>}
      </section>

      <form onSubmit={submit} className="shifu-composer">
        <button
          type="button"
          className={`shifu-mic ${isListening ? 'listening' : ''}`}
          onClick={toggleSpeech}
          title={isListening ? 'Stop voice input' : 'Start voice input'}
          aria-label={isListening ? 'Stop voice input' : 'Start voice input'}
        ><Mic size={20}/></button>
        <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Query the system architecture..." />
        <button className="shifu-send" disabled={busy || !wiki} title="Send"><ArrowRight size={20}/></button>
      </form>
      <div className="shifu-footer-hints">
        <span>⌘_ Open logs</span>
        <span>•• Advanced</span>
        <span><kbd>Enter</kbd> to send</span>
        <span><kbd>Shift+Enter</kbd> new line</span>
      </div>
      {isListening && <div className="speech-status shifu-speech">Listening... speak now. Click the mic again to stop.</div>}
      {speechError && <div className="speech-error shifu-speech">{speechError}</div>}
    </div>
  </div>;
}

function Workspace({ workspace, onBack, onRefresh }) {
  const { insights, aiSections } = useWorkspaceEnhancements(workspace);
  const [activeSection, setActiveSection] = useState('overview');
  const [theme, setTheme] = useState('light');
  const [smartbarOpen, setSmartbarOpen] = useState(false);
  useEffect(() => {
    const ids = DOC_SECTIONS.map(([id]) => id);
    const observer = new IntersectionObserver(entries => {
      const visible = entries.filter(e => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
      if (visible?.target?.id) setActiveSection(visible.target.id);
    }, { rootMargin: '-90px 0px -65% 0px', threshold: 0.01 });
    ids.forEach(id => { const el = document.getElementById(id); if (el) observer.observe(el); });
    return () => observer.disconnect();
  }, [workspace?.id]);
  return <div className={`workspace-page ${theme}`}>
    <GlobalHeader workspace={workspace} onBack={onBack} onRefresh={onRefresh} onAskClick={() => setSmartbarOpen(true)} theme={theme} setTheme={setTheme} />
    <div className="three-column-layout">
      <LeftSidebar workspace={workspace}/>
      <DocumentationMain workspace={workspace} insights={insights} aiSections={aiSections}/>
      <RightSidebar workspace={workspace} activeSection={activeSection} onRefresh={onRefresh} insights={insights}/>
    </div>
    <SmartBar workspace={workspace} activeSection={activeSection} open={smartbarOpen} setOpen={setSmartbarOpen}/>
  </div>;
}

function App() {
  const [repoInput, setRepoInput] = useState('https://github.com/fanshuangstrive/payment_system');
  const [branch, setBranch] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [capabilities, setCapabilities] = useState(null);
  const [workspace, setWorkspace] = useState(null);
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState('');
  const [error, setError] = useState('');
  const [recent, setRecent] = useState(recentWorkspaces());
  const [indexedWorkspaces, setIndexedWorkspaces] = useState([]);
  const [indexedLoading, setIndexedLoading] = useState(false);

  function refreshIndexedWorkspaces() {
    setIndexedLoading(true);
    listWorkspaces()
      .then(data => setIndexedWorkspaces(Array.isArray(data) ? data : []))
      .catch(() => setIndexedWorkspaces([]))
      .finally(() => setIndexedLoading(false));
  }

  useEffect(() => { getCapabilities().then(setCapabilities).catch(()=>{}); refreshIndexedWorkspaces(); }, []);

  async function index(e, force=false, overrideRepoInput=null) {
    if (e?.preventDefault) e.preventDefault();
    setError('');
    if (!force) {
      const inputForIndex = overrideRepoInput || repoInput;
      const cached = getCached(inputForIndex, branch);
      if (cached) { setWorkspace(cached); setRecent(recentWorkspaces()); return; }
    }
    setLoading(true); setStage('Starting workspace index');
    try {
      const inputForIndex = overrideRepoInput || repoInput;
      const job = await startWorkspaceIndex({ repoInput: inputForIndex, branch: branch || undefined, accessToken: accessToken || undefined });
      let done = false;
      while (!done) {
        await new Promise(r => setTimeout(r, 1400));
        const status = await getWorkspaceJob(job.jobId);
        setStage(`${status.stage} · ${status.progress}% · ${status.message}`);
        if (status.status === 'READY') {
          setWorkspace(status.workspace);
          saveWorkspace(inputForIndex, branch, status.workspace);
          setRecent(recentWorkspaces());
          refreshIndexedWorkspaces();
          done = true;
        }
        if (status.status === 'FAILED') throw new Error(status.error || 'Workspace indexing failed');
      }
    } catch (err) { setError(err.message || 'Index failed'); }
    finally { setLoading(false); }
  }

  function useRecent(item) {
    const cached = getCached(item.repoInput, item.branch);
    if (cached) { setRepoInput(item.repoInput); setBranch(item.branch || ''); setWorkspace(cached); }
  }

  function openIndexedWorkspace(item) {
    if (!item) return;
    const repos = (item.repositories || []).map(r => r.url).filter(Boolean).join('\n');
    if (repos) setRepoInput(repos);
    setBranch(item.branch || '');
    setWorkspace(item);
  }

  if (loading) return <div className="loading"><div className="loading-card"><Loader2 className="spin" size={42}/><h2>Indexing workspace</h2><p>{stage}</p></div></div>;
  return <>{error && <div className="error">{error}</div>}{workspace ? <Workspace workspace={workspace} onBack={()=>setWorkspace(null)} onRefresh={()=>index(null,true)} /> : <Landing repoInput={repoInput} setRepoInput={setRepoInput} branch={branch} setBranch={setBranch} accessToken={accessToken} setAccessToken={setAccessToken} onIndex={index} onIndexRepoInput={(value)=>index(null, false, value)} loading={loading} capabilities={capabilities} recent={recent} onUseRecent={useRecent} indexedWorkspaces={indexedWorkspaces} onOpenIndexedWorkspace={openIndexedWorkspace} indexedLoading={indexedLoading}/>}</>;
}

createRoot(document.getElementById('root')).render(<App/>);
