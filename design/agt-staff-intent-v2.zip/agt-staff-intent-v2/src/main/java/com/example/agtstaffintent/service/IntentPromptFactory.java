package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentRequest;
import com.example.agtstaffintent.domain.RankedIntent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class IntentPromptFactory {

    private final ObjectMapper objectMapper;

    public IntentPromptFactory(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public String systemPrompt() {
        return """
                You are the intent discovery agent for agt-staff-intent.
                Your job is to select exactly one intent from the shortlisted candidate intents.
                You must also extract entities from the user request.

                Rules:
                1. Select only from shortlisted intents provided in context.
                2. Respect persona. If the user role does not fit an intent, do not choose it.
                3. Negative keywords and business rules are strong disambiguation signals.
                4. Do not invent services not present in the chosen taxonomy.
                5. Return strict JSON only. No markdown.
                6. If none of the shortlisted intents is a credible fit, return UNKNOWN_OR_UNSUPPORTED_REQUEST.
                7. When deciding on a domain-specific intent, anchor terms matter more than generic terms like status, my, check, show.

                Output JSON shape:
                {
                  "selectedIntent": "STRING",
                  "confidence": 0.0,
                  "rationale": "STRING",
                  "entities": {
                    "scope": "STRING OR NULL",
                    "team": "STRING OR NULL",
                    "leaveApplicationId": "STRING OR NULL",
                    "decision": "STRING OR NULL",
                    "status": "STRING OR NULL",
                    "certificateStatus": "STRING OR NULL",
                    "caseId": "STRING OR NULL",
                    "issueType": "STRING OR NULL"
                  },
                  "serviceCandidates": [
                    {
                      "service": "STRING",
                      "domain": "STRING",
                      "function": "STRING",
                      "action": "STRING"
                    }
                  ],
                  "candidateIntents": ["STRING", "STRING"]
                }
                """;
    }

    public String userPrompt(IntentRequest request, List<RankedIntent> shortlisted) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("request", request);
        payload.put("shortlistedIntents", shortlisted);
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Unable to create LLM prompt", e);
        }
    }
}
