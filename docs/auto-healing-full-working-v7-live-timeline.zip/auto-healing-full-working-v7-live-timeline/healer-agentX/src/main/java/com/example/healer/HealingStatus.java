package com.example.healer;

import java.util.*;

public class HealingStatus {
  public String status = "HEALTHY";
  public String incidentId = null;
  public String title = null;
  public String service = "Payment-Service";
  public String severity = "NORMAL";
  public String classification = null;
  public String affectedContainers = "0 of 12";
  public String branch;
  public String pullRequestUrl;
  public String error;
  public String transactionType;
  public String actionRequired = "NONE";
  public String aiPlanJson;
  public List<String> timeline = new ArrayList<>();
}
