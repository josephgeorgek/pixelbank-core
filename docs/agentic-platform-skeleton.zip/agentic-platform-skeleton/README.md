# Agentic Platform Skeleton (Spring Boot + LangGraph4j + Spring AI)

This sample is a starter skeleton, not a production-ready codebase. It is designed to show how the following pieces can fit together:

- `ms-agentic-buddy` — request intake and user context
- `agentic-orchestrator` — graph supervisor/orchestrator
- `intent-agent` — taxonomy lookup + intent/entity resolution
- `fulfilment-agent` — graph step execution and MCP tool invocation
- `ms-workforce-knowledgebase` — intent taxonomy + knowledge retrieval
- `ms-control-gate` — entitlement and policy validation
- `ms-gateway` — governed enterprise API gateway
- `mcp-server-workplace` — example MCP server for workplace tools

## Notes

1. Update exact Maven coordinates for LangGraph4j and your chosen Spring AI model starter before compiling.
2. Use Java 17+; this skeleton targets Java 21.
3. Keep the graph contract and tool schemas framework-neutral so the orchestration model remains portable.

## Suggested build order

1. `common-contracts`
2. `ms-workforce-knowledgebase`
3. `ms-control-gate`
4. `mcp-server-workplace`
5. `intent-agent`
6. `fulfilment-agent`
7. `agentic-orchestrator`
8. `ms-agentic-buddy`

## Key files

- `agentic-orchestrator/src/main/resources/graphs/book-hot-desk-v1.json`
- `examples/mcp-book-hot-desk.json`
- `examples/mcp-submit-leave.json`
- `docs/development-steps.md`
- `docs/component-dependencies.md`
