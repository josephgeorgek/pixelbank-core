package com.ocbc.staff.mcp.leave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class AgtMcpStaffLeaveApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgtMcpStaffLeaveApplication.class, args);
    }
}
