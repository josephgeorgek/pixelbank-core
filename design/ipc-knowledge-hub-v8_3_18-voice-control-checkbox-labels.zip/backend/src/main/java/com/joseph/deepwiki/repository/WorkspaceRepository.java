package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.WorkspaceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface WorkspaceRepository extends JpaRepository<WorkspaceEntity, String> {}
