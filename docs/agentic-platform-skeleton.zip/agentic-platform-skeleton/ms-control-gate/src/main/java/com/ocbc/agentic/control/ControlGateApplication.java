package com.ocbc.agentic.control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlGateApplication {
    public static void main(String[] args) {
        SpringApplication.run(ControlGateApplication.class, args);
    }
}
