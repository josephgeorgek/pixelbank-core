package com.ocbc.staff.orchestrator.graph;

public class ErrorHandlerDefinition {
    private String next;

    public String getNext() { return next; }
    public void setNext(String next) { this.next = next; }
}
