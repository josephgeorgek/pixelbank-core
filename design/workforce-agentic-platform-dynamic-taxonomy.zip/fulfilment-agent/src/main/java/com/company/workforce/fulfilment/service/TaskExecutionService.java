package com.company.workforce.fulfilment.service;

import com.company.workforce.contracts.api.TaskExecutionRequest;
import com.company.workforce.contracts.api.TaskExecutionResponse;
import com.company.workforce.contracts.enums.ExecutionStatus;
import com.company.workforce.contracts.enums.TaskType;
import com.company.workforce.fulfilment.client.KnowledgebaseClient;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class TaskExecutionService {

    private final KnowledgebaseClient knowledgebaseClient;
    private final OpenAiIntentEntityExtractionService extractionService;

    public TaskExecutionService(KnowledgebaseClient knowledgebaseClient,
                                OpenAiIntentEntityExtractionService extractionService) {
        this.knowledgebaseClient = knowledgebaseClient;
        this.extractionService = extractionService;
    }

    @SuppressWarnings("unchecked")
    public TaskExecutionResponse execute(TaskExecutionRequest request) {
        long totalStart = System.nanoTime();
        try {
            if (request.taskType() == TaskType.API_CALL) {
                Map<String, Object> response = knowledgebaseClient.call(
                        request.targetEndpoint(),
                        request.input()
                );
                Map<String, Object> metadata = new LinkedHashMap<>();
                metadata.put("timings_ms", Map.of("total_fulfilment_agent", toMs(System.nanoTime() - totalStart)));
                return new TaskExecutionResponse(
                        request.executionId(),
                        request.taskId(),
                        ExecutionStatus.COMPLETED,
                        response,
                        metadata,
                        null
                );
            }

            if (request.taskType() == TaskType.AI_EXTRACT) {
                String utterance = String.valueOf(request.input().getOrDefault("utterance", ""));
                String domain = String.valueOf(request.metadata().getOrDefault("domain", "HR"));
                List<String> candidateIntents = (List<String>) request.metadata().getOrDefault("candidateIntents", List.of());

                Map<String, Object> extractionResult = extractionService.extract(utterance, domain, candidateIntents);
                Map<String, Object> responseMetadata = new LinkedHashMap<>();
                Object extractionMetadata = extractionResult.get("metadata");
                if (extractionMetadata instanceof Map<?, ?> map) {
                    responseMetadata.putAll((Map<String, Object>) map);
                }
                return new TaskExecutionResponse(
                        request.executionId(),
                        request.taskId(),
                        ExecutionStatus.COMPLETED,
                        (Map<String, Object>) extractionResult.get("extraction"),
                        responseMetadata,
                        null
                );
            }

            return new TaskExecutionResponse(
                    request.executionId(),
                    request.taskId(),
                    ExecutionStatus.FAILED,
                    Map.of(),
                    Map.of(),
                    "Unsupported task type: " + request.taskType()
            );
        } catch (Exception e) {
            return new TaskExecutionResponse(
                    request.executionId(),
                    request.taskId(),
                    ExecutionStatus.FAILED,
                    Map.of(),
                    Map.of("timings_ms", Map.of("total_fulfilment_agent", toMs(System.nanoTime() - totalStart))),
                    e.getMessage()
            );
        }
    }

    private long toMs(long nanos) {
        return nanos / 1_000_000;
    }
}
