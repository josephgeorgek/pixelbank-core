package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.SymbolEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SymbolRepository extends JpaRepository<SymbolEntity, Long> { void deleteByWikiId(String wikiId); long countByWikiId(String wikiId); }
