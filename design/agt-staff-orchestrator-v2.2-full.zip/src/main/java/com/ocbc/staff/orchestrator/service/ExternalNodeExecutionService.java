package com.ocbc.staff.orchestrator.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ocbc.staff.orchestrator.config.ServiceRegistryProperties;
import com.ocbc.staff.orchestrator.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.model.WorkflowState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class ExternalNodeExecutionService {
    private static final Logger log = LoggerFactory.getLogger(ExternalNodeExecutionService.class);

    private final ServiceRegistryProperties serviceRegistryProperties;
    private final MappingResolverService mappingResolverService;
    private final ObjectMapper objectMapper;

    public ExternalNodeExecutionService(ServiceRegistryProperties serviceRegistryProperties,
                                        MappingResolverService mappingResolverService,
                                        ObjectMapper objectMapper) {
        this.serviceRegistryProperties = serviceRegistryProperties;
        this.mappingResolverService = mappingResolverService;
        this.objectMapper = objectMapper;
    }

    public Map<String, Object> execute(GraphNodeDefinition node, WorkflowState state) {
        Map<String, Object> config = castMap(node.getConfig());
        Map<String, Object> target = castMap(config.get("target"));
        Map<String, Object> requestTemplate = castMap(config.get("requestTemplate"));
        Map<String, Object> serviceCandidate = castMap(config.get("serviceCandidate"));
        Map<String, Object> requestBody = mappingResolverService.resolveTemplate(requestTemplate, state);
        mergeIfMissing(requestBody, serviceCandidate);

        String method = String.valueOf(target.getOrDefault("method", "POST"));
        String endpoint = String.valueOf(target.getOrDefault("endpoint", ""));
        String baseUrl = resolveBaseUrl(target);
        long timeoutMs = toLong(target.getOrDefault("timeoutMs", 3000L));

        if (baseUrl.isBlank()) throw new IllegalArgumentException("Missing target baseUrl or resolvable serviceAlias for node " + node.getId());
        if (endpoint.isBlank()) throw new IllegalArgumentException("Missing target endpoint for node " + node.getId());

        String url = normalizeUrl(baseUrl, endpoint);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        RestTemplate restTemplate = buildRestTemplate(timeoutMs);

        log.info("[API_CALL_START] executionId={} nodeId={} delegateTo={} taskType={} method={} url={} timeoutMs={}",
                state.getExecutionId(), node.getId(), node.getDelegateTo(), node.getTaskType(), method, url, timeoutMs);
        log.info("[API_CALL_REQUEST] executionId={} nodeId={} payload={}",
                state.getExecutionId(), node.getId(), toJson(requestBody));

        ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                url,
                HttpMethod.valueOf(method.toUpperCase()),
                entity,
                new ParameterizedTypeReference<>() {}
        );

        Map<String, Object> body = response.getBody();
        Map<String, Object> normalized = body == null ? new LinkedHashMap<>() : body;

        log.info("[API_CALL_RESPONSE] executionId={} nodeId={} httpStatus={} payload={}",
                state.getExecutionId(), node.getId(), response.getStatusCode().value(), toJson(normalized));
        log.info("[API_CALL_END] executionId={} nodeId={} delegateTo={} completed=true",
                state.getExecutionId(), node.getId(), node.getDelegateTo());

        return normalized;
    }

    private RestTemplate buildRestTemplate(long timeoutMs) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        int timeout = (int) Math.min(timeoutMs, Integer.MAX_VALUE);
        requestFactory.setConnectTimeout(timeout);
        requestFactory.setReadTimeout(timeout);
        return new RestTemplate(requestFactory);
    }

    private String resolveBaseUrl(Map<String, Object> target) {
        Object baseUrl = target.get("baseUrl");
        if (baseUrl != null && !String.valueOf(baseUrl).isBlank()) return String.valueOf(baseUrl);
        Object alias = target.get("serviceAlias");
        if (alias == null) return "";
        return serviceRegistryProperties.getAliases().getOrDefault(String.valueOf(alias), "");
    }

    private String normalizeUrl(String baseUrl, String endpoint) {
        if (baseUrl.endsWith("/") && endpoint.startsWith("/")) return baseUrl.substring(0, baseUrl.length() - 1) + endpoint;
        if (!baseUrl.endsWith("/") && !endpoint.startsWith("/")) return baseUrl + "/" + endpoint;
        return baseUrl + endpoint;
    }

    private void mergeIfMissing(Map<String, Object> requestBody, Map<String, Object> serviceCandidate) {
        for (Map.Entry<String, Object> entry : serviceCandidate.entrySet()) {
            requestBody.putIfAbsent(entry.getKey(), entry.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> castMap(Object value) {
        if (value instanceof Map<?, ?> map) return (Map<String, Object>) map;
        return new LinkedHashMap<>();
    }

    private long toLong(Object value) {
        if (value instanceof Number n) return n.longValue();
        return Long.parseLong(String.valueOf(value));
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException ex) {
            return String.valueOf(value);
        }
    }
}
