package com.company.workforce.contracts.enums;

public enum ExecutionStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED
}
