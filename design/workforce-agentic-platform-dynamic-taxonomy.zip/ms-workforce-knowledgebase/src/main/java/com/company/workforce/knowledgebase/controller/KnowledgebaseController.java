package com.company.workforce.knowledgebase.controller;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/v1")
public class KnowledgebaseController {

    @PostMapping("/search")
    public Map<String, Object> search(@RequestBody Map<String, Object> request) {
        String query = String.valueOf(request.get("query"));
        return Map.of(
                "documentId", "DOC-1001",
                "title", "Singapore Leave Policy",
                "matchedQuery", query
        );
    }

    @PostMapping("/fetch")
    public Map<String, Object> fetch(@RequestBody Map<String, Object> request) {
        String documentId = String.valueOf(request.get("documentId"));
        return Map.of(
                "documentId", documentId,
                "title", "Singapore Leave Policy",
                "content", "This is a stubbed knowledgebase fetch response."
        );
    }
}
