package com.joseph.deepwiki.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "graph_edges", indexes = @Index(name="idx_graph_edges_wiki", columnList="wikiId"))
public class GraphEdgeEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String wikiId;
    public String edgeId;
    public String sourceNodeId;
    public String targetNodeId;
    public String edgeType;
    public String label;
    @Column(length = 2000) public String path;
    public int lineNumber;
    public String evidenceKind;
    public String confidence;
    public GraphEdgeEntity() {}
}
