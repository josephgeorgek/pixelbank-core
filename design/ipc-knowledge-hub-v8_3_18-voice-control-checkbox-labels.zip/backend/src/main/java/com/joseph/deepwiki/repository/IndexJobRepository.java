package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.IndexJobEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IndexJobRepository extends JpaRepository<IndexJobEntity, String> {}
