package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class InMemoryWorkflowStateStore {

    private final Map<String, WorkflowState> states = new ConcurrentHashMap<>();

    public void save(WorkflowState state) {
        states.put(state.getExecutionId(), state);
    }

    public WorkflowState get(String executionId) {
        WorkflowState state = states.get(executionId);
        if (state == null) {
            throw new IllegalArgumentException("Unknown executionId: " + executionId);
        }
        return state;
    }
}
