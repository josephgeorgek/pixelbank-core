# Auto-Healing Full Working v6 - Rich Dynamic UI + Real GitHub

This keeps the incident-driven behavior from v5 and restores the richer high-density dashboard UI.

## Run

```bash
export GITHUB_PERSONAL_ACCESS_TOKEN="github_pat_xxx"
export GITHUB_OWNER="josephgeorgek"
export GITHUB_REPO="payment-processor-demo"
export GITHUB_BASE_BRANCH="main"
export GITHUB_MOCK_MODE="false"

docker compose up --build
```

Open:

```text
http://localhost:5173
```

## Demo flow

1. UI starts healthy. No incident timeline is shown.
2. Trigger runtime failure:

```bash
curl -X POST http://localhost:8080/api/payments/process \
  -H "Content-Type: application/json" \
  -d '{"type":"SWIFT_INTL","amount":5000}'
```

3. UI self-refreshes. Payment-Service becomes ACTION REQUIRED.
4. Click Payment-Service in the left sidebar.
5. Timeline progresses automatically over self-refresh:
   - Detect
   - Analyze
   - Classify
   - Root cause
   - Plan
   - GitHub branch + PR
6. Click GitHub PR link.
7. Click Promote to PROD.
8. Status becomes RESTORED.


## v7 UI update

- Timeline now uses timestamped rows like the reference image.
- Timeline has colored stage badges and status chips.
- Evidence panel is restored with Logs / Metrics / Traces / Config Diff / Patch tabs.
- When status reaches AWAITING_PROD_APPROVAL, GitOps review card and clickable PR link are shown.
