package com.ocbc.staff.orchestrator.api.dto;

import com.ocbc.staff.orchestrator.model.WorkflowStatus;

import java.time.Instant;

public class StartWorkflowResponse {
    private String executionId;
    private String graphId;
    private WorkflowStatus status;
    private String currentNodeId;
    private Instant startedAt;

    public StartWorkflowResponse() {
    }

    public StartWorkflowResponse(String executionId, String graphId, WorkflowStatus status, String currentNodeId, Instant startedAt) {
        this.executionId = executionId;
        this.graphId = graphId;
        this.status = status;
        this.currentNodeId = currentNodeId;
        this.startedAt = startedAt;
    }

    public String getExecutionId() {
        return executionId;
    }

    public String getGraphId() {
        return graphId;
    }

    public WorkflowStatus getStatus() {
        return status;
    }

    public String getCurrentNodeId() {
        return currentNodeId;
    }

    public Instant getStartedAt() {
        return startedAt;
    }
}
