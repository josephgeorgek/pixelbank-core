package com.ocbc.agentic.orchestrator.graph;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class GraphLoader {
    private final ObjectMapper objectMapper;

    public GraphLoader(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public JsonNode load(String graphId) {
        try {
            String filename = graphId.replace('_', '-') + ".json";
            return objectMapper.readTree(new ClassPathResource("graphs/" + filename).getInputStream());
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to load graph: " + graphId, ex);
        }
    }
}
