package com.example.healer;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PlanValidator {
  private static final List<String> BLOCKED_PATTERNS = List.of(
      "DROP TABLE",
      "TRUNCATE TABLE",
      "DELETE FROM",
      "UPDATE CUSTOMER",
      "UPDATE ACCOUNT",
      "PRODUCTION DIRECT PATCH",
      "\"shouldAutoApply\":true"
  );

  public ValidationResult validate(String planJson) {
    HealerTraceLogger.step("VALIDATE_START", "Validating AI plan against guardrails");

    if (planJson == null || planJson.isBlank()) {
      HealerTraceLogger.step("VALIDATE_FAILED", "AI plan is empty");
      return ValidationResult.failed("AI plan is empty");
    }

    String upper = planJson.toUpperCase();

    for (String blocked : BLOCKED_PATTERNS) {
      if (upper.contains(blocked.toUpperCase())) {
        HealerTraceLogger.step("VALIDATE_FAILED", "Blocked unsafe plan pattern: " + blocked);
        return ValidationResult.failed("Blocked unsafe plan pattern: " + blocked);
      }
    }

    if (!upper.contains("ROLLBACK")) {
      HealerTraceLogger.step("VALIDATE_FAILED", "Plan must contain rollback plan");
      return ValidationResult.failed("Plan must contain rollback plan");
    }

    if (!upper.contains("TESTPLAN") && !upper.contains("TEST PLAN")) {
      HealerTraceLogger.step("VALIDATE_FAILED", "Plan must contain test plan");
      return ValidationResult.failed("Plan must contain test plan");
    }

    if (!upper.contains("REQUIRESHUMANAPPROVAL") && !upper.contains("HUMAN APPROVAL")) {
      HealerTraceLogger.step("VALIDATE_FAILED", "Plan must require human approval");
      return ValidationResult.failed("Plan must require human approval");
    }

    HealerTraceLogger.step("VALIDATE_PASSED", "Plan validated against generic auto-healing guardrails");
    return ValidationResult.passed("Plan validated against generic auto-healing guardrails");
  }

  public record ValidationResult(boolean passed, String message) {
    public static ValidationResult passed(String msg) { return new ValidationResult(true, msg); }
    public static ValidationResult failed(String msg) { return new ValidationResult(false, msg); }
  }
}
