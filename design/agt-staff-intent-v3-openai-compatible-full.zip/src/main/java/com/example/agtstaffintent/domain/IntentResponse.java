package com.example.agtstaffintent.domain;

import java.util.List;
import java.util.Map;

public record IntentResponse(
        String prompt,
        String userRole,
        String selectedIntent,
        double confidence,
        String rationale,
        Map<String, Object> entities,
        List<ServiceCandidate> serviceCandidates,
        Map<String, Object> debug
) {
}
