package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class AiWikiWriter {
    private static final Logger log = LoggerFactory.getLogger(AiWikiWriter.class);
    private final ObjectProvider<ChatClient.Builder> chatClientBuilderProvider;

    public AiWikiWriter(ObjectProvider<ChatClient.Builder> chatClientBuilderProvider) {
        this.chatClientBuilderProvider = chatClientBuilderProvider;
    }

    public String generateOverview(String repoUrl, List<FileSummary> files, Map<String, Long> stats, ArchitectureGraph graph) {
        String prompt = """
                You are a senior software architect generating a technical overview for a source repository.
                Write concise but meaningful markdown.
                Requirements:
                - Explain what the repository appears to do.
                - Infer the stack and major module groups.
                - Explain likely runtime flow and important interactions.
                - Mention dependency hotspots or structural risks.
                - Ground all claims in the provided evidence.
                - Use file paths inline when useful.

                Repository: %s
                Language stats: %s
                Graph stats: nodes=%s edges=%s nodeTypes=%s edgeTypes=%s
                Evidence:
                %s
                """.formatted(repoUrl, stats, graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats(), compactEvidence(files));
        return askOrFallback("generateOverview", prompt, fallbackOverview(repoUrl, files, stats, graph));
    }

    public String answerQuestion(String question, List<FileSummary> files, ArchitectureGraph graph) {
        String prompt = """
                You are a repository-grounded engineering assistant.
                Answer only from the supplied repository evidence.
                Make the answer practical and specific.
                Requirements:
                - answer the question directly first
                - explain how you know
                - mention likely entry points, flows, or dependencies when relevant
                - include file paths as evidence bullets at the end
                - if the evidence is incomplete, say so clearly

                Question: %s
                Graph stats: nodes=%s edges=%s nodeTypes=%s edgeTypes=%s
                Evidence:
                %s
                """.formatted(question, graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats(), compactEvidence(files));
        return askOrFallback("answerQuestion", prompt, fallbackAnswer(question, files, graph));
    }

    public String explainArchitecture(ArchitectureGraph graph, List<FileSummary> files) {
        String prompt = """
                Explain this repository architecture in markdown.
                Include:
                - likely entry points
                - main layers or subsystems
                - dependency hotspots
                - frontend/backend split if present
                - 3 practical questions a refactoring engineer should investigate next

                Graph nodes: %s
                Graph edges: %s
                Files: %s
                """.formatted(graph.nodes().stream().limit(80).toList(), graph.edges().stream().limit(120).toList(), files.stream().limit(30).map(FileSummary::path).toList());
        return askOrFallback("explainArchitecture", prompt, fallbackArchitecture(graph));
    }

    public AiGeneratedSections generateWorkspaceDocumentation(List<WikiResponse> wikis) {
        String purposePrompt = """
                what is Purpose and Scope, list of features of this repos like I am a business analyst

                Required markdown structure:
                ## Purpose
                ## Scope
                ## List of Features
                - feature name: short business-friendly explanation
                ## Business Analyst Notes
                """;
        String devPrompt = """
                Explain these repositories, tech stack, how to use this, configuration & Environment Management like I am a new developer

                Required markdown structure:
                ## Repository Explanation
                ## Tech Stack
                - layer: technology / evidence
                ## How to Use This Repository
                ## Configuration and Environment Management
                ## New Developer Reading Path
                """;
        String archPrompt = """
                Describe High-Level Component Architecture, System interaction Architecture in PUML format, list of API exposed, and list the key modules and responsibilities, Core Domain Model, Entity Hierarchy and Relationships of these repos, internal like I am a solution architect

                Required markdown structure:
                ## High-Level Component Architecture
                ## System Interaction Architecture
                ## PUML
                ```puml
                @startuml
                ' use only evidence-backed components; mark unknowns clearly
                @enduml
                ```
                ## APIs Exposed
                - method/path or route signal: source/evidence
                ## Key Modules and Responsibilities
                ## Core Domain Model
                ## Entity Hierarchy and Relationships
                """;
        String codeInsightsPrompt = """
                Role: Expert Codebase Educator
                Task: Generate a Light Tutorial for the indexed GitHub repository or multi-repo workspace.
                Input: current indexed repository URL(s) from the supplied evidence.

                Instructions:
                Analyze the provided repository evidence and generate a beginner-friendly tutorial. You must infer logic from the code evidence without asking clarifying questions.

                1. Analysis Phase
                Fetch & Identify: Identify the top 3 core abstractions or foundational concepts/modules.
                Map: Determine how these abstractions interact.
                Sequence: Order them from Entry Point/Foundational to Internal/Advanced.

                2. Output Requirements
                Deliver the tutorial as markdown with content sections represented by headers.

                ## Summary
                A 3-sentence beginner-friendly overview of the project using bold and italics.

                ## Architecture
                A Mermaid flowchart TD showing relationships between up to 5 core abstractions.

                ## Table of Contents
                A numbered list of chapters.

                ## 01_<abstraction_name>.md
                Write chapter 1 only. Include The Hook, The Use Case, Code Walkthrough, Under the Hood, Navigation.

                ## 02_<abstraction_name>.md
                Write chapter 2 only. Include The Hook, The Use Case, Code Walkthrough, Under the Hood, Navigation.

                Chapter rules:
                - The Hook: real-world analogy.
                - The Use Case: simple example of the problem solved.
                - Code Walkthrough: snippets only, no code block over 10 lines; use comments to skip boilerplate.
                - The Under the Hood: brief Mermaid sequenceDiagram.
                - Navigation: Previous Chapter / Next Chapter links.

                Style:
                Welcoming, encouraging, jargon-lite. Prioritize why it exists over line-by-line syntax. Standard Markdown. No complex LaTeX.
                """;
        String designElevationPrompt = """
                List all Design patterns already in this repo and list of Design patterns to be used, List of design smell and list of code smells in this repository like I am a new tech leader and senior Architect joined this.

                Required markdown structure:
                ## Design Patterns Already Present
                - pattern: where used / evidence / why it matters
                ## Design Patterns Recommended
                - pattern: where to apply / expected benefit / risk if ignored
                ## Design Smells
                - smell: evidence / architectural impact / recommended action
                ## Code Smells
                - smell: evidence / maintainability impact / recommended action
                ## Senior Architect Priorities
                - prioritized action item

                Rules:
                - Stay grounded in supplied repository evidence.
                - If a pattern or smell is inferred, mark it as inferred.
                - Do not invent frameworks or modules not present in evidence.
                - Be direct, practical, and leadership-ready.
                """;


        String roadmapFeaturesPrompt = """
                List 3 additional features can be roadmap for this repos and list possible 3 extension options available, list of 2 related repositories.

                Required markdown structure:
                ## Roadmap Features
                - feature: why it matters / evidence or assumption / first implementation step
                ## Extension Options
                - extension option: use case / integration touchpoint / implementation note
                ## Related Repositories
                - repository name or type: why related / evidence if available

                Rules:
                - Stay grounded in supplied repository evidence.
                - If a related repository is not directly found, say it is a suggested related repository type, not a confirmed dependency.
                - Keep it concise and useful for a product owner and solution architect.
                """;

        return new AiGeneratedSections(
                generateWorkspaceSection("purposeAndScope", purposePrompt, wikis, fallbackWorkspaceSection("Purpose and Scope", wikis)),
                generateWorkspaceSection("dev2DevInfo", devPrompt, wikis, fallbackWorkspaceSection("Dev 2 Dev Info", wikis)),
                generateWorkspaceSection("architectureSolutionView", archPrompt, wikis, fallbackWorkspaceArchitecture(wikis)),
                generateWorkspaceSection("codeInsights", codeInsightsPrompt, wikis, fallbackCodeInsights(wikis)),
                generateWorkspaceSection("designElevation", designElevationPrompt, wikis, fallbackDesignElevation(wikis)),
                generateWorkspaceSection("roadmapFeatures", roadmapFeaturesPrompt, wikis, fallbackRoadmapFeatures(wikis))
        );
    }

    private String generateWorkspaceSection(String operation, String instruction, List<WikiResponse> wikis, String fallback) {
        String prompt = """
                You are generating Live Docs Knowledge Hub developer documentation from indexed repository evidence.
                Follow the user instruction exactly, but stay grounded in the supplied repository evidence.
                If evidence is incomplete, state what is not detected.
                Use markdown headings, concise bullets, and file paths where useful.

                User instruction:
                %s

                Workspace evidence:
                %s
                """.formatted(instruction, compactWorkspaceEvidence(wikis));
        return askOrFallback(operation, prompt, fallback);
    }

    private String compactWorkspaceEvidence(List<WikiResponse> wikis) {
        return wikis.stream().limit(5).map(wiki -> {
            String files = wiki.files().stream().limit(28)
                    .map(f -> "PATH: " + f.path() + "\nLANG: " + f.language() + "\n" + abbreviate(f.preview(), 900))
                    .collect(Collectors.joining("\n---\n"));
            String symbols = wiki.symbols().stream().limit(40)
                    .map(s -> s.kind() + ": " + s.symbol() + " @ " + s.path() + ":" + s.line())
                    .collect(Collectors.joining("\n"));
            return "REPOSITORY: " + wiki.repoUrl()
                    + "\nBRANCH: " + wiki.branch()
                    + "\nLANGUAGE_STATS: " + wiki.languageStats()
                    + "\nGRAPH: nodes=" + wiki.architectureGraph().nodes().size()
                    + " edges=" + wiki.architectureGraph().edges().size()
                    + " nodeTypes=" + wiki.architectureGraph().nodeTypeStats()
                    + " edgeTypes=" + wiki.architectureGraph().edgeTypeStats()
                    + "\nSYMBOLS:\n" + symbols
                    + "\nFILES:\n" + files;
        }).collect(Collectors.joining("\n====================\n"));
    }

    private String fallbackRoadmapFeatures(List<WikiResponse> wikis) {
        String repoNames = wikis.stream().map(WikiResponse::repoUrl).limit(3).collect(Collectors.joining(", "));
        return "## Roadmap Features\n"
                + "- Operational dashboard: expose health, throughput, and error insights from the indexed repository evidence.\n"
                + "- API experience improvements: document and standardize API flows where controllers or route evidence exists.\n"
                + "- Developer onboarding automation: convert setup, configuration, and module evidence into guided onboarding steps.\n\n"
                + "## Extension Options\n"
                + "- Observability extension: connect logs, metrics, and traces to repository modules.\n"
                + "- API contract extension: generate OpenAPI or contract documentation from detected routes.\n"
                + "- Test intelligence extension: map tests to modules and identify coverage gaps.\n\n"
                + "## Related Repositories\n"
                + "- UI/client repository type: suggested if this repository exposes backend services.\n"
                + "- Integration/consumer repository type: suggested if this repository publishes or consumes external events or APIs.\n\n"
                + "_Fallback generated from indexed workspace metadata for: " + repoNames + "_";
    }

    private String askOrFallback(String operation, String prompt, String fallback) {
        String callId = UUID.randomUUID().toString();
        String model = System.getenv().getOrDefault("SPRING_AI_OPENAI_MODEL", "gpt-4o-mini");
        int promptTokens = estimateTokens(prompt);
        try {
            ChatClient.Builder builder = chatClientBuilderProvider.getIfAvailable();
            if (builder == null || !StringUtils.hasText(System.getenv("OPENAI_API_KEY"))) {
                log.info("OPENAI_CALL_SKIPPED callId={} operation={} reason={} promptTokensEstimated={} model={}", callId, operation, "OPENAI_API_KEY missing or ChatClient unavailable", promptTokens, model);
                return fallback;
            }
            Instant start = Instant.now();
            log.info("OPENAI_REQUEST callId={} operation={} model={} promptTokensEstimated={} promptChars={} prompt={}", callId, operation, model, promptTokens, prompt.length(), singleLine(prompt));
            String content = builder.build().prompt(prompt).call().content();
            long latencyMs = Duration.between(start, Instant.now()).toMillis();
            int responseTokens = estimateTokens(content);
            log.info("OPENAI_RESPONSE callId={} operation={} model={} latencyMs={} promptTokensEstimated={} responseTokensEstimated={} totalTokensEstimated={} responseChars={} response={}", callId, operation, model, latencyMs, promptTokens, responseTokens, promptTokens + responseTokens, content == null ? 0 : content.length(), singleLine(content));
            return StringUtils.hasText(content) ? content : fallback;
        } catch (Exception ex) {
            log.warn("OPENAI_CALL_FAILED callId={} operation={} model={} promptTokensEstimated={} error={}", callId, operation, model, promptTokens, ex.toString());
            return fallback;
        }
    }

    private int estimateTokens(String text) {
        if (text == null || text.isBlank()) return 0;
        return Math.max(1, (int) Math.ceil(text.length() / 4.0));
    }

    private String singleLine(String text) {
        if (text == null) return "";
        return text.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
    }

    private String compactEvidence(List<FileSummary> files) {
        return files.stream().limit(45)
                .map(f -> "PATH: " + f.path() + "\nLANG: " + f.language() + "\n" + abbreviate(f.preview(), 1800))
                .collect(Collectors.joining("\n---\n"));
    }

    private String fallbackOverview(String repoUrl, List<FileSummary> files, Map<String, Long> stats, ArchitectureGraph graph) {
        String topFiles = files.stream().limit(12).map(f -> "- `" + f.path() + "` — " + f.language()).collect(Collectors.joining("\n"));
        return """
                ## Repository overview

                This wiki was generated for `%s` using static repository inspection. For deeper explanations and more reliable reasoning, configure `OPENAI_API_KEY` so Live Docs Knowledge Hub can use Spring AI OpenAI ChatClient.

                ## Technology signal

                %s

                ## Architecture graph signal

                - Nodes: `%s`
                - Edges: `%s`
                - Node types: `%s`
                - Edge types: `%s`

                ## Important files sampled

                %s

                ## Initial reading path

                Start with configuration files, entry points, controllers/routes, service classes, and package/module boundaries. Then use the architecture graph and Q&A panel to ask targeted questions about flow, dependencies, and extension points.
                """.formatted(repoUrl, stats, graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats(), topFiles);
    }

    private String fallbackAnswer(String question, List<FileSummary> files, ArchitectureGraph graph) {
        String matches = files.stream().limit(8).map(f -> "- `" + f.path() + "`: " + abbreviate(f.preview().replace("\n", " "), 260)).collect(Collectors.joining("\n"));
        return """
                Live Docs Knowledge Hub is running in static-analysis fallback mode, so this answer is based on repository structure rather than full LLM reasoning.

                Question asked: **%s**

                Inspect these files first:

                %s

                Graph context: `%s` nodes and `%s` edges were detected. Use the Architecture Graph panel or MCP tool `repo.getDependencies` to inspect relationships.
                """.formatted(question, matches, graph.nodes().size(), graph.edges().size());
    }

    private String fallbackArchitecture(ArchitectureGraph graph) {
        return """
                ## Architecture summary

                Live Docs Knowledge Hub detected `%s` graph nodes and `%s` graph edges.

                ### Node types
                %s

                ### Edge types
                %s

                Use the interactive architecture graph to inspect controllers/routes, services, repositories, React components, and inferred runtime-flow edges.
                """.formatted(graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats());
    }

    private String fallbackWorkspaceSection(String title, List<WikiResponse> wikis) {
        String repos = wikis.stream().map(WikiResponse::repoUrl).collect(Collectors.joining(", "));
        String stats = wikis.stream().map(w -> "- `" + w.repoUrl() + "`: " + w.languageStats() + ", files=" + w.files().size() + ", symbols=" + w.symbols().size()).collect(Collectors.joining("\n"));
        return """
                ## %s

                OpenAI did not return generated content, so this section is based on indexed static evidence.

                Repositories: %s

                ### Indexed signals

                %s

                Re-index with a valid `OPENAI_API_KEY` to generate a richer explanation.
                """.formatted(title, repos, stats);
    }

    private String fallbackWorkspaceArchitecture(List<WikiResponse> wikis) {
        String graph = wikis.stream().map(w -> "- `" + w.repoUrl() + "`: nodes=" + w.architectureGraph().nodes().size() + ", edges=" + w.architectureGraph().edges().size() + ", nodeTypes=" + w.architectureGraph().nodeTypeStats()).collect(Collectors.joining("\n"));
        return """
                ## Architecture

                OpenAI did not return generated content. Static evidence was still indexed.

                ### Graph evidence

                %s

                ### PUML

                ```puml
                @startuml
                title Workspace architecture evidence unavailable for full PUML generation
                note "Re-index with OpenAI enabled to generate a richer architecture narrative and PUML." as N1
                @enduml
                ```
                """.formatted(graph);
    }

    private String fallbackCodeInsights(List<WikiResponse> wikis) {
        String repos = wikis.stream().map(WikiResponse::repoUrl).collect(Collectors.joining(", "));
        String top = wikis.stream().flatMap(w -> w.files().stream()).limit(10).map(f -> "- `" + f.path() + "` — " + f.language()).collect(Collectors.joining("\n"));
        return """
                ## Summary

                **_This light tutorial could not be fully generated by OpenAI, so Live Docs Knowledge Hub is showing a static fallback from indexed evidence._** The workspace includes repositories: `%s`. Start by reading the entry point, configuration, controllers/routes, services, and domain/model files.

                ## Architecture

                ```mermaid
                flowchart TD
                  Repo[Repository Evidence] --> Entry[Entry Points]
                  Entry --> Config[Configuration]
                  Entry --> Logic[Core Logic]
                  Logic --> Data[Data / Integration]
                ```

                ## Table of Contents

                1. 01_repository_evidence.md
                2. 02_core_logic.md

                ## 01_repository_evidence.md

                ### The Hook
                Think of the repository as a building. The README, configs, and entry points are the map at the entrance.

                ### The Use Case
                This chapter helps a new developer find where to start.

                ### Code Walkthrough

                ```text
                %s
                ```

                ### Under the Hood

                ```mermaid
                sequenceDiagram
                  participant Dev
                  participant Repo
                  participant Entry
                  Dev->>Repo: Open indexed files
                  Repo->>Entry: Identify startup and config
                ```

                ### Navigation
                Previous Chapter: Start · Next Chapter: 02_core_logic.md

                ## 02_core_logic.md

                ### The Hook
                Core logic is like the kitchen in a restaurant: requests come in, rules are applied, and outputs are prepared.

                ### The Use Case
                This chapter helps connect controllers/routes to services, repositories, or integrations.

                ### Code Walkthrough

                ```text
                // Re-index with OPENAI_API_KEY for richer code snippets.
                // Static fallback uses indexed source evidence only.
                ```

                ### Under the Hood

                ```mermaid
                sequenceDiagram
                  participant Request
                  participant Entry
                  participant Service
                  Request->>Entry: Invoke entry point
                  Entry->>Service: Delegate business logic
                ```

                ### Navigation
                Previous Chapter: 01_repository_evidence.md · Next Chapter: End
                """.formatted(repos, top.replace("`", ""));
    }

    private String fallbackDesignElevation(List<WikiResponse> wikis) {
        String repos = wikis.stream().map(WikiResponse::repoUrl).collect(Collectors.joining(", "));
        String signals = wikis.stream().map(w -> "- `" + w.repoUrl() + "`: nodeTypes=" + w.architectureGraph().nodeTypeStats() + ", edgeTypes=" + w.architectureGraph().edgeTypeStats()).collect(Collectors.joining("\n"));
        return """
                ## Design Patterns Already Present

                OpenAI did not return generated content. Static graph evidence suggests these repositories may contain layered or component-based structures, but exact design patterns require deeper analysis.

                ## Design Patterns Recommended

                - Repository Pattern: consider where persistence access is present.
                - Adapter Pattern: consider for external API, Kafka, MQ, or legacy integrations.
                - Facade/Application Service: consider where multiple domain operations must be coordinated.

                ## Design Smells

                - Insufficient evidence for authoritative smell classification. Re-index with `OPENAI_API_KEY` enabled for a deeper senior-architect assessment.

                ## Code Smells

                - Insufficient evidence for authoritative code smell classification from static fallback alone.

                ## Senior Architect Priorities

                Repositories: %s

                Evidence signals:
                %s
                """.formatted(repos, signals);
    }

    private String abbreviate(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max) + "…";
    }
}
