package com.company.workforce.fulfilment.service;

import com.company.workforce.fulfilment.service.model.IntentDefinition;
import com.company.workforce.fulfilment.service.model.IntentTaxonomyContext;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.StringJoiner;

@Service
public class PromptBuilderService {

    private final ZoneId singaporeZoneId = ZoneId.of("Asia/Singapore");

    public ZoneId getSingaporeZoneId() {
        return singaporeZoneId;
    }

    public String buildSystemPrompt(IntentTaxonomyContext context, ZonedDateTime singaporeNow) {
        StringJoiner intentJoiner = new StringJoiner("\n\n");
        for (IntentDefinition intent : context.intents()) {
            intentJoiner.add("""
Intent: %s
Description: %s
Synonyms: %s
Entity hints: %s
Rules: %s
Examples: %s
""".formatted(
                    intent.intent(),
                    intent.description(),
                    intent.synonyms(),
                    intent.entityHints(),
                    intent.rules(),
                    intent.examples()
            ));
        }

        return """
You are an enterprise intent and entity extraction engine.

Your job is to read a user utterance and return ONLY strict JSON.

Use the supplied current Singapore date/time as the temporal reference.
You must dynamically resolve relative dates such as today, tomorrow, next monday, next week, 3 days from now, next friday, end of month, and similar expressions.
Do not ask follow-up questions.
Do not explain.
Do not return markdown.
Do not wrap the JSON in code fences.

Current Singapore date-time:
%s

Domain:
%s

Global rules:
%s

Candidate intents and contextual guidance:
%s

Return JSON with this exact shape:
{
  "intent": "UPPER_SNAKE_CASE_INTENT",
  "entities": {
    "dates": [
      {
        "expression": "string",
        "resolved_date": "YYYY-MM-DD",
        "role": "string"
      }
    ],
    "numbers": [
      {
        "value": number,
        "role": "string"
      }
    ],
    "people": [],
    "locations": [],
    "documents": [],
    "systems": [],
    "custom": {}
  },
  "confidence": number,
  "notes": ["..."]
}

Rules:
- Infer the most likely business intent from the candidate intents and context.
- Resolve dates using the supplied current Singapore date-time.
- If the utterance contains a duration such as "for 3 days", keep that in entities.numbers with role "duration_days".
- If the utterance contains a start date phrase such as "next monday", keep that in entities.dates with a role like "start_date".
- Put domain-specific fields that do not fit the generic slots inside entities.custom.
- Keep confidence between 0 and 1.
- Output valid JSON only.
""".formatted(singaporeNow, context.domain(), context.globalRules(), intentJoiner);
    }
}
