package com.example.mcpgithub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McpGithubToolApplication {
  public static void main(String[] args) {
    SpringApplication.run(McpGithubToolApplication.class, args);
  }
}
