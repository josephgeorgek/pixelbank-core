package com.ocbc.staff.orchestrator.graph;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GraphNodeDefinition {
    private String id;
    private String type;
    private String taskType;
    private String delegateTo;
    private Map<String, Object> config = new LinkedHashMap<>();
    private ErrorHandlerDefinition onError;
    private List<TransitionDefinition> transitions = new ArrayList<>();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getTaskType() { return taskType; }
    public void setTaskType(String taskType) { this.taskType = taskType; }
    public String getDelegateTo() { return delegateTo; }
    public void setDelegateTo(String delegateTo) { this.delegateTo = delegateTo; }
    public Map<String, Object> getConfig() { return config; }
    public void setConfig(Map<String, Object> config) { this.config = config; }
    public ErrorHandlerDefinition getOnError() { return onError; }
    public void setOnError(ErrorHandlerDefinition onError) { this.onError = onError; }
    public List<TransitionDefinition> getTransitions() { return transitions; }
    public void setTransitions(List<TransitionDefinition> transitions) { this.transitions = transitions; }
}
