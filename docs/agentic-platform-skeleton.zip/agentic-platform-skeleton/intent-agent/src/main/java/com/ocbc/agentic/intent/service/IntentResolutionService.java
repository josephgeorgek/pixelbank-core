package com.ocbc.agentic.intent.service;

import com.ocbc.agentic.common.model.IntentResolution;
import com.ocbc.agentic.common.model.UserRequest;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class IntentResolutionService {

    public IntentResolution resolve(UserRequest request) {
        // TODO: retrieve intent taxonomy context from ms-workforce-knowledgebase,
        // then use Spring AI advisor chain + LLM confirmation.
        return new IntentResolution(
                "HOTDESK_BOOKING",
                Map.of("location", "OCBC Changi", "date", "2026-03-18", "timeSlot", "MORNING"),
                "ms-workplace-booking",
                "book_hot_desk_v1",
                0.93,
                true
        );
    }
}
