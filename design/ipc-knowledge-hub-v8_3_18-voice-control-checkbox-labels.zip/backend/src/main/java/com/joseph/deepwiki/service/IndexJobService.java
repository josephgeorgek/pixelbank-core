package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.*;

@Service
public class IndexJobService {
    private final WikiGenerationService wikiGenerationService;
    private final PersistenceService persistenceService;
    private final ExecutorService executor = Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors() / 2));
    private final Map<String, MutableJob> jobs = new ConcurrentHashMap<>();

    public IndexJobService(WikiGenerationService wikiGenerationService, PersistenceService persistenceService) {
        this.wikiGenerationService = wikiGenerationService;
        this.persistenceService = persistenceService;
    }

    public IndexJobResponse start(GenerateWikiRequest request) {
        String jobId = UUID.randomUUID().toString();
        MutableJob job = new MutableJob(jobId);
        jobs.put(jobId, job);
        persistenceService.saveJob(jobId, "WIKI", job.status, job.stage, job.progress, job.message, null, null, null, job.createdAt, job.updatedAt);
        executor.submit(() -> run(job, request));
        return new IndexJobResponse(jobId, "/api/wiki/jobs/" + jobId);
    }

    public IndexJobStatus get(String jobId) {
        MutableJob job = jobs.get(jobId);
        if (job == null) throw new NoSuchElementException("Index job not found: " + jobId);
        return job.toStatus();
    }

    private void run(MutableJob job, GenerateWikiRequest request) {
        try {
            job.update("RUNNING", "CLONING", 15, "Cloning repository"); persist(job);
            job.update("RUNNING", "INDEXING", 35, "Scanning files, chunking code, extracting symbols, and building graph"); persist(job);
            WikiResponse wiki = wikiGenerationService.generate(request);
            job.wiki = wiki;
            job.wikiId = wiki.id();
            job.update("READY", "READY", 100, "Repository wiki, search index, citations, and graph are ready"); persist(job);
        } catch (Exception e) {
            job.error = e.getMessage() == null ? e.toString() : e.getMessage();
            job.update("FAILED", "FAILED", 100, job.error); persist(job);
        }
    }

    private void persist(MutableJob job) {
        persistenceService.saveJob(job.jobId, "WIKI", job.status, job.stage, job.progress, job.message, job.wikiId, null, job.error, job.createdAt, job.updatedAt);
    }

    private static class MutableJob {
        final String jobId;
        final Instant createdAt = Instant.now();
        volatile Instant updatedAt = Instant.now();
        volatile String status = "QUEUED";
        volatile String stage = "QUEUED";
        volatile int progress = 5;
        volatile String message = "Queued";
        volatile String wikiId;
        volatile WikiResponse wiki;
        volatile String error;

        MutableJob(String jobId) { this.jobId = jobId; }
        void update(String status, String stage, int progress, String message) {
            this.status = status; this.stage = stage; this.progress = progress; this.message = message; this.updatedAt = Instant.now();
        }
        IndexJobStatus toStatus() {
            return new IndexJobStatus(jobId, status, stage, progress, message, wikiId, wiki, error, createdAt, updatedAt);
        }
    }
}
