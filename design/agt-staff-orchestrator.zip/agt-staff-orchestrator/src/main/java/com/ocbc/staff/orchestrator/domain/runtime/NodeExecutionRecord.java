package com.ocbc.staff.orchestrator.domain.runtime;

import java.time.Instant;
import java.util.Map;

public record NodeExecutionRecord(
        String nodeId,
        String nodeType,
        String taskType,
        String delegateTo,
        NodeExecutionStatus status,
        Map<String, Object> input,
        Map<String, Object> output,
        String selectedNextNode,
        String errorMessage,
        Instant startedAt,
        Instant endedAt,
        long elapsedMs
) {
}
