package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class KeyContributorService {
    public List<KeyContributor> topContributors(List<PullRequestReviewer> reviewers, List<CommitHighlight> commits) {
        Map<String, ContributorScore> scores = new LinkedHashMap<>();
        for (PullRequestReviewer r : reviewers) add(scores, r.reviewer(), r.repo(), "REVIEWER", 2);
        for (CommitHighlight c : commits) add(scores, c.author(), c.repo(), "COMMIT_AUTHOR", 1);
        return scores.values().stream()
                .sorted(Comparator.comparingInt(ContributorScore::score).reversed().thenComparing(ContributorScore::name))
                .limit(5)
                .map(s -> new KeyContributor(s.name(), s.repoName(), s.sourceType()))
                .toList();
    }

    private void add(Map<String, ContributorScore> scores, String name, String repo, String type, int weight) {
        String n = Optional.ofNullable(name).orElse("").trim();
        if (n.isBlank() || "unknown".equalsIgnoreCase(n)) return;
        String key = n.toLowerCase(Locale.ROOT);
        scores.compute(key, (k, existing) -> existing == null
                ? new ContributorScore(n, repo, type, weight)
                : existing.add(type, weight));
    }

    private record ContributorScore(String name, String repoName, String sourceType, int score) {
        ContributorScore add(String type, int weight) {
            String mergedType = sourceType.equals(type) ? sourceType : "MIXED";
            return new ContributorScore(name, repoName, mergedType, score + weight);
        }
    }
}
