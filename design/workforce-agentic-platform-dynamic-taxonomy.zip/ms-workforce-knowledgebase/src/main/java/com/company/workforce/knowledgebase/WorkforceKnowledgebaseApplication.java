package com.company.workforce.knowledgebase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkforceKnowledgebaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(WorkforceKnowledgebaseApplication.class, args);
    }
}
