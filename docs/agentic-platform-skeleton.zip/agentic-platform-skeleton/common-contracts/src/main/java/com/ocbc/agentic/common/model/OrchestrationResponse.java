package com.ocbc.agentic.common.model;

import java.util.Map;

public record OrchestrationResponse(
        String requestId,
        String status,
        String message,
        Map<String, Object> data) {
}
