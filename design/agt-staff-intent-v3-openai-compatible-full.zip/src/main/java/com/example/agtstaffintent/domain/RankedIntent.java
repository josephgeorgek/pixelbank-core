package com.example.agtstaffintent.domain;

import java.util.List;

public record RankedIntent(
        IntentTaxonomy taxonomy,
        double score,
        List<String> matchedSignals,
        List<String> rejectedSignals
) {
}
