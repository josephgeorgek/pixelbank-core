package com.joseph.deepwiki.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "index_jobs")
public class IndexJobEntity {
    @Id public String jobId;
    public String jobType;
    public String status;
    public String stage;
    public int progress;
    @Lob @Column(columnDefinition = "CLOB") public String message;
    public String wikiId;
    public String workspaceId;
    @Lob @Column(columnDefinition = "CLOB") public String error;
    public Instant createdAt;
    public Instant updatedAt;
    public IndexJobEntity() {}
}
