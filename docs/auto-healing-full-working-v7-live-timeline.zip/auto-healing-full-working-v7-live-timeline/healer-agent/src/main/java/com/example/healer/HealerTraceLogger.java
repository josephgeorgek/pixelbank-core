package com.example.healer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HealerTraceLogger {
  private static final Logger log = LoggerFactory.getLogger("HEALER_TRACE");

  private HealerTraceLogger() {}

  public static void step(String stage, String message) {
    log.info("[{}] {}", stage, message);
  }

  public static void payload(String stage, String payload) {
    log.info("[{}][PAYLOAD]\n{}", stage, payload);
  }

  public static void error(String stage, String message, Throwable t) {
    log.error("[{}] {}", stage, message, t);
  }
}
