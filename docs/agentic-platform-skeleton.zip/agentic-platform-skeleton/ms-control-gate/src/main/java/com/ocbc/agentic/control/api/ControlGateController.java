package com.ocbc.agentic.control.api;

import com.ocbc.agentic.common.model.EntitlementDecision;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/control")
public class ControlGateController {

    @PostMapping("/entitlements/check")
    public EntitlementDecision check(@RequestBody Map<String, Object> request) {
        String serviceCode = (String) request.getOrDefault("serviceCode", "UNKNOWN");
        return new EntitlementDecision(true, serviceCode, "Allowed by skeleton rule");
    }
}
