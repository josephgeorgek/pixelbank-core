package com.ocbc.staff.orchestrator.service;

import com.jayway.jsonpath.JsonPath;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MappingResolverService {

    @SuppressWarnings("unchecked")
    public Map<String, Object> resolveMap(Map<String, Object> mapping, WorkflowState state) {
        Map<String, Object> resolved = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : mapping.entrySet()) {
            resolved.put(entry.getKey(), resolveValue(entry.getValue(), state));
        }
        return resolved;
    }

    @SuppressWarnings("unchecked")
    public Object resolveValue(Object value, WorkflowState state) {
        if (value instanceof String str) {
            if (str.startsWith("$.")) {
                try {
                    return JsonPath.read(state.asMap(), str);
                } catch (Exception e) {
                    return null;
                }
            }
            return str;
        }
        if (value instanceof Map<?, ?> mapValue) {
            Map<String, Object> nested = new LinkedHashMap<>();
            mapValue.forEach((k, v) -> nested.put(String.valueOf(k), resolveValue(v, state)));
            return nested;
        }
        if (value instanceof List<?> listValue) {
            List<Object> nested = new ArrayList<>();
            for (Object item : listValue) {
                nested.add(resolveValue(item, state));
            }
            return nested;
        }
        return value;
    }
}
