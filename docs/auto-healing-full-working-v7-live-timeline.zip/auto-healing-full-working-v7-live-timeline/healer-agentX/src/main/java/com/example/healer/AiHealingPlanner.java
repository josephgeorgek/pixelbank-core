package com.example.healer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AiHealingPlanner {
  private static final Logger log = LoggerFactory.getLogger(AiHealingPlanner.class);

  private final ChatClient chatClient;
  private final SkillLoader skillLoader;
  private final String apiKey;

  public AiHealingPlanner(ChatClient.Builder builder, SkillLoader skillLoader,
                          @Value("${spring.ai.openai.api-key:}") String apiKey) {
    this.chatClient = builder.build();
    this.skillLoader = skillLoader;
    this.apiKey = apiKey;
  }

  public String createPlan(String error, String repoUrl) {
    if (apiKey == null || apiKey.isBlank()) {
      log.warn("[AI] OPENAI_API_KEY missing. Using deterministic fallback plan.");
      return fallbackPlan(error);
    }

    String skill = skillLoader.loadAutoHealingSkill();

    return chatClient.prompt()
      .system("""
        You are healer-agent.
        Follow SKILL.md exactly.
        Return JSON only.
        Do not directly modify production.
        Do not invent business values.
        If uncertain, use REVIEW_REQUIRED.
        """)
      .user("""
        SKILL.md:
        %s

        Runtime Error:
        %s

        Repository:
        %s

        Create a generic healing plan.
        """.formatted(skill, error, repoUrl))
      .call()
      .content();
  }

  private String fallbackPlan(String error) {
    return """
      {
        "classification": "PAYMENT_DEFAULT_CONFIG_DATA_GAP",
        "rootCause": "Runtime failure indicates a missing default/config/reference value. AI fallback used because OPENAI_API_KEY is not configured.",
        "confidence": 0.60,
        "proposedFixType": "REFERENCE_DATA_PATCH",
        "filesToChange": ["db/migration/V20260425__swift_fee.sql"],
        "patchContent": "INSERT INTO payment_fee_config(transaction_type, fee_rate, status, created_at) VALUES ('SWIFT_INTL', REVIEW_REQUIRED, 'ACTIVE', CURRENT_TIMESTAMP);",
        "testPlan": ["Replay failed transaction", "Verify exception is resolved", "Verify calculation after reviewer confirms fee value"],
        "rollbackPlan": "DELETE FROM payment_fee_config WHERE transaction_type = 'SWIFT_INTL';",
        "requiresHumanApproval": true
      }
      """;
  }
}
