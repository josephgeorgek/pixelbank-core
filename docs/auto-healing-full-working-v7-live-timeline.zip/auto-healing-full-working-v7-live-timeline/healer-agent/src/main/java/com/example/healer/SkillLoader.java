package com.example.healer;

import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;

@Service
public class SkillLoader {
  public String loadAutoHealingSkill() {
    try (var in = getClass().getResourceAsStream("/skills/auto-healing/SKILL.md")) {
      if (in == null) {
        throw new IllegalStateException("SKILL.md not found at /skills/auto-healing/SKILL.md");
      }
      String skill = new String(in.readAllBytes(), StandardCharsets.UTF_8);
      HealerTraceLogger.step("SKILL_LOAD", "Loaded Auto-Healing SKILL.md, length=" + skill.length());
      return skill;
    } catch (Exception e) {
      throw new IllegalStateException("Unable to load Auto-Healing SKILL.md", e);
    }
  }
}
