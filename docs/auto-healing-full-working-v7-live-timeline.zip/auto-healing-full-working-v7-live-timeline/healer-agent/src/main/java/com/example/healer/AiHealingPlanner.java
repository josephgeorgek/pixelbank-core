package com.example.healer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AiHealingPlanner {

    private final ChatClient chatClient;
    private final SkillLoader skillLoader;
    private final ObjectMapper objectMapper;
    private final String apiKey;
    private final String model;

    public AiHealingPlanner(ChatClient.Builder builder,
                           SkillLoader skillLoader,
                           ObjectMapper objectMapper,
                           @Value("${spring.ai.openai.api-key:dummy}") String apiKey,
                           @Value("${spring.ai.openai.chat.options.model:gpt-4.1-mini}") String model) {

        this.chatClient = builder.build();
        this.skillLoader = skillLoader;
        this.objectMapper = objectMapper;
        this.apiKey = apiKey;
        this.model = model;
    }

    public AiPlanResult createPlan(String error, String repoUrl, String service, String transactionType) {

        HealerTraceLogger.step("AI_START", "Preparing AI analysis");

        String skill = skillLoader.loadAutoHealingSkill();
        String prompt = buildPrompt(skill, error, repoUrl, service, transactionType);

        HealerTraceLogger.payload("AI_REQUEST", prompt);

        // 🔴 Fallback if no API key
        if (apiKey == null || apiKey.isBlank() || "dummy".equalsIgnoreCase(apiKey)) {
            HealerTraceLogger.step("AI_FALLBACK", "No API key. Using deterministic plan");
            String fallback = fallbackPlan(error, service, transactionType);
            HealerTraceLogger.payload("AI_RESPONSE_FALLBACK", fallback);
            return new AiPlanResult(prompt, fallback, buildRationale(fallback));
        }

        try {
            String response = chatClient.prompt()
                    .system("You are healer-agent. Follow SKILL.md strictly. Return JSON only.")
                    .user(prompt)
                    .call()
                    .content();

            HealerTraceLogger.payload("AI_RESPONSE", response);

            return new AiPlanResult(prompt, response, buildRationale(response));

        } catch (Exception e) {
            HealerTraceLogger.error("AI_ERROR", "AI call failed. Using fallback.", e);
            String fallback = fallbackPlan(error, service, transactionType);
            return new AiPlanResult(prompt, fallback, buildRationale(fallback));
        }
    }

    private String buildPrompt(String skill, String error, String repoUrl, String service, String transactionType) {

        StringBuilder sb = new StringBuilder();

        sb.append("SKILL:\n").append(skill).append("\n\n");
        sb.append("Evidence:\n");
        sb.append("service=").append(nvl(service)).append("\n");
        sb.append("transactionType=").append(nvl(transactionType)).append("\n");
        sb.append("error=").append(nvl(error)).append("\n");
        sb.append("repo=").append(nvl(repoUrl)).append("\n\n");

        sb.append("Task:\n");
        sb.append("Analyze failure and produce JSON healing plan.\n");

        return sb.toString();
    }

    private String fallbackPlan(String error, String service, String transactionType) {

        Map<String, Object> rootCause = new HashMap<>();
        rootCause.put("summary", "Fallback analysis due to missing AI");
        rootCause.put("technicalCause", "Unknown failure");
        rootCause.put("businessImpact", "Potential transaction failure");
        rootCause.put("confidence", 0.5);
        rootCause.put("evidence", List.of(nvl(error)));

        Map<String, Object> proposedFix = new HashMap<>();
        proposedFix.put("fixType", "REVIEW_REQUIRED");
        proposedFix.put("filesToChange", List.of("manual-review.md"));
        proposedFix.put("patchContent", "REVIEW_REQUIRED");
        proposedFix.put("requiresBusinessValueReview", true);
        proposedFix.put("unknowns", List.of("root cause", "safe fix"));

        Map<String, Object> plan = new HashMap<>();

        plan.put("service", nvl(service));
        plan.put("environment", "healing-zone");
        plan.put("errorSignature", "RUNTIME_FAILURE");
        plan.put("classification", "UNKNOWN_REQUIRES_INVESTIGATION");
        plan.put("rootCause", rootCause);
        plan.put("proposedFix", proposedFix);

        plan.put("testPlan", List.of(
                "Replay request",
                "Validate error",
                "Apply fix in pre-prod"
        ));

        plan.put("rollbackPlan", "Revert PR");
        plan.put("riskLevel", "MEDIUM");
        plan.put("requiresHumanApproval", true);
        plan.put("shouldCreatePr", true);
        plan.put("shouldAutoApply", false);

        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(plan);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private String buildRationale(String json) {

        if (json == null) return "No AI response";

        if (json.contains("CONFIG")) return "Detected config-related issue";
        if (json.contains("REFERENCE")) return "Reference data gap identified";

        return "Generic fallback reasoning applied";
    }

    private String nvl(String v) {
        return v == null ? "" : v;
    }
}