package com.ocbc.agentic.gateway.api;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/gateway")
public class DomainGatewayController {

    @PostMapping("/domain")
    public Map<String, Object> invoke(@RequestBody Map<String, Object> request) {
        return Map.of(
                "status", "BOOKED",
                "bookingId", "HD-20260318-0001",
                "seatNumber", "C-12-08",
                "echo", request
        );
    }
}
