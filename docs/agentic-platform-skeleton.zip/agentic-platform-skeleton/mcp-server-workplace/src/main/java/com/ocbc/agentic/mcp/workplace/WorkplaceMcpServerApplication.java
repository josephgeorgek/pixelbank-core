package com.ocbc.agentic.mcp.workplace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkplaceMcpServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(WorkplaceMcpServerApplication.class, args);
    }
}
