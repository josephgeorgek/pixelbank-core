package com.ocbc.staff.orchestrator.graph;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GraphDefinition {
    private String graphId;
    private String version;
    private String description;
    private String entryNode;
    private List<String> finishNodes = new ArrayList<>();
    private Map<String, Object> metadata = new LinkedHashMap<>();
    private List<GraphNodeDefinition> nodes = new ArrayList<>();

    public String getGraphId() { return graphId; }
    public void setGraphId(String graphId) { this.graphId = graphId; }
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getEntryNode() { return entryNode; }
    public void setEntryNode(String entryNode) { this.entryNode = entryNode; }
    public List<String> getFinishNodes() { return finishNodes; }
    public void setFinishNodes(List<String> finishNodes) { this.finishNodes = finishNodes; }
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    public List<GraphNodeDefinition> getNodes() { return nodes; }
    public void setNodes(List<GraphNodeDefinition> nodes) { this.nodes = nodes; }
}
