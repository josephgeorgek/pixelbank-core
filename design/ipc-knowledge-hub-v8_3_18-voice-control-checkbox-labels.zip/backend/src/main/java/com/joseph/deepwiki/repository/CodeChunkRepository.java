package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.CodeChunkEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CodeChunkRepository extends JpaRepository<CodeChunkEntity, String> { void deleteByWikiId(String wikiId); long countByWikiId(String wikiId); }
