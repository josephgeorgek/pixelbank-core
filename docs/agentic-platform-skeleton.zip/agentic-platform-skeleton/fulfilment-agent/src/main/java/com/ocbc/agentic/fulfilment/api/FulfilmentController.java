package com.ocbc.agentic.fulfilment.api;

import com.ocbc.agentic.common.model.OrchestrationResponse;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/fulfilment")
public class FulfilmentController {

    @PostMapping("/execute")
    public OrchestrationResponse execute(@RequestBody Map<String, Object> payload) {
        // TODO: call MCP server, retrieve context, invoke ms-gateway, and format domain result.
        return new OrchestrationResponse(
                (String) payload.getOrDefault("requestId", "n/a"),
                "SUCCESS",
                "Fulfilment skeleton executed",
                payload
        );
    }
}
