package com.ocbc.staff.orchestrator.domain.runtime;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("unchecked")
public class WorkflowState {

    private String executionId;
    private String graphId;
    private String graphVersion;
    private WorkflowExecutionStatus status;
    private String currentNodeId;
    private Map<String, Object> input = new LinkedHashMap<>();
    private Map<String, Object> intentResult = new LinkedHashMap<>();
    private Map<String, Object> taskResults = new LinkedHashMap<>();
    private Map<String, Object> finalOutput = new LinkedHashMap<>();
    private List<NodeExecutionRecord> auditTrail = new ArrayList<>();
    private List<Map<String, Object>> errors = new ArrayList<>();
    private Instant startedAt;
    private Instant updatedAt;
    private Instant completedAt;

    public Map<String, Object> asMap() {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("executionId", executionId);
        root.put("graphId", graphId);
        root.put("graphVersion", graphVersion);
        root.put("status", status != null ? status.name() : null);
        root.put("currentNodeId", currentNodeId);
        root.put("input", input);
        root.put("intentResult", intentResult);
        root.put("taskResults", taskResults);
        root.put("finalOutput", finalOutput);
        root.put("errors", errors);
        root.put("startedAt", startedAt != null ? startedAt.toString() : null);
        root.put("updatedAt", updatedAt != null ? updatedAt.toString() : null);
        root.put("completedAt", completedAt != null ? completedAt.toString() : null);
        return root;
    }

    public void putTaskResult(String key, Object value) {
        taskResults.put(key, value);
    }

    public void addError(String nodeId, String message) {
        Map<String, Object> error = new LinkedHashMap<>();
        error.put("nodeId", nodeId);
        error.put("message", message);
        error.put("at", Instant.now().toString());
        errors.add(error);
    }

    public void addAudit(NodeExecutionRecord record) {
        auditTrail.add(record);
    }

    public List<NodeExecutionRecord> getAuditTrail() {
        return auditTrail;
    }

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getGraphId() {
        return graphId;
    }

    public void setGraphId(String graphId) {
        this.graphId = graphId;
    }

    public String getGraphVersion() {
        return graphVersion;
    }

    public void setGraphVersion(String graphVersion) {
        this.graphVersion = graphVersion;
    }

    public WorkflowExecutionStatus getStatus() {
        return status;
    }

    public void setStatus(WorkflowExecutionStatus status) {
        this.status = status;
    }

    public String getCurrentNodeId() {
        return currentNodeId;
    }

    public void setCurrentNodeId(String currentNodeId) {
        this.currentNodeId = currentNodeId;
    }

    public Map<String, Object> getInput() {
        return input;
    }

    public void setInput(Map<String, Object> input) {
        this.input = input;
    }

    public Map<String, Object> getIntentResult() {
        return intentResult;
    }

    public void setIntentResult(Map<String, Object> intentResult) {
        this.intentResult = intentResult;
    }

    public Map<String, Object> getTaskResults() {
        return taskResults;
    }

    public Map<String, Object> getFinalOutput() {
        return finalOutput;
    }

    public void setFinalOutput(Map<String, Object> finalOutput) {
        this.finalOutput = finalOutput;
    }

    public List<Map<String, Object>> getErrors() {
        return errors;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Instant completedAt) {
        this.completedAt = completedAt;
    }
}
