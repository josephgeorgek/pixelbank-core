package com.ocbc.staff.orchestrator.api;

import com.ocbc.staff.orchestrator.api.dto.ResumeWorkflowRequest;
import com.ocbc.staff.orchestrator.api.dto.StartWorkflowRequest;
import com.ocbc.staff.orchestrator.api.dto.StartWorkflowResponse;
import com.ocbc.staff.orchestrator.model.WorkflowEvent;
import com.ocbc.staff.orchestrator.model.WorkflowExecution;
import com.ocbc.staff.orchestrator.service.WorkflowApplicationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/workflows")
public class WorkflowController {
    private final WorkflowApplicationService workflowApplicationService;

    public WorkflowController(WorkflowApplicationService workflowApplicationService) {
        this.workflowApplicationService = workflowApplicationService;
    }

    @PostMapping("/start")
    public StartWorkflowResponse start(@Valid @RequestBody StartWorkflowRequest request) {
        return workflowApplicationService.start(request);
    }

    @PostMapping("/resume")
    public StartWorkflowResponse resume(@Valid @RequestBody ResumeWorkflowRequest request) {
        return workflowApplicationService.resume(request.getExecutionId());
    }

    @GetMapping("/{executionId}")
    public WorkflowExecution getStatus(@PathVariable String executionId) {
        return workflowApplicationService.getExecution(executionId);
    }

    @GetMapping("/{executionId}/state")
    public Map<String, Object> getState(@PathVariable String executionId) {
        return workflowApplicationService.getState(executionId);
    }

    @GetMapping("/{executionId}/events")
    public List<WorkflowEvent> getEvents(@PathVariable String executionId) {
        return workflowApplicationService.getEvents(executionId);
    }
}
