package com.joseph.deepwiki.controller;

import com.joseph.deepwiki.model.WikiModels.*;
import com.joseph.deepwiki.service.WorkspaceIndexJobService;
import com.joseph.deepwiki.service.WorkspaceService;
import com.joseph.deepwiki.service.PersistenceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/api/workspaces")
@CrossOrigin(origins = "*")
public class WorkspaceController {
    private final WorkspaceService workspaceService;
    private final WorkspaceIndexJobService workspaceIndexJobService;
    private final PersistenceService persistenceService;

    public WorkspaceController(WorkspaceService workspaceService, WorkspaceIndexJobService workspaceIndexJobService, PersistenceService persistenceService) {
        this.workspaceService = workspaceService;
        this.workspaceIndexJobService = workspaceIndexJobService;
        this.persistenceService = persistenceService;
    }

    @PostMapping("/index")
    public ResponseEntity<WorkspaceIndexJobResponse> index(@RequestBody MultiRepoIndexRequest request) {
        return ResponseEntity.accepted().body(workspaceIndexJobService.start(request));
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<WorkspaceIndexJobStatus> job(@PathVariable String jobId) {
        return ResponseEntity.ok(workspaceIndexJobService.get(jobId));
    }

    @PostMapping("/generate")
    public ResponseEntity<WorkspaceResponse> generate(@RequestBody MultiRepoIndexRequest request) {
        return ResponseEntity.ok(workspaceService.generate(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<WorkspaceResponse> get(@PathVariable String id) {
        return workspaceService.find(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/diagrams")
    public java.util.List<java.util.Map<String, Object>> diagrams(@PathVariable String id) { return persistenceService.diagramsForWorkspace(id); }

    @GetMapping
    public Collection<WorkspaceResponse> list() { return workspaceService.list(); }
}
