package com.ocbc.staff.orchestrator.api;

import com.ocbc.staff.orchestrator.api.dto.StartWorkflowRequest;
import com.ocbc.staff.orchestrator.api.dto.WorkflowExecutionResponse;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import com.ocbc.staff.orchestrator.service.WorkflowOrchestratorService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class WorkflowController {

    private final WorkflowOrchestratorService workflowOrchestratorService;

    public WorkflowController(WorkflowOrchestratorService workflowOrchestratorService) {
        this.workflowOrchestratorService = workflowOrchestratorService;
    }

    @PostMapping("/v1/workflows/start")
    public WorkflowExecutionResponse start(@Valid @RequestBody StartWorkflowRequest request) {
        WorkflowState state = workflowOrchestratorService.start(request);
        return new WorkflowExecutionResponse(
                state.getExecutionId(),
                state.getGraphId(),
                state.getStatus().name(),
                state.getCurrentNodeId(),
                state.getFinalOutput()
        );
    }

    @GetMapping("/v1/workflows/{executionId}")
    public WorkflowExecutionResponse get(@PathVariable String executionId) {
        WorkflowState state = workflowOrchestratorService.get(executionId);
        return new WorkflowExecutionResponse(
                state.getExecutionId(),
                state.getGraphId(),
                state.getStatus().name(),
                state.getCurrentNodeId(),
                state.getFinalOutput()
        );
    }

    @GetMapping("/v1/workflows/{executionId}/state")
    public Map<String, Object> getState(@PathVariable String executionId) {
        return workflowOrchestratorService.get(executionId).asMap();
    }
}
