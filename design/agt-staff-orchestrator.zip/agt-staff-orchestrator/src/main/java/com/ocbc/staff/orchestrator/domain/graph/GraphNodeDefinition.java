package com.ocbc.staff.orchestrator.domain.graph;

import java.util.List;
import java.util.Map;

public record GraphNodeDefinition(
        String id,
        String type,
        String taskType,
        String delegateTo,
        Map<String, Object> config,
        String outputKey,
        ErrorHandlerDefinition onError,
        List<TransitionDefinition> transitions
) {
    public boolean isEndNode() {
        return "END".equalsIgnoreCase(type);
    }

    public boolean isTaskNode() {
        return "TASK".equalsIgnoreCase(type);
    }
}
