package com.ocbc.staff.orchestrator.domain.graph;

public record ErrorHandlerDefinition(
        String outputKey,
        String next
) {
}
