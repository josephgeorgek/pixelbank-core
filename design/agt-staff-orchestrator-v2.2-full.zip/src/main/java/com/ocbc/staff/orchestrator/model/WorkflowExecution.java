package com.ocbc.staff.orchestrator.model;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class WorkflowExecution {
    private String executionId;
    private String graphId;
    private String graphVersion;
    private WorkflowStatus status;
    private String currentNodeId;
    private Instant startedAt;
    private Instant updatedAt;
    private Instant completedAt;
    private Map<String, NodeStatus> nodeStatuses = new LinkedHashMap<>();
    private Map<String, Object> finalOutput = new LinkedHashMap<>();
    private String failureReason;

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getGraphId() {
        return graphId;
    }

    public void setGraphId(String graphId) {
        this.graphId = graphId;
    }

    public String getGraphVersion() {
        return graphVersion;
    }

    public void setGraphVersion(String graphVersion) {
        this.graphVersion = graphVersion;
    }

    public WorkflowStatus getStatus() {
        return status;
    }

    public void setStatus(WorkflowStatus status) {
        this.status = status;
    }

    public String getCurrentNodeId() {
        return currentNodeId;
    }

    public void setCurrentNodeId(String currentNodeId) {
        this.currentNodeId = currentNodeId;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Instant completedAt) {
        this.completedAt = completedAt;
    }

    public Map<String, NodeStatus> getNodeStatuses() {
        return nodeStatuses;
    }

    public void setNodeStatuses(Map<String, NodeStatus> nodeStatuses) {
        this.nodeStatuses = nodeStatuses;
    }

    public Map<String, Object> getFinalOutput() {
        return finalOutput;
    }

    public void setFinalOutput(Map<String, Object> finalOutput) {
        this.finalOutput = finalOutput;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }
}
