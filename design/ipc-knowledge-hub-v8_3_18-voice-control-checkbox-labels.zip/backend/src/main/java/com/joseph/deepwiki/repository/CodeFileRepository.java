package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.CodeFileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CodeFileRepository extends JpaRepository<CodeFileEntity, Long> { void deleteByWikiId(String wikiId); long countByWikiId(String wikiId); }
