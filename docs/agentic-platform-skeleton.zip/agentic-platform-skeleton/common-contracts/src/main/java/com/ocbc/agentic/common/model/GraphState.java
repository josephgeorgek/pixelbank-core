package com.ocbc.agentic.common.model;

import java.util.HashMap;
import java.util.Map;

public class GraphState {
    private final Map<String, Object> values = new HashMap<>();

    public GraphState put(String key, Object value) {
        values.put(key, value);
        return this;
    }

    public Object get(String key) {
        return values.get(key);
    }

    public Map<String, Object> asMap() {
        return values;
    }
}
