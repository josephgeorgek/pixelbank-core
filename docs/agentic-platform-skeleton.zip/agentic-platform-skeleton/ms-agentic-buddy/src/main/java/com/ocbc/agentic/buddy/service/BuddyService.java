package com.ocbc.agentic.buddy.service;

import com.ocbc.agentic.common.model.OrchestrationResponse;
import com.ocbc.agentic.common.model.UserRequest;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class BuddyService {

    public OrchestrationResponse handle(UserRequest request) {
        // TODO: enrich user context from ms-authorization and ms-staff-security,
        // then forward to agentic-orchestrator.
        return new OrchestrationResponse(
                request.sessionId(),
                "ACCEPTED",
                "Request accepted by ms-agentic-buddy",
                Map.of("text", request.text(), "userId", request.userId()));
    }
}
