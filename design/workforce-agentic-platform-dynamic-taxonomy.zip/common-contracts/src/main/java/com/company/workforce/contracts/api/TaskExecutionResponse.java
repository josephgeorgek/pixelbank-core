package com.company.workforce.contracts.api;

import com.company.workforce.contracts.enums.ExecutionStatus;
import java.util.Map;

public record TaskExecutionResponse(
        String executionId,
        String taskId,
        ExecutionStatus status,
        Map<String, Object> output,
        Map<String, Object> metadata,
        String error
) {
}
