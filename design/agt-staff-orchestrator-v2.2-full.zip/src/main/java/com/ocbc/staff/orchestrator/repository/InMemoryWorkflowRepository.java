package com.ocbc.staff.orchestrator.repository;

import com.ocbc.staff.orchestrator.model.WorkflowEvent;
import com.ocbc.staff.orchestrator.model.WorkflowExecution;
import com.ocbc.staff.orchestrator.model.WorkflowState;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryWorkflowRepository {
    private final Map<String, WorkflowExecution> executions = new ConcurrentHashMap<>();
    private final Map<String, WorkflowState> states = new ConcurrentHashMap<>();
    private final Map<String, List<WorkflowEvent>> events = new ConcurrentHashMap<>();

    public void saveExecution(WorkflowExecution execution) { executions.put(execution.getExecutionId(), execution); }
    public WorkflowExecution getExecution(String executionId) { return executions.get(executionId); }
    public void saveState(WorkflowState state) { states.put(state.getExecutionId(), state); }
    public WorkflowState getState(String executionId) { return states.get(executionId); }
    public void addEvent(String executionId, WorkflowEvent event) { events.computeIfAbsent(executionId, key -> new ArrayList<>()).add(event); }
    public List<WorkflowEvent> getEvents(String executionId) { return events.getOrDefault(executionId, List.of()); }
}
