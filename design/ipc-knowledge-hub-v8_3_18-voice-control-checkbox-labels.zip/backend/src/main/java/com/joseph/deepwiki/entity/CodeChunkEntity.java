package com.joseph.deepwiki.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "code_chunks", indexes = @Index(name="idx_code_chunks_wiki", columnList="wikiId"))
public class CodeChunkEntity {
    @Id public String id;
    public String wikiId;
    @Column(length = 2000) public String path;
    public String language;
    public int startLine;
    public int endLine;
    @Lob @Column(columnDefinition = "CLOB") public String content;
    @Lob @Column(columnDefinition = "CLOB") public String symbolsText;
    public CodeChunkEntity() {}
}
