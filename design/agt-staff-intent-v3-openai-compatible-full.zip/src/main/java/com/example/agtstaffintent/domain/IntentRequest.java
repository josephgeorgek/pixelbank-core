package com.example.agtstaffintent.domain;

import jakarta.validation.constraints.NotBlank;

public record IntentRequest(
        @NotBlank String prompt,
        @NotBlank String userRole,
        String userId
) {
}
