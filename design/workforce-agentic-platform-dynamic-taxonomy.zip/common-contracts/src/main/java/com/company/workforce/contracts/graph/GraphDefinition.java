package com.company.workforce.contracts.graph;

import java.util.List;

public record GraphDefinition(
        String graphId,
        String intentId,
        String description,
        String startNode,
        String endNode,
        List<GraphNodeDefinition> nodes
) {
}
