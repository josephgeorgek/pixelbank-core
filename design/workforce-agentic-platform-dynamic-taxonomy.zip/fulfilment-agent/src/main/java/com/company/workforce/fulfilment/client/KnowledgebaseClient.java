package com.company.workforce.fulfilment.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component
public class KnowledgebaseClient {

    private final WebClient webClient;

    public KnowledgebaseClient(@Value("${services.knowledgebase.base-url}") String baseUrl) {
        this.webClient = WebClient.builder().baseUrl(baseUrl).build();
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> call(String endpoint, Map<String, Object> payload) {
        return webClient.post()
                .uri(endpoint)
                .bodyValue(payload)
                .retrieve()
                .bodyToMono(Map.class)
                .block();
    }
}
