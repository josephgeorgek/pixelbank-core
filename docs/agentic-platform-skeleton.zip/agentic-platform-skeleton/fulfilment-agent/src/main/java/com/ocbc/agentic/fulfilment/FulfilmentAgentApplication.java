package com.ocbc.agentic.fulfilment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FulfilmentAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(FulfilmentAgentApplication.class, args);
    }
}
