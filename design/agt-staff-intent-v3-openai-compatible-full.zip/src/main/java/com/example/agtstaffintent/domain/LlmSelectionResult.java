package com.example.agtstaffintent.domain;

import java.util.List;
import java.util.Map;

public record LlmSelectionResult(
        String selectedIntent,
        double confidence,
        String rationale,
        Map<String, Object> entities,
        List<ServiceCandidate> serviceCandidates
) {
}
