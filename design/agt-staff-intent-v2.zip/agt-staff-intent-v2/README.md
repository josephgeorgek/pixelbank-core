# agt-staff-intent v2

Spring AI based Spring Boot 3.5 / Java 21 intent discovery orchestrator.

## What changed in v2

- Added `UNKNOWN_OR_UNSUPPORTED_REQUEST` fallback intent.
- Added `STAFF_SELF_CASE_STATUS_TRACKING` taxonomy for issue / ticket / case status queries.
- Added required anchor keywords per taxonomy to stop generic terms like `status` and `my` from driving a wrong domain match.
- Added acronym / alias expansion for terms like `HIP`.
- Added stricter shortlist rules: minimum score + minimum matched signals.
- Updated LLM prompt so it can return `UNKNOWN_OR_UNSUPPORTED_REQUEST` instead of forcing a bad match.

## API

`POST /v1/intent/discover`

## Example request

```bash
curl --location 'http://localhost:8080/v1/intent/discover' \
--header 'Content-Type: application/json' \
--data '{
  "prompt": "Find out status for my HIP issue raised",
  "userRole": "Staff",
  "userId": "M12345",
  "locale": "en-SG"
}'
```

## Expected v2 behavior

- `HIP issue` should map to `STAFF_SELF_CASE_STATUS_TRACKING` when that taxonomy wins.
- If no supported taxonomy clears the threshold, the service returns `UNKNOWN_OR_UNSUPPORTED_REQUEST`.
- Medical leave intents now require medical/leave/certificate anchors before they can be shortlisted.

## Run

```bash
export OPENAI_API_KEY=<your-key>
mvn spring-boot:run
```

## Notes

- Similarity is still lightweight and deterministic. It is safer than v1, not magic.
- The correct next step is embedding-based retrieval plus rule-based reranking.
