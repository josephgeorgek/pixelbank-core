package com.company.workforce.orchestrator.loader;

import com.company.workforce.contracts.graph.GraphDefinition;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
public class GraphDefinitionLoader {

    private final ObjectMapper objectMapper;

    public GraphDefinitionLoader(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public GraphDefinition load(String intentId) {
        try {
            var resource = new ClassPathResource("graphs/" + intentId + ".json");
            return objectMapper.readValue(resource.getInputStream(), GraphDefinition.class);
        } catch (Exception e) {
            throw new IllegalArgumentException("Graph JSON not found or invalid for intent: " + intentId, e);
        }
    }
}
