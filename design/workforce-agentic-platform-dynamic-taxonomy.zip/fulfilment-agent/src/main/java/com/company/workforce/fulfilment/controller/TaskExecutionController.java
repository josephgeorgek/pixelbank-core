package com.company.workforce.fulfilment.controller;

import com.company.workforce.contracts.api.TaskExecutionRequest;
import com.company.workforce.contracts.api.TaskExecutionResponse;
import com.company.workforce.fulfilment.service.TaskExecutionService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/tasks")
public class TaskExecutionController {

    private final TaskExecutionService taskExecutionService;

    public TaskExecutionController(TaskExecutionService taskExecutionService) {
        this.taskExecutionService = taskExecutionService;
    }

    @PostMapping("/execute")
    public TaskExecutionResponse execute(@RequestBody TaskExecutionRequest request) {
        return taskExecutionService.execute(request);
    }
}
