package com.joseph.deepwiki.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Service
public class GitHubRepositorySearchService {
    private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String githubToken;

    public GitHubRepositorySearchService(@Value("${github.token:}") String configuredGithubToken) {
        String envToken = System.getenv("GITHUB_TOKEN");
        this.githubToken = StringUtils.hasText(configuredGithubToken) ? configuredGithubToken : envToken;
    }

    public SearchResponse search(String query) {
        if (!StringUtils.hasText(query)) {
            return new SearchResponse(0, 0, List.of(), "Enter a search term.");
        }
        try {
            String encoded = URLEncoder.encode(query.trim(), StandardCharsets.UTF_8);
            String url = "https://api.github.com/search/repositories?q=" + encoded + "&sort=stars&order=desc&per_page=3";
            HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(12))
                    .header("Accept", "application/vnd.github+json")
                    .header("X-GitHub-Api-Version", "2022-11-28")
                    .header("User-Agent", "ipc-knowledge-hub");
            if (StringUtils.hasText(githubToken)) builder.header("Authorization", "Bearer " + githubToken.trim());

            HttpResponse<String> response = httpClient.send(builder.GET().build(), HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                return new SearchResponse(0, response.statusCode(), List.of(), "GitHub search failed with HTTP " + response.statusCode());
            }
            JsonNode root = objectMapper.readTree(response.body());
            List<RepoResult> results = new ArrayList<>();
            JsonNode items = root.path("items");
            if (items.isArray()) {
                for (JsonNode item : items) {
                    List<String> topics = new ArrayList<>();
                    JsonNode topicNodes = item.path("topics");
                    if (topicNodes.isArray()) topicNodes.forEach(t -> topics.add(t.asText()));
                    results.add(new RepoResult(
                            item.path("full_name").asText(""),
                            item.path("html_url").asText(""),
                            item.path("description").asText(""),
                            item.path("language").asText(""),
                            item.path("stargazers_count").asLong(0),
                            item.path("forks_count").asLong(0),
                            item.path("updated_at").asText(""),
                            topics
                    ));
                }
            }
            return new SearchResponse(root.path("total_count").asLong(0), response.statusCode(), results, "");
        } catch (Exception e) {
            return new SearchResponse(0, 500, List.of(), "GitHub search failed: " + e.getMessage());
        }
    }

    public record SearchResponse(long totalCount, int statusCode, List<RepoResult> results, String message) {}
    public record RepoResult(String fullName, String htmlUrl, String description, String language, long stars, long forks, String updatedAt, List<String> topics) {}
}
