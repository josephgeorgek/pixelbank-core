package com.ocbc.staff.orchestrator.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ocbc.staff.orchestrator.domain.graph.GraphDefinition;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class GraphRegistryService {

    private final Map<String, GraphDefinition> graphs = new LinkedHashMap<>();

    public GraphRegistryService(ObjectMapper objectMapper, GraphValidationService validationService) throws IOException {
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources = resolver.getResources("classpath*:graphs/*.json");
        for (Resource resource : resources) {
            GraphDefinition graphDefinition = objectMapper.readValue(resource.getInputStream(), GraphDefinition.class);
            validationService.validate(graphDefinition);
            graphs.put(graphDefinition.graphId(), graphDefinition);
        }
    }

    public GraphDefinition require(String graphId) {
        GraphDefinition graph = graphs.get(graphId);
        if (graph == null) {
            throw new IllegalArgumentException("Unknown graphId: " + graphId);
        }
        return graph;
    }

    public Collection<GraphDefinition> findAll() {
        return graphs.values();
    }
}
