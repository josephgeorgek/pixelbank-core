package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.WikiEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface WikiRepository extends JpaRepository<WikiEntity, String> { List<WikiEntity> findByWorkspaceId(String workspaceId); }
