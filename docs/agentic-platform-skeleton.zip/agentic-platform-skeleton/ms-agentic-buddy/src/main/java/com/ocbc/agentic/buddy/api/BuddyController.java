package com.ocbc.agentic.buddy.api;

import com.ocbc.agentic.common.api.AgenticApiPaths;
import com.ocbc.agentic.common.model.OrchestrationResponse;
import com.ocbc.agentic.common.model.UserRequest;
import com.ocbc.agentic.buddy.service.BuddyService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(AgenticApiPaths.BUDDY)
public class BuddyController {
    private final BuddyService buddyService;

    public BuddyController(BuddyService buddyService) {
        this.buddyService = buddyService;
    }

    @PostMapping("/requests")
    public OrchestrationResponse submit(@Valid @RequestBody UserRequest request) {
        return buddyService.handle(request);
    }
}
