package com.ocbc.staff.orchestrator.service;

import java.util.Map;

public interface DelegateTaskClient {
    Map<String, Object> invoke(String delegateTo, String taskType, Map<String, Object> payload);
}
