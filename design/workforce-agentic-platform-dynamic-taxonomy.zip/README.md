# Workforce Agentic Platform - Dynamic Taxonomy + Spring AI

This version includes:
- Generic `fulfilment-agent`
- In-memory intent taxonomy service
- Dynamic prompt composition
- Spring AI + OpenAI extraction
- Prompt debug endpoint
- Per-task timing breakdown
- Existing `Search_and_Fetch` flow retained

## Prerequisites
- Java 21
- Maven 3.9+
- OpenAI API key

## Set OpenAI API key
```bash
export OPENAI_API_KEY="your-openai-api-key"
```

## Build
Always build from the project root so the shared `common-contracts` module is installed consistently:
```bash
mvn clean install
```

## Run
Terminal 1:
```bash
cd ms-workforce-knowledgebase
mvn spring-boot:run
```

Terminal 2:
```bash
cd fulfilment-agent
mvn spring-boot:run
```

Terminal 3:
```bash
cd agentic-orchestrator
mvn spring-boot:run
```

## Test 1 - Search and fetch
```bash
curl --location 'http://localhost:8081/v1/execute/Search_and_Fetch' --header 'Content-Type: application/json' --data '{
  "input": {
    "query": "leave policy singapore",
    "documentId": "DOC-1001"
  }
}'
```

## Test 2 - Generic AI extract
```bash
curl --location 'http://localhost:8081/v1/execute/Extract_Generic_Intent' --header 'Content-Type: application/json' --data '{
  "input": {
    "utterance": "i need to apply for 3 days leave from next monday"
  }
}'
```

## Test 3 - Debug rendered prompt
```bash
curl --location 'http://localhost:8082/v1/debug/render-prompt' --header 'Content-Type: application/json' --data '{
  "domain": "HR",
  "candidateIntents": ["LEAVE_APPLICATION", "LEAVE_BALANCE_QUERY", "MEETING_BOOKING", "POLICY_SEARCH"],
  "utterance": "i need to apply for 3 days leave from next monday"
}'
```

## Logs to inspect
In `fulfilment-agent` logs, search for:
- `LLM_SYSTEM_PROMPT`
- `LLM_USER_PROMPT`
- `LLM_RESPONSE_TEXT`
- `LLM_RESPONSE_MODEL`
- `LLM_USAGE`

## Response metadata
The AI extract task includes metadata such as:
- `domain`
- `candidateIntents`
- `model`
- `timings_ms.taxonomy_lookup`
- `timings_ms.prompt_build`
- `timings_ms.llm_round_trip`
- `timings_ms.response_parse`
- `token_usage`

## Important
- Date resolution is intentionally left to the LLM through the prompt.
- The taxonomy service is in-memory for now.
- I did not compile this inside the current environment because external dependency download is not available here.
