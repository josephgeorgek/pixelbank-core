package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.GraphEdgeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface GraphEdgeRepository extends JpaRepository<GraphEdgeEntity, Long> { void deleteByWikiId(String wikiId); long countByWikiId(String wikiId); }
