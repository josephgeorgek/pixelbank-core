package com.ocbc.agentic.common.model;

public record EntitlementDecision(
        boolean allowed,
        String serviceCode,
        String reason) {
}
