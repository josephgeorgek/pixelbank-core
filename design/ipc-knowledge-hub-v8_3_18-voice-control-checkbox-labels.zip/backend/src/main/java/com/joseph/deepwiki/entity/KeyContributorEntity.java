package com.joseph.deepwiki.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "key_contributors")
public class KeyContributorEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String workspaceId;
    public String repoName;
    public String contributorName;
    public String sourceType;
    public int rankOrder;
    public KeyContributorEntity() {}
}
