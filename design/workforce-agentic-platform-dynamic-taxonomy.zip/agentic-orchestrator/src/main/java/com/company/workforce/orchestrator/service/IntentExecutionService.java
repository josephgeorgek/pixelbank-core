package com.company.workforce.orchestrator.service;

import com.company.workforce.contracts.api.*;
import com.company.workforce.contracts.enums.ExecutionStatus;
import com.company.workforce.contracts.enums.TaskType;
import com.company.workforce.contracts.graph.GraphDefinition;
import com.company.workforce.contracts.graph.GraphNodeDefinition;
import com.company.workforce.orchestrator.client.FulfilmentAgentClient;
import com.company.workforce.orchestrator.loader.GraphDefinitionLoader;
import com.company.workforce.orchestrator.state.WorkflowState;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class IntentExecutionService {

    private final GraphDefinitionLoader graphDefinitionLoader;
    private final FulfilmentAgentClient fulfilmentAgentClient;

    public IntentExecutionService(GraphDefinitionLoader graphDefinitionLoader,
                                  FulfilmentAgentClient fulfilmentAgentClient) {
        this.graphDefinitionLoader = graphDefinitionLoader;
        this.fulfilmentAgentClient = fulfilmentAgentClient;
    }

    public IntentExecutionResponse execute(String intentId, IntentExecutionRequest request) {
        long totalStart = System.nanoTime();
        GraphDefinition graph = graphDefinitionLoader.load(intentId);

        WorkflowState state = new WorkflowState();
        state.setExecutionId(UUID.randomUUID().toString());
        state.setIntentId(intentId);
        state.setStatus(ExecutionStatus.RUNNING);
        if (request.input() != null) {
            state.getInput().putAll(request.input());
        }

        String nextNodeId = graph.startNode();

        while (nextNodeId != null && !"END".equalsIgnoreCase(nextNodeId)) {
            GraphNodeDefinition node = findNode(graph, nextNodeId);
            state.setCurrentNode(node.id());

            TaskType taskType = TaskType.valueOf(node.taskType());
            TaskExecutionRequest taskRequest = new TaskExecutionRequest(
                    state.getExecutionId(),
                    intentId,
                    node.id(),
                    taskType,
                    getConfigString(node, "targetService"),
                    getConfigString(node, "targetEndpoint"),
                    getConfigString(node, "method"),
                    buildInput(node, state),
                    buildMetadata(node, state)
            );

            long delegateStart = System.nanoTime();
            TaskExecutionResponse taskResponse = fulfilmentAgentClient.executeTask(taskRequest);
            long delegateEnd = System.nanoTime();

            if (taskResponse == null || taskResponse.status() == ExecutionStatus.FAILED) {
                state.setStatus(ExecutionStatus.FAILED);
                state.setError(taskResponse != null ? taskResponse.error() : "Null response from fulfilment-agent");
                state.getMetadata().put("failedNode", node.id());
                state.getMetadata().put("orchestrator_delegate_ms", toMs(delegateEnd - delegateStart));
                state.getMetadata().put("orchestrator_total_ms", toMs(System.nanoTime() - totalStart));
                return new IntentExecutionResponse(
                        state.getExecutionId(),
                        intentId,
                        state.getStatus(),
                        state.getCurrentNode(),
                        state.getFinalOutput(),
                        state.getMetadata(),
                        state.getError()
                );
            }

            state.getTaskResults().put(node.id(), taskResponse.output());
            state.getFinalOutput().put(node.id(), taskResponse.output());
            if (taskResponse.metadata() != null) {
                state.getMetadata().put(node.id(), taskResponse.metadata());
            }

            nextNodeId = node.next();
        }

        state.setCurrentNode(graph.endNode());
        state.setStatus(ExecutionStatus.COMPLETED);
        state.getMetadata().put("orchestrator_total_ms", toMs(System.nanoTime() - totalStart));

        return new IntentExecutionResponse(
                state.getExecutionId(),
                intentId,
                state.getStatus(),
                state.getCurrentNode(),
                state.getFinalOutput(),
                state.getMetadata(),
                null
        );
    }

    private GraphNodeDefinition findNode(GraphDefinition graph, String nodeId) {
        for (GraphNodeDefinition node : graph.nodes()) {
            if (node.id().equals(nodeId)) {
                return node;
            }
        }
        throw new IllegalStateException("Node not found: " + nodeId);
    }

    private Map<String, Object> buildInput(GraphNodeDefinition node, WorkflowState state) {
        Map<String, Object> input = new LinkedHashMap<>();
        if ("task_1_search".equals(node.id())) {
            input.put("query", state.getInput().get("query"));
        } else if ("task_2_fetch".equals(node.id())) {
            Object searchResult = state.getTaskResults().get("task_1_search");
            if (searchResult instanceof Map<?, ?> map && map.get("documentId") != null) {
                input.put("documentId", map.get("documentId"));
            } else {
                input.put("documentId", state.getInput().get("documentId"));
            }
        } else if (TaskType.AI_EXTRACT.name().equals(node.taskType())) {
            input.put("utterance", state.getInput().get("utterance"));
        }
        return input;
    }

    private Map<String, Object> buildMetadata(GraphNodeDefinition node, WorkflowState state) {
        Map<String, Object> metadata = new LinkedHashMap<>();
        if (node.domain() != null) {
            metadata.put("domain", node.domain());
        }
        if (node.candidateIntents() != null) {
            metadata.put("candidateIntents", node.candidateIntents());
        }
        metadata.put("requestInputKeys", state.getInput().keySet());
        return metadata;
    }

    private String getConfigString(GraphNodeDefinition node, String key) {
        Object value = node.config() != null ? node.config().get(key) : null;
        return value != null ? String.valueOf(value) : null;
    }

    private long toMs(long nanos) {
        return nanos / 1_000_000;
    }
}
