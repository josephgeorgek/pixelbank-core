package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentRequest;
import com.example.agtstaffintent.domain.IntentResponse;
import com.example.agtstaffintent.domain.LlmSelectionResult;
import com.example.agtstaffintent.domain.RankedIntent;
import com.example.agtstaffintent.support.TimingCollector;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class IntentDiscoveryService {

    private final TaxonomyLoader taxonomyLoader;
    private final PromptNormalizer promptNormalizer;
    private final IntentSimilarityService similarityService;
    private final IntentShortlistService shortlistService;
    private final LlmIntentService llmIntentService;

    public IntentDiscoveryService(TaxonomyLoader taxonomyLoader,
                                  PromptNormalizer promptNormalizer,
                                  IntentSimilarityService similarityService,
                                  IntentShortlistService shortlistService,
                                  LlmIntentService llmIntentService) {
        this.taxonomyLoader = taxonomyLoader;
        this.promptNormalizer = promptNormalizer;
        this.similarityService = similarityService;
        this.shortlistService = shortlistService;
        this.llmIntentService = llmIntentService;
    }

    public IntentResponse discover(IntentRequest request, boolean debug) {
        TimingCollector timing = new TimingCollector();

        var taxonomies = taxonomyLoader.loadAll();
        timing.mark("taxonomyLoad");

        String normalizedPrompt = promptNormalizer.normalize(request.prompt());
        timing.mark("promptNormalize");

        List<RankedIntent> ranked = similarityService.rank(normalizedPrompt, request.userRole(), taxonomies);
        timing.mark("similarityRank");

        List<RankedIntent> shortlisted = shortlistService.shortlist(ranked);
        timing.mark("shortlist");

        LlmSelectionResult selection = llmIntentService.resolveIntent(request.prompt(), request.userRole(), shortlisted);
        timing.mark("llmResolve");

        IntentResponse response = new IntentResponse(
                request.prompt(),
                request.userRole(),
                selection.selectedIntent(),
                selection.confidence(),
                selection.rationale(),
                selection.entities(),
                selection.serviceCandidates(),
                debug ? buildDebugMap(normalizedPrompt, ranked, shortlisted, timing) : null
        );
        timing.mark("responseBuild");

        log.info("INTENT_DISCOVERY_TIMING userId={} role={} totalMs={} steps={}",
                request.userId(), request.userRole(), timing.totalMs(), timing.steps());

        return response;
    }

    private Map<String, Object> buildDebugMap(String normalizedPrompt,
                                              List<RankedIntent> ranked,
                                              List<RankedIntent> shortlisted,
                                              TimingCollector timing) {
        Map<String, Object> debug = new LinkedHashMap<>();
        debug.put("normalizedPrompt", normalizedPrompt);
        debug.put("totalMs", timing.totalMs());
        debug.put("steps", timing.steps());
        debug.put("topKBeforeFilter", ranked.stream().map(item -> Map.of(
                "intent", item.taxonomy().intent(),
                "score", item.score(),
                "matchedSignals", item.matchedSignals(),
                "rejectedSignals", item.rejectedSignals()
        )).toList());
        debug.put("shortlisted", shortlisted.stream().map(item -> item.taxonomy().intent()).toList());
        return debug;
    }
}
