package com.ocbc.staff.orchestrator.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class WorkflowState {
    private String executionId;
    private String graphId;
    private String graphVersion;
    private WorkflowStatus status;
    private String currentNodeId;

    private Map<String, Object> input = new LinkedHashMap<>();
    private Map<String, Object> intentResult = new LinkedHashMap<>();

    private Boolean allowed;
    private List<Map<String, Object>> pendingLeaves = new ArrayList<>();
    private Map<String, Object> reviewResult = new LinkedHashMap<>();
    private Map<String, Object> finalResponse = new LinkedHashMap<>();
    private Map<String, Object> outcome = new LinkedHashMap<>();

    private Map<String, NodeStatus> nodeStatuses = new LinkedHashMap<>();
    private List<Map<String, Object>> errors = new ArrayList<>();
    private Map<String, Object> finalOutput = new LinkedHashMap<>();
    private Instant startedAt;
    private Instant updatedAt;
    private Instant completedAt;

    public String getExecutionId() { return executionId; }
    public void setExecutionId(String executionId) { this.executionId = executionId; }
    public String getGraphId() { return graphId; }
    public void setGraphId(String graphId) { this.graphId = graphId; }
    public String getGraphVersion() { return graphVersion; }
    public void setGraphVersion(String graphVersion) { this.graphVersion = graphVersion; }
    public WorkflowStatus getStatus() { return status; }
    public void setStatus(WorkflowStatus status) { this.status = status; }
    public String getCurrentNodeId() { return currentNodeId; }
    public void setCurrentNodeId(String currentNodeId) { this.currentNodeId = currentNodeId; }
    public Map<String, Object> getInput() { return input; }
    public void setInput(Map<String, Object> input) { this.input = input; }
    public Map<String, Object> getIntentResult() { return intentResult; }
    public void setIntentResult(Map<String, Object> intentResult) { this.intentResult = intentResult; }
    public Boolean getAllowed() { return allowed; }
    public void setAllowed(Boolean allowed) { this.allowed = allowed; }
    public List<Map<String, Object>> getPendingLeaves() { return pendingLeaves; }
    public void setPendingLeaves(List<Map<String, Object>> pendingLeaves) { this.pendingLeaves = pendingLeaves; }
    public Map<String, Object> getReviewResult() { return reviewResult; }
    public void setReviewResult(Map<String, Object> reviewResult) { this.reviewResult = reviewResult; }
    public Map<String, Object> getFinalResponse() { return finalResponse; }
    public void setFinalResponse(Map<String, Object> finalResponse) { this.finalResponse = finalResponse; }
    public Map<String, Object> getOutcome() { return outcome; }
    public void setOutcome(Map<String, Object> outcome) { this.outcome = outcome; }
    public Map<String, NodeStatus> getNodeStatuses() { return nodeStatuses; }
    public void setNodeStatuses(Map<String, NodeStatus> nodeStatuses) { this.nodeStatuses = nodeStatuses; }
    public List<Map<String, Object>> getErrors() { return errors; }
    public void setErrors(List<Map<String, Object>> errors) { this.errors = errors; }
    public Map<String, Object> getFinalOutput() { return finalOutput; }
    public void setFinalOutput(Map<String, Object> finalOutput) { this.finalOutput = finalOutput; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }
}
