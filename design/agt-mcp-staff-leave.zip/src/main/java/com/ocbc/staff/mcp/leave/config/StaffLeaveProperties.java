package com.ocbc.staff.mcp.leave.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "staff.leave")
public class StaffLeaveProperties {
    private String baseUrl = "http://localhost:8091";
    private String listPendingEndpoint = "/v1/workday/leave/manager/pending/leave";
    private String approveEndpoint = "/v1/workday/leave/manager/approve";
    private String documentsEndpoint = "/v1/workday/leave/documents";
    private int timeoutMs = 4000;
    private int maxPageSize = 100;

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getListPendingEndpoint() { return listPendingEndpoint; }
    public void setListPendingEndpoint(String listPendingEndpoint) { this.listPendingEndpoint = listPendingEndpoint; }
    public String getApproveEndpoint() { return approveEndpoint; }
    public void setApproveEndpoint(String approveEndpoint) { this.approveEndpoint = approveEndpoint; }
    public String getDocumentsEndpoint() { return documentsEndpoint; }
    public void setDocumentsEndpoint(String documentsEndpoint) { this.documentsEndpoint = documentsEndpoint; }
    public int getTimeoutMs() { return timeoutMs; }
    public void setTimeoutMs(int timeoutMs) { this.timeoutMs = timeoutMs; }
    public int getMaxPageSize() { return maxPageSize; }
    public void setMaxPageSize(int maxPageSize) { this.maxPageSize = maxPageSize; }
}
