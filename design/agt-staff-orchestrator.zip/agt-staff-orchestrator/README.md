# agt-staff-orchestrator

Spring Boot + Java 21 sample for a JSON-graph-driven staff workflow orchestrator.

This v1 is intentionally practical:
- graph JSON is loaded from `src/main/resources/graphs`
- workflow state is kept in-memory for fast local testing
- node execution is delegated through pluggable executors
- transition routing is state-driven
- LangGraph4j is used as the shared-state runtime host for execution of the workflow session
- mock downstream delegates are included so you can test immediately without real HR/OCR services

## What this v1 does
- validates and registers graph JSON at startup
- starts a workflow from REST
- executes the graph
- stores runtime state keyed by `executionId`
- exposes workflow status and full workflow state
- supports:
  - `ACCESS_GUARD`
  - `DOMAIN_EXECUTION`
  - `LLM_STRUCTURED_TASK`
  - `GENERATE_RESPONSE`
  - `END`

## Important design note
This is **not** yet a full node-per-node LangGraph4j materialization.  
For v1, LangGraph4j hosts the shared workflow state and executes a single orchestration node that runs the JSON graph loop safely. That keeps the code runnable and avoids fragile hardcoding. The next step would be compiling each JSON node into conditional LangGraph4j edges.

## Project layout
```text
src/main/java/com/ocbc/staff/orchestrator
├── api
├── config
├── domain
├── executor
├── runtime
└── service
```

## Requirements
- Java 21
- Maven 3.6.3+

## Run
```bash
mvn spring-boot:run
```

The app starts on `http://localhost:8080`.

## Test with curl

### 1) Health
```bash
curl -s http://localhost:8080/actuator/health
```

### 2) List graphs
```bash
curl -s http://localhost:8080/v1/graphs | jq
```

### 3) Start workflow
```bash
curl -s -X POST http://localhost:8080/v1/workflows/start \
  -H 'Content-Type: application/json' \
  -d '{
    "graphId": "staff_leave_application_medical_cert_list_and_review",
    "input": {
      "userContext": {
        "userId": "M12345",
        "role": "Manager",
        "displayName": "Joseph George"
      }
    },
    "intentResult": {
      "intent": "STAFF_MEDICAL_LEAVE_REVIEW",
      "entities": {
        "reviewMode": "PENDING_MC"
      }
    }
  }' | jq
```

### 4) Get workflow summary
Replace `<executionId>` with the value returned from the start call.
```bash
curl -s http://localhost:8080/v1/workflows/<executionId> | jq
```

### 5) Get full workflow state
```bash
curl -s http://localhost:8080/v1/workflows/<executionId>/state | jq
```

## Sample responses

### Successful path
- guard passes
- pending medical leaves found
- mock OCR/LLM review runs
- final summary response is generated

### No-pending path
Use `userId = M00000`
```bash
curl -s -X POST http://localhost:8080/v1/workflows/start \
  -H 'Content-Type: application/json' \
  -d '{
    "graphId": "staff_leave_application_medical_cert_list_and_review",
    "input": {
      "userContext": {
        "userId": "M00000",
        "role": "Manager"
      }
    },
    "intentResult": {
      "intent": "STAFF_MEDICAL_LEAVE_REVIEW",
      "entities": {}
    }
  }' | jq
```

### Access denied path
Use `role = Staff`
```bash
curl -s -X POST http://localhost:8080/v1/workflows/start \
  -H 'Content-Type: application/json' \
  -d '{
    "graphId": "staff_leave_application_medical_cert_list_and_review",
    "input": {
      "userContext": {
        "userId": "S12345",
        "role": "Staff"
      }
    },
    "intentResult": {
      "intent": "STAFF_MEDICAL_LEAVE_REVIEW",
      "entities": {}
    }
  }' | jq
```

## Graph file
- `src/main/resources/graphs/staff_leave_application_medical_cert_list_and_review.v2.json`

## Next upgrades you should do
- replace in-memory state store with PostgreSQL or Redis
- convert the orchestration loop into node-per-node conditional LangGraph4j edges
- add retry backoff executor wrappers
- add suspend/resume human approval node
- add OpenTelemetry or structured JSON log sink
- add real OCR delegate
