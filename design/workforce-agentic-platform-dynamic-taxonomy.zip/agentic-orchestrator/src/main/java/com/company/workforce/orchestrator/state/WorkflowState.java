package com.company.workforce.orchestrator.state;

import com.company.workforce.contracts.enums.ExecutionStatus;
import java.util.HashMap;
import java.util.Map;

public class WorkflowState {
    private String executionId;
    private String intentId;
    private String currentNode;
    private ExecutionStatus status;
    private final Map<String, Object> input = new HashMap<>();
    private final Map<String, Object> taskResults = new HashMap<>();
    private final Map<String, Object> finalOutput = new HashMap<>();
    private final Map<String, Object> metadata = new HashMap<>();
    private String error;

    public String getExecutionId() { return executionId; }
    public void setExecutionId(String executionId) { this.executionId = executionId; }
    public String getIntentId() { return intentId; }
    public void setIntentId(String intentId) { this.intentId = intentId; }
    public String getCurrentNode() { return currentNode; }
    public void setCurrentNode(String currentNode) { this.currentNode = currentNode; }
    public ExecutionStatus getStatus() { return status; }
    public void setStatus(ExecutionStatus status) { this.status = status; }
    public Map<String, Object> getInput() { return input; }
    public Map<String, Object> getTaskResults() { return taskResults; }
    public Map<String, Object> getFinalOutput() { return finalOutput; }
    public Map<String, Object> getMetadata() { return metadata; }
    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
}
