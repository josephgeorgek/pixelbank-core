package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class WikiGenerationService {
    private final RepositoryAnalyzer repositoryAnalyzer;
    private final AiWikiWriter aiWikiWriter;
    private final SearchService searchService;
    private final CitationService citationService;
    private final RepoMermaidGenerator repoMermaidGenerator;
    private final PersistenceService persistenceService;
    private final Map<String, WikiResponse> store = new ConcurrentHashMap<>();

    public WikiGenerationService(RepositoryAnalyzer repositoryAnalyzer,
                                 AiWikiWriter aiWikiWriter,
                                 SearchService searchService,
                                 CitationService citationService,
                                 RepoMermaidGenerator repoMermaidGenerator,
                                 PersistenceService persistenceService) {
        this.repositoryAnalyzer = repositoryAnalyzer;
        this.aiWikiWriter = aiWikiWriter;
        this.searchService = searchService;
        this.citationService = citationService;
        this.repoMermaidGenerator = repoMermaidGenerator;
        this.persistenceService = persistenceService;
    }

    public WikiResponse generate(GenerateWikiRequest request) {
        RepositoryAnalyzer.AnalysisResult analysis = repositoryAnalyzer.analyze(request.repoUrl(), request.branch(), request.accessToken());
        String id = UUID.randomUUID().toString();
        String overview = aiWikiWriter.generateOverview(request.repoUrl(), analysis.files(), analysis.languageStats(), analysis.architectureGraph());
        List<WikiPage> pages = createPages(analysis.files(), analysis.chunks(), analysis.symbols(), analysis.architectureGraph());
        WikiResponse response = new WikiResponse(
                id,
                request.repoUrl(),
                Optional.ofNullable(request.branch()).filter(s -> !s.isBlank()).orElse("default"),
                Instant.now(),
                overview,
                repoMermaidGenerator.generate(analysis.architectureGraph()),
                analysis.architectureGraph(),
                pages,
                analysis.files(),
                analysis.chunks(),
                analysis.symbols(),
                analysis.languageStats()
        );
        store.put(id, response);
        persistenceService.saveWiki(response);
        return response;
    }

    public Optional<WikiResponse> find(String id) {
        WikiResponse cached = store.get(id);
        return cached != null ? Optional.of(cached) : persistenceService.findWiki(id);
    }
    public Collection<WikiResponse> list() {
        LinkedHashMap<String, WikiResponse> all = new LinkedHashMap<>();
        persistenceService.listWikis().forEach(w -> all.put(w.id(), w));
        store.values().forEach(w -> all.put(w.id(), w));
        return all.values();
    }

    public AiGeneratedSections generateWorkspaceDocumentation(List<WikiResponse> wikis) {
        return aiWikiWriter.generateWorkspaceDocumentation(wikis);
    }

    public ChatResponse chat(ChatRequest request) {
        WikiResponse wiki = find(request.wikiId()).orElseThrow(() -> new NoSuchElementException("Wiki not found: " + request.wikiId()));
        String query = request.selectedContext() == null || request.selectedContext().isBlank()
                ? request.question()
                : request.question() + "\n" + request.selectedContext();
        List<CodeChunk> evidence = searchService.evidence(wiki, query, 14);
        List<FileSummary> evidenceFiles = toFileSummaries(evidence);
        String answer = aiWikiWriter.answerQuestion(request.question(), evidenceFiles, wiki.architectureGraph());
        List<String> citations = evidence.stream().map(citationService::format).toList();
        return new ChatResponse(answer, citations, evidence);
    }

    public SearchResponse search(String wikiId, String query, int limit) {
        WikiResponse wiki = find(wikiId).orElseThrow(() -> new NoSuchElementException("Wiki not found: " + wikiId));
        List<SearchHit> hits = searchService.search(wiki, query, limit);
        return new SearchResponse(query, hits, hits.stream().map(citationService::format).toList());
    }

    public List<FileSummary> searchFiles(String wikiId, String query, int limit) {
        WikiResponse wiki = find(wikiId).orElseThrow(() -> new NoSuchElementException("Wiki not found: " + wikiId));
        return toFileSummaries(searchService.evidence(wiki, query, limit));
    }

    public List<GraphEdge> dependencies(String wikiId, String pathOrNodeId) {
        WikiResponse wiki = find(wikiId).orElseThrow(() -> new NoSuchElementException("Wiki not found: " + wikiId));
        Set<String> ids = wiki.architectureGraph().nodes().stream()
                .filter(n -> n.id().equals(pathOrNodeId) || n.path().equals(pathOrNodeId) || n.label().equalsIgnoreCase(pathOrNodeId))
                .map(GraphNode::id)
                .collect(Collectors.toSet());
        if (ids.isEmpty() && !StringUtils.hasText(pathOrNodeId)) {
            ids = wiki.architectureGraph().nodes().stream().limit(5).map(GraphNode::id).collect(Collectors.toSet());
        }
        Set<String> finalIds = ids;
        return wiki.architectureGraph().edges().stream()
                .filter(e -> finalIds.contains(e.source()) || finalIds.contains(e.target()))
                .limit(80)
                .toList();
    }

    public String explainArchitecture(String wikiId) {
        WikiResponse wiki = find(wikiId).orElseThrow(() -> new NoSuchElementException("Wiki not found: " + wikiId));
        return aiWikiWriter.explainArchitecture(wiki.architectureGraph(), wiki.files());
    }

    private List<FileSummary> toFileSummaries(List<CodeChunk> chunks) {
        return chunks.stream()
                .map(c -> new FileSummary(c.path(), c.language(), c.content().length(), c.content()))
                .toList();
    }

    private List<WikiPage> createPages(List<FileSummary> files, List<CodeChunk> chunks, List<SymbolRef> symbols, ArchitectureGraph graph) {
        Map<String, List<FileSummary>> byArea = files.stream().collect(Collectors.groupingBy(this::area, TreeMap::new, Collectors.toList()));
        List<WikiPage> pages = new ArrayList<>();
        pages.add(new WikiPage("architecture-map", "Architecture Map", "Repository-specific component and dependency map.", architectureMarkdown(graph), files.stream().limit(30).map(FileSummary::path).toList()));
        pages.add(new WikiPage("core-concepts", "Core Concepts", "Concepts inferred from repository files, symbols, and graph nodes.", conceptsMarkdown(symbols, graph), files.stream().limit(25).map(FileSummary::path).toList()));
        pages.add(new WikiPage("search-and-citations", "Search & Citations", "How evidence and line ranges are built.", citationMarkdown(chunks), chunks.stream().limit(25).map(CodeChunk::path).distinct().toList()));
        byArea.forEach((area, areaFiles) -> pages.add(new WikiPage(slug(area), pretty(area), "Auto-generated documentation for " + pretty(area), pageMarkdown(area, areaFiles, chunks, graph), areaFiles.stream().limit(20).map(FileSummary::path).toList())));
        pages.add(new WikiPage("onboarding-guide", "Onboarding Guide", "Suggested first reading path for a new contributor.", onboardingMarkdown(files, chunks, graph), files.stream().limit(25).map(FileSummary::path).toList()));
        return pages;
    }

    private String area(FileSummary file) {
        String path = file.path().replace('\\', '/').toLowerCase(Locale.ROOT);
        if (path.contains("/controller") || path.contains("/routes") || path.contains("/api")) return "api-layer";
        if (path.contains("/service") || path.contains("/domain") || path.contains("/usecase")) return "domain-services";
        if (path.contains("/repository") || path.contains("/dao") || path.contains("/entity") || path.contains("/model")) return "data-layer";
        if (path.contains("/components") || path.endsWith(".jsx") || path.endsWith(".tsx")) return "frontend-components";
        if (path.contains("dockerfile") || path.contains("docker-compose") || path.endsWith(".yml") || path.endsWith(".yaml")) return "deployment-config";
        if (path.endsWith("readme.md") || path.endsWith(".md")) return "documentation";
        if (path.contains("/test")) return "tests";
        return "source-overview";
    }

    private String architectureMarkdown(ArchitectureGraph graph) {
        return """
                ## Repository-specific architecture visualization

                This graph is generated from this repository's files, imports, framework annotations, React/TypeScript imports, and inferred runtime-flow edges.

                ### Node types

                %s

                ### Edge types

                %s

                ### How to use this map

                - Use Search to find payment, controller, service, repository, auth, config, or component terms.
                - Click graph nodes to inspect related source files.
                - Ask the repo assistant targeted questions, then verify the cited source ranges.
                """.formatted(formatStats(graph.nodeTypeStats()), formatStats(graph.edgeTypeStats()));
    }

    private String conceptsMarkdown(List<SymbolRef> symbols, ArchitectureGraph graph) {
        String symbolList = symbols.stream().limit(60)
                .map(s -> "- `" + s.symbol() + "` — " + s.kind() + " in `" + s.path() + ":" + s.line() + "`")
                .collect(Collectors.joining("\n"));
        if (!StringUtils.hasText(symbolList)) symbolList = "- No explicit code symbols were detected in the sampled files.";
        return """
                ## Core concepts inferred from code

                These are inferred from source symbols and graph nodes. Treat them as a starting map, then verify with the cited files.

                %s

                ## Architecture signal

                %s
                """.formatted(symbolList, formatStats(graph.nodeTypeStats()));
    }

    private String citationMarkdown(List<CodeChunk> chunks) {
        String chunkList = chunks.stream().limit(40)
                .map(c -> "- `" + citationService.format(c) + "` — " + c.language() + " symbols=" + c.symbols())
                .collect(Collectors.joining("\n"));
        return """
                ## Search and citation model

                v7 indexes source into line-based chunks. Search and grounded Q&A cite chunk ranges instead of file-only references.

                ### Sample indexed chunks

                %s
                """.formatted(chunkList);
    }

    private String pageMarkdown(String area, List<FileSummary> files, List<CodeChunk> chunks, ArchitectureGraph graph) {
        Set<String> areaPaths = files.stream().map(FileSummary::path).collect(Collectors.toSet());
        String fileBullets = files.stream().limit(25)
                .map(f -> "- `" + f.path() + "` (" + f.language() + ")")
                .collect(Collectors.joining("\n"));
        String chunkBullets = chunks.stream().filter(c -> areaPaths.contains(c.path())).limit(12)
                .map(c -> "- `" + citationService.format(c) + "` symbols=" + c.symbols())
                .collect(Collectors.joining("\n"));
        return """
                ## %s

                This section groups repository files that appear to belong to `%s`.

                ### Files

                %s

                ### Evidence chunks

                %s

                ### Graph context

                Architecture graph: `%s` nodes and `%s` edges. Use this page with Search, graph filters, and grounded Q&A to inspect inbound and outbound relationships.
                """.formatted(pretty(area), area, fileBullets, StringUtils.hasText(chunkBullets) ? chunkBullets : "No chunks for this area.", graph.nodes().size(), graph.edges().size());
    }

    private String onboardingMarkdown(List<FileSummary> files, List<CodeChunk> chunks, ArchitectureGraph graph) {
        String firstChunks = chunks.stream()
                .filter(c -> c.path().toLowerCase(Locale.ROOT).contains("readme") || c.path().toLowerCase(Locale.ROOT).contains("application") || c.path().toLowerCase(Locale.ROOT).contains("package.json") || c.path().toLowerCase(Locale.ROOT).contains("pom.xml"))
                .limit(12)
                .map(c -> "- `" + citationService.format(c) + "`")
                .collect(Collectors.joining("\n"));
        if (!StringUtils.hasText(firstChunks)) firstChunks = chunks.stream().limit(12).map(c -> "- `" + citationService.format(c) + "`").collect(Collectors.joining("\n"));
        return """
                ## New contributor reading path

                1. Read entry/config files.
                2. Open the Architecture Map and filter by `controller`, `service`, `repository`, and `react-component`.
                3. Search for the business flow you care about, for example `payment`, `auth`, `order`, or `checkout`.
                4. Ask grounded questions and verify the cited line ranges.

                ### Suggested first chunks

                %s
                """.formatted(firstChunks);
    }

    private String formatStats(Map<String, Long> stats) { return stats.entrySet().stream().map(e -> "- `" + e.getKey() + "`: " + e.getValue()).collect(Collectors.joining("\n")); }
    private String slug(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-"); }
    private String pretty(String s) { return Arrays.stream(s.split("[-_]")) .filter(w -> !w.isBlank()).map(w -> w.substring(0,1).toUpperCase() + w.substring(1)).collect(Collectors.joining(" ")); }
}
