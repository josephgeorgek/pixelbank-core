package com.joseph.deepwiki.model;

import jakarta.validation.constraints.NotBlank;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public class WikiModels {
    public record GenerateWikiRequest(@NotBlank String repoUrl, String branch, String accessToken) {}
    public record ChatRequest(@NotBlank String wikiId, @NotBlank String question, String selectedContext) {}
    public record ChatResponse(String answer, List<String> citations, List<CodeChunk> evidenceChunks) {}
    public record SearchResponse(String query, List<SearchHit> results, List<String> citations) {}

    public record FileSummary(String path, String language, long bytes, String preview) {}

    public record CodeChunk(
            String id,
            String path,
            String language,
            int startLine,
            int endLine,
            String content,
            List<String> symbols
    ) {}

    public record SearchHit(
            String path,
            String language,
            int startLine,
            int endLine,
            String preview,
            int score,
            List<String> symbols
    ) {}

    public record CodeCitation(String path, int startLine, int endLine) {}
    public record SymbolRef(String path, String symbol, String kind, int line) {}
    public record WikiPage(String id, String title, String summary, String markdown, List<String> relatedFiles) {}

    public record GraphNode(String id, String label, String type, String path, String language, String group, long bytes) {}
    public record GraphEdge(String id, String source, String target, String kind, String label) {}
    public record ArchitectureGraph(List<GraphNode> nodes, List<GraphEdge> edges, Map<String, Long> nodeTypeStats, Map<String, Long> edgeTypeStats) {}

    public record WikiResponse(
            String id,
            String repoUrl,
            String branch,
            Instant generatedAt,
            String overview,
            String architectureMermaid,
            ArchitectureGraph architectureGraph,
            List<WikiPage> pages,
            List<FileSummary> files,
            List<CodeChunk> chunks,
            List<SymbolRef> symbols,
            Map<String, Long> languageStats
    ) {}

    public record IndexJobResponse(String jobId, String statusUrl) {}
    public record IndexJobStatus(
            String jobId,
            String status,
            String stage,
            int progress,
            String message,
            String wikiId,
            WikiResponse wiki,
            String error,
            Instant createdAt,
            Instant updatedAt
    ) {}



    public record MultiRepoIndexRequest(List<String> repoUrls, String repoInput, String branch, String accessToken) {}
    public record WorkspaceIndexJobResponse(String jobId, String statusUrl) {}
    public record WorkspaceIndexJobStatus(
            String jobId,
            String status,
            String stage,
            int progress,
            String message,
            String workspaceId,
            WorkspaceResponse workspace,
            String error,
            Instant createdAt,
            Instant updatedAt
    ) {}

    public record WorkspaceRepoSummary(
            String repoId,
            String repoUrl,
            String name,
            String branch,
            String wikiId,
            String summary,
            Map<String, Long> languageStats,
            int files,
            int chunks,
            int symbols,
            int graphNodes,
            int graphEdges
    ) {}

    public record CommitHighlight(
            String repo,
            String sha,
            String shortSha,
            String author,
            String date,
            String message,
            String url,
            String reason
    ) {}

    public record PullRequestReviewer(
            String repo,
            int pullNumber,
            String pullTitle,
            String reviewer,
            String state,
            String submittedAt,
            String url
    ) {}

    public record KeyContributor(String name, String repoName, String sourceType) {}

    public record WorkspaceDiagrams(
            String interactionComponentMermaid,
            String sequenceMermaid,
            String combinedComponentMermaid,
            Map<String, String> individualRepoMermaid
    ) {}

    public record AiGeneratedSections(
            String purposeAndScope,
            String dev2DevInfo,
            String architecture,
            String codeInsights,
            String designElevation,
            String roadmapFeatures
    ) {}

    public record WorkspaceResponse(
            String id,
            Instant generatedAt,
            List<String> repoUrls,
            String branch,
            String summary,
            String overview,
            AiGeneratedSections aiGeneratedSections,
            Map<String, Long> combinedLanguageStats,
            int totalFiles,
            int totalChunks,
            int totalSymbols,
            int totalGraphNodes,
            int totalGraphEdges,
            List<WorkspaceRepoSummary> repositories,
            WorkspaceDiagrams diagrams,
            List<KeyContributor> keyContributors,
            List<WikiResponse> wikis
    ) {}

    public record McpTool(String name, String description, Map<String, String> inputSchema) {}
    public record McpToolCallRequest(@NotBlank String toolName, Map<String, Object> arguments) {}
    public record McpToolCallResponse(String toolName, Object result, List<String> citations) {}
}
