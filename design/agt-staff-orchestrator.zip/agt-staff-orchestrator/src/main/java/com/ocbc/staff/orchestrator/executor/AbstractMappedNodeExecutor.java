package com.ocbc.staff.orchestrator.executor;

import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import com.ocbc.staff.orchestrator.service.DelegateTaskClient;
import com.ocbc.staff.orchestrator.service.MappingResolverService;

import java.util.LinkedHashMap;
import java.util.Map;

public abstract class AbstractMappedNodeExecutor implements NodeExecutor {

    protected final MappingResolverService mappingResolverService;
    protected final DelegateTaskClient delegateTaskClient;

    protected AbstractMappedNodeExecutor(MappingResolverService mappingResolverService,
                                         DelegateTaskClient delegateTaskClient) {
        this.mappingResolverService = mappingResolverService;
        this.delegateTaskClient = delegateTaskClient;
    }

    @SuppressWarnings("unchecked")
    protected Map<String, Object> resolvedPayload(GraphNodeDefinition node, WorkflowState state) {
        Object inputMapping = node.config() != null ? node.config().get("inputMapping") : null;
        if (inputMapping instanceof Map<?, ?> map) {
            return mappingResolverService.resolveMap((Map<String, Object>) map, state);
        }
        return new LinkedHashMap<>();
    }
}
