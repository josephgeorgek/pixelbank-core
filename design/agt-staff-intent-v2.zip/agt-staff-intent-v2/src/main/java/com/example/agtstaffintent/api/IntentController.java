package com.example.agtstaffintent.api;

import com.example.agtstaffintent.domain.IntentRequest;
import com.example.agtstaffintent.domain.IntentResponse;
import com.example.agtstaffintent.service.IntentDiscoveryOrchestrator;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/v1/intent", produces = MediaType.APPLICATION_JSON_VALUE)
public class IntentController {

    private final IntentDiscoveryOrchestrator orchestrator;

    public IntentController(IntentDiscoveryOrchestrator orchestrator) {
        this.orchestrator = orchestrator;
    }

    @PostMapping(path = "/discover", consumes = MediaType.APPLICATION_JSON_VALUE)
    public IntentResponse discover(@Valid @RequestBody IntentRequest request) {
        return orchestrator.discover(request);
    }
}
