package com.ocbc.agentic.common.model;

import java.util.Map;

public record IntentResolution(
        String intentCode,
        Map<String, Object> entities,
        String targetService,
        String graphId,
        double confidence,
        boolean resolved) {
}
