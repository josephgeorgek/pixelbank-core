package com.joseph.deepwiki.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.joseph.deepwiki.model.WikiModels.CommitHighlight;
import com.joseph.deepwiki.model.WikiModels.PullRequestReviewer;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Service
public class GitHubAnalyticsService {
    private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<CommitHighlight> commits(String repoUrl, String token) {
        Optional<RepoRef> ref = parse(repoUrl);
        if (ref.isEmpty()) return List.of();
        String api = "https://api.github.com/repos/" + ref.get().owner() + "/" + ref.get().repo() + "/commits?per_page=20";
        try {
            JsonNode root = get(api, token);
            if (!root.isArray()) return List.of();
            List<CommitHighlight> results = new ArrayList<>();
            for (JsonNode node : root) {
                String sha = text(node, "sha");
                JsonNode commit = node.path("commit");
                String message = commit.path("message").asText("").split("\\R", 2)[0];
                String author = commit.path("author").path("name").asText("unknown");
                String date = commit.path("author").path("date").asText("");
                String url = text(node, "html_url");
                String reason = reasonForCommit(message);
                results.add(new CommitHighlight(ref.get().name(), sha, sha.length() >= 7 ? sha.substring(0, 7) : sha, author, date, message, url, reason));
            }
            return results;
        } catch (Exception ignored) {
            return List.of();
        }
    }

    public List<PullRequestReviewer> reviewers(String repoUrl, String token) {
        Optional<RepoRef> ref = parse(repoUrl);
        if (ref.isEmpty()) return List.of();
        String pullsApi = "https://api.github.com/repos/" + ref.get().owner() + "/" + ref.get().repo() + "/pulls?state=all&per_page=12";
        try {
            JsonNode pulls = get(pullsApi, token);
            if (!pulls.isArray()) return List.of();
            List<PullRequestReviewer> results = new ArrayList<>();
            for (JsonNode pr : pulls) {
                int number = pr.path("number").asInt();
                String title = pr.path("title").asText("");
                String prUrl = pr.path("html_url").asText("");
                JsonNode requested = pr.path("requested_reviewers");
                if (requested.isArray()) {
                    for (JsonNode reviewer : requested) {
                        results.add(new PullRequestReviewer(ref.get().name(), number, title, reviewer.path("login").asText("unknown"), "REQUESTED", "", prUrl));
                    }
                }
                String reviewsApi = "https://api.github.com/repos/" + ref.get().owner() + "/" + ref.get().repo() + "/pulls/" + number + "/reviews?per_page=20";
                JsonNode reviews = get(reviewsApi, token);
                if (reviews.isArray()) {
                    for (JsonNode review : reviews) {
                        String reviewer = review.path("user").path("login").asText("unknown");
                        String state = review.path("state").asText("REVIEWED");
                        String submittedAt = review.path("submitted_at").asText("");
                        if (StringUtils.hasText(reviewer)) {
                            results.add(new PullRequestReviewer(ref.get().name(), number, title, reviewer, state, submittedAt, prUrl));
                        }
                    }
                }
            }
            return results.stream().limit(80).toList();
        } catch (Exception ignored) {
            return List.of();
        }
    }

    private JsonNode get(String apiUrl, String token) throws Exception {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(apiUrl))
                .timeout(Duration.ofSeconds(12))
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "ipc-knowledge-hub");
        if (StringUtils.hasText(token)) builder.header("Authorization", "Bearer " + token.trim());
        HttpResponse<String> response = httpClient.send(builder.GET().build(), HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) return objectMapper.createArrayNode();
        return objectMapper.readTree(response.body());
    }

    private Optional<RepoRef> parse(String repoUrl) {
        try {
            URI uri = URI.create(repoUrl);
            if (!"github.com".equalsIgnoreCase(uri.getHost())) return Optional.empty();
            String[] parts = uri.getPath().replaceAll("^/+", "").replaceAll("/+$", "").split("/");
            if (parts.length < 2) return Optional.empty();
            String repo = parts[1].replaceAll("\\.git$", "");
            return Optional.of(new RepoRef(parts[0], repo));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private String text(JsonNode node, String field) { return node.path(field).asText(""); }

    private String reasonForCommit(String message) {
        String m = Optional.ofNullable(message).orElse("").toLowerCase(Locale.ROOT);
        if (m.contains("security") || m.contains("vulnerab")) return "Security-sensitive change";
        if (m.contains("payment") || m.contains("ledger") || m.contains("transaction")) return "Business-flow change";
        if (m.contains("refactor") || m.contains("cleanup")) return "Refactoring signal";
        if (m.contains("fix") || m.contains("bug")) return "Bug-fix signal";
        if (m.contains("test")) return "Test coverage change";
        return "Recent activity";
    }

    private record RepoRef(String owner, String repo) {
        String name() { return owner + "/" + repo; }
    }
}
