agt-mcp-staff-leave
===================

Spring Boot 3.5.7 / Java 21 MCP-style staff leave server.
Uses application.properties, not YAML.

Port
----
9090

Exposed APIs
------------
GET  /v1/mcp/tools
POST /v1/mcp/tools/execute

Implemented tools
-----------------
1. list_pending_medical_leaves
2. get_medical_leave_documents
3. approve_medical_leaves

Build
-----
mvn clean install

Run
---
mvn spring-boot:run

Example CURLs
-------------
List tools:
curl -s http://localhost:9090/v1/mcp/tools

Execute list_pending_medical_leaves:
curl -s -X POST http://localhost:9090/v1/mcp/tools/execute \
  -H "Content-Type: application/json" \
  -d '{
    "toolName": "list_pending_medical_leaves",
    "arguments": {
      "managerId": "M12345",
      "status": "PENDING",
      "certificateRequired": true,
      "fetchAll": true,
      "maxRecords": 100
    }
  }'

Execute approve_medical_leaves:
curl -s -X POST http://localhost:9090/v1/mcp/tools/execute \
  -H "Content-Type: application/json" \
  -d '{
    "toolName": "approve_medical_leaves",
    "arguments": {
      "approverId": "M12345",
      "approvalMode": "MATCH_TRUE_ONLY",
      "leaveApplications": [
        {
          "leaveId": "ML-1001",
          "patientName": "John Tan",
          "medicalLeaveDateFrom": "2026-04-07",
          "medicalLeaveDateTo": "2026-04-08",
          "match": true
        }
      ]
    }
  }'

See graph-node-examples.json for graph node examples.
