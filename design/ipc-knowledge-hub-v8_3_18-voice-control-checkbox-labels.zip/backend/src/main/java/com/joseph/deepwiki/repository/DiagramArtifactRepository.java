package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.DiagramArtifactEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface DiagramArtifactRepository extends JpaRepository<DiagramArtifactEntity, Long> { void deleteByWikiId(String wikiId); void deleteByWorkspaceId(String workspaceId); List<DiagramArtifactEntity> findByWorkspaceId(String workspaceId); }
