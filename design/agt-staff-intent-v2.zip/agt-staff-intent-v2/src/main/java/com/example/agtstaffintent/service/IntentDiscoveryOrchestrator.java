package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentRequest;
import com.example.agtstaffintent.domain.IntentResponse;
import com.example.agtstaffintent.domain.LlmIntentExtractionResult;
import com.example.agtstaffintent.domain.RankedIntent;
import com.example.agtstaffintent.domain.IntentTaxonomy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IntentDiscoveryOrchestrator {

    private static final String UNKNOWN_INTENT = "UNKNOWN_OR_UNSUPPORTED_REQUEST";

    private final TaxonomyRepository taxonomyRepository;
    private final IntentSimilarityService similarityService;
    private final OpenAiIntentExtractionService extractionService;

    public IntentDiscoveryOrchestrator(TaxonomyRepository taxonomyRepository,
                                       IntentSimilarityService similarityService,
                                       OpenAiIntentExtractionService extractionService) {
        this.taxonomyRepository = taxonomyRepository;
        this.similarityService = similarityService;
        this.extractionService = extractionService;
    }

    public IntentResponse discover(IntentRequest request) {
        List<RankedIntent> topK = similarityService.rank(request.prompt(), request.userRole(), taxonomyRepository.findAll(), 3);
        List<RankedIntent> shortlisted = topK.stream().filter(RankedIntent::shortlisted).toList();
        List<RankedIntent> effectiveShortlist = shortlisted.isEmpty() ? List.of(unknownRankedIntent()) : shortlisted;

        LlmIntentExtractionResult llmResult = UNKNOWN_INTENT.equals(effectiveShortlist.getFirst().taxonomy().intent())
                ? extractionService.fallbackUnknown(request, effectiveShortlist,
                "No supported taxonomy matched with sufficient confidence. Domain anchors were missing or ambiguous.")
                : extractionService.extract(request, effectiveShortlist);

        return new IntentResponse(
                request.prompt(),
                request.userRole(),
                llmResult.selectedIntent(),
                llmResult.confidence(),
                llmResult.rationale(),
                llmResult.entities(),
                llmResult.serviceCandidates(),
                topK.stream().map(this::toView).toList(),
                effectiveShortlist.stream().map(this::toView).toList()
        );
    }

    private RankedIntent unknownRankedIntent() {
        IntentTaxonomy taxonomy = taxonomyRepository.requireByIntent(UNKNOWN_INTENT);
        return new RankedIntent(
                taxonomy,
                0.0d,
                List.of(),
                List.of(),
                true
        );
    }

    private IntentResponse.RankedIntentView toView(RankedIntent rankedIntent) {
        return new IntentResponse.RankedIntentView(
                rankedIntent.taxonomy().intent(),
                rankedIntent.taxonomy().persona(),
                rankedIntent.similarityScore(),
                rankedIntent.matchedSignals(),
                rankedIntent.rejectedSignals(),
                rankedIntent.shortlisted(),
                rankedIntent.taxonomy().serviceCandidates()
        );
    }
}
