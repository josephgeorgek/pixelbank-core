package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.model.WorkflowState;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.util.*;

@Service
public class MappingResolverService {
    public Map<String, Object> root(WorkflowState state) {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("executionId", state.getExecutionId());
        root.put("graphId", state.getGraphId());
        root.put("graphVersion", state.getGraphVersion());
        root.put("status", state.getStatus());
        root.put("currentNodeId", state.getCurrentNodeId());
        root.put("input", state.getInput());
        root.put("intentResult", state.getIntentResult());
        root.put("allowed", state.getAllowed());
        root.put("pendingLeaves", state.getPendingLeaves());
        root.put("reviewResult", state.getReviewResult());
        root.put("finalResponse", state.getFinalResponse());
        root.put("outcome", state.getOutcome());
        root.put("nodeStatuses", state.getNodeStatuses());
        root.put("errors", state.getErrors());
        root.put("finalOutput", state.getFinalOutput());
        root.put("startedAt", state.getStartedAt());
        root.put("updatedAt", state.getUpdatedAt());
        root.put("completedAt", state.getCompletedAt());
        return root;
    }

    public Map<String, Object> resolveTemplate(Map<String, Object> template, WorkflowState state) {
        Map<String, Object> resolved = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : template.entrySet()) {
            resolved.put(entry.getKey(), resolveValue(entry.getValue(), state));
        }
        return resolved;
    }

    public Map<String, Object> applyOutputMapping(Map<String, Object> mapping, WorkflowState state) {
        return resolveTemplate(mapping, state);
    }

    public Object resolveValue(Object rawValue, WorkflowState state) {
        if (rawValue == null) return null;
        if (rawValue instanceof String str && str.startsWith("$.")) return getByPath(root(state), str);
        if (rawValue instanceof Map<?, ?> map) {
            Map<String, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                out.put(String.valueOf(entry.getKey()), resolveValue(entry.getValue(), state));
            }
            return out;
        }
        if (rawValue instanceof List<?> list) {
            List<Object> out = new ArrayList<>();
            for (Object item : list) out.add(resolveValue(item, state));
            return out;
        }
        return rawValue;
    }

    @SuppressWarnings("unchecked")
    public Object getByPath(Map<String, Object> root, String path) {
        if (path == null || !path.startsWith("$.")) return null;
        String[] tokens = path.substring(2).split("\\.");
        Object current = root;
        for (String token : tokens) {
            if (current == null) return null;
            if ("size".equals(token)) {
                current = sizeOf(current);
                continue;
            }
            if (current instanceof Map<?, ?> map) {
                current = ((Map<String, Object>) map).get(token);
            } else {
                return null;
            }
        }
        return current;
    }

    private int sizeOf(Object value) {
        if (value == null) return 0;
        if (value instanceof Collection<?> c) return c.size();
        if (value instanceof Map<?, ?> m) return m.size();
        if (value.getClass().isArray()) return Array.getLength(value);
        return 0;
    }
}
