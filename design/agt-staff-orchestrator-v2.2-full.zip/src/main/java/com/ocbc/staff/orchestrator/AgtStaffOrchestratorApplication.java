package com.ocbc.staff.orchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgtStaffOrchestratorApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgtStaffOrchestratorApplication.class, args);
    }
}
