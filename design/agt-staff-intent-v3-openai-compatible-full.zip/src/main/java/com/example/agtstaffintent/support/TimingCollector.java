package com.example.agtstaffintent.support;

import java.util.LinkedHashMap;
import java.util.Map;

public class TimingCollector {

    private final long startNanos = System.nanoTime();
    private long lastMark = startNanos;
    private final Map<String, Long> steps = new LinkedHashMap<>();

    public void mark(String step) {
        long now = System.nanoTime();
        steps.put(step, (now - lastMark) / 1_000_000);
        lastMark = now;
    }

    public long totalMs() {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    public Map<String, Long> steps() {
        return steps;
    }
}
