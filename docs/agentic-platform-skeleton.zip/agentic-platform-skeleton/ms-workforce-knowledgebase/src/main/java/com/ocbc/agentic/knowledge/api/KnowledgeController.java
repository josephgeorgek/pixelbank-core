package com.ocbc.agentic.knowledge.api;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/knowledge")
public class KnowledgeController {

    @PostMapping("/search")
    public List<Map<String, Object>> search(@RequestBody Map<String, Object> request) {
        return List.of(
                Map.of("type", "intent-taxonomy", "intent", "HOTDESK_BOOKING", "graphId", "book_hot_desk_v1"),
                Map.of("type", "knowledge", "title", "Hot Desk Policy", "summary", "Booking allowed for entitled staff")
        );
    }
}
