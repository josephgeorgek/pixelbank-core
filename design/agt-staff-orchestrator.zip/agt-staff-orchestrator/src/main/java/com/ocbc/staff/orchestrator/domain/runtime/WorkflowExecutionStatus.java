package com.ocbc.staff.orchestrator.domain.runtime;

public enum WorkflowExecutionStatus {
    RUNNING,
    COMPLETED,
    FAILED
}
