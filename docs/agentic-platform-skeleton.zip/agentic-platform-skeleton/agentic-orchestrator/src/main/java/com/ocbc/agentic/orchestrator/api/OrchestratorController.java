package com.ocbc.agentic.orchestrator.api;

import com.ocbc.agentic.common.model.OrchestrationResponse;
import com.ocbc.agentic.common.model.UserRequest;
import com.ocbc.agentic.orchestrator.service.OrchestratorService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orchestrator")
public class OrchestratorController {
    private final OrchestratorService orchestratorService;

    public OrchestratorController(OrchestratorService orchestratorService) {
        this.orchestratorService = orchestratorService;
    }

    @PostMapping("/execute")
    public OrchestrationResponse execute(@RequestBody UserRequest request) {
        return orchestratorService.execute(request);
    }
}
