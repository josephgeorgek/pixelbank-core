package com.example.healer;

public record AiPlanResult(
    String requestPrompt,
    String responseJson,
    String rationale
) {}
