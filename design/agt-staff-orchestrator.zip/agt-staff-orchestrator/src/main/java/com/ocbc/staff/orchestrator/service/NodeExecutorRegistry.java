package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.executor.NodeExecutor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class NodeExecutorRegistry {

    private final List<NodeExecutor> executors;

    public NodeExecutorRegistry(List<NodeExecutor> executors) {
        this.executors = executors;
    }

    public NodeExecutor require(GraphNodeDefinition node) {
        return executors.stream()
                .filter(executor -> executor.supports(node))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No executor for node taskType: " + node.taskType()));
    }
}
