package com.example.mcpgithub;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class GitHubPatchService {

  private static final Logger log = LoggerFactory.getLogger(GitHubPatchService.class);
  private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

  private final RestClient restClient;
  private final String token;
  private final String owner;
  private final String repo;
  private final String baseBranch;
  private final boolean mockMode;

  public GitHubPatchService(
      @Value("${github.token:}") String token,
      @Value("${github.owner}") String owner,
      @Value("${github.repo}") String repo,
      @Value("${github.base-branch:main}") String baseBranch,
      @Value("${github.mock-mode:false}") boolean mockMode) {

    this.token = token;
    this.owner = owner;
    this.repo = repo;
    this.baseBranch = baseBranch;
    this.mockMode = mockMode;

    this.restClient = RestClient.builder()
        .baseUrl("https://api.github.com")
        .defaultHeader("Authorization", "Bearer " + token)
        .defaultHeader("Accept", "application/vnd.github+json")
        .defaultHeader("X-GitHub-Api-Version", "2022-11-28")
        .build();
  }

  public Map<String,Object> createHotfixPr(GitHubHotfixRequest req) {
    validate(req);
    String branch = uniqueBranch(req.branchName());

    log.info("[GITHUB] createHotfixPr incident={} owner={} repo={} baseBranch={} mockMode={}",
        req.incidentId(), owner, repo, baseBranch, mockMode);

    if (mockMode) {
      String fakeUrl = "https://github.com/" + owner + "/" + repo + "/pulls?q=" + branch;
      log.warn("[GITHUB] MOCK MODE enabled. Returning fake PR URL={}", fakeUrl);
      return result("PR_MOCK_CREATED", branch, req.filePath(), fakeUrl);
    }

    if (token == null || token.isBlank() || token.equals("dummy")) {
      throw new GitHubToolException("GITHUB_PERSONAL_ACCESS_TOKEN is missing.", null);
    }

    try {
      String sha = getBaseBranchSha();
      log.info("[GITHUB] Base branch SHA resolved branch={} sha={}", baseBranch, sha);
      createBranch(branch, sha);
      log.info("[GITHUB] Branch created branch={}", branch);
      commitFile(req, branch);
      log.info("[GITHUB] File committed branch={} path={}", branch, req.filePath());
      String prUrl = createPullRequest(req, branch);
      log.info("[GITHUB] PR created url={}", prUrl);
      return result("PR_CREATED", branch, req.filePath(), prUrl);
    } catch (HttpClientErrorException e) {
      log.error("[GITHUB] API failed status={} body={}", e.getStatusCode(), e.getResponseBodyAsString(), e);
      throw new GitHubToolException(explain(e), e);
    } catch (Exception e) {
      log.error("[GITHUB] Unexpected failure", e);
      throw new GitHubToolException("Unexpected GitHub tool failure: " + e.getMessage(), e);
    }
  }

  private String getBaseBranchSha() {
    Map response = restClient.get()
        .uri("/repos/{owner}/{repo}/git/ref/heads/{branch}", owner, repo, baseBranch)
        .retrieve()
        .body(Map.class);
    Map object = (Map) response.get("object");
    return String.valueOf(object.get("sha"));
  }

  private void createBranch(String branch, String sha) {
    restClient.post()
        .uri("/repos/{owner}/{repo}/git/refs", owner, repo)
        .body(Map.of("ref", "refs/heads/" + branch, "sha", sha))
        .retrieve()
        .body(Map.class);
  }

  private void commitFile(GitHubHotfixRequest req, String branch) {
    String encoded = Base64.getEncoder().encodeToString(req.fileContent().getBytes(StandardCharsets.UTF_8));
    restClient.put()
        .uri("/repos/{owner}/{repo}/contents/{path}", owner, repo, req.filePath())
        .body(Map.of("message", req.commitMessage(), "content", encoded, "branch", branch))
        .retrieve()
        .body(Map.class);
  }

  private String createPullRequest(GitHubHotfixRequest req, String branch) {
    Map response = restClient.post()
        .uri("/repos/{owner}/{repo}/pulls", owner, repo)
        .body(Map.of("title", req.prTitle(), "head", branch, "base", baseBranch, "body", req.prBody()))
        .retrieve()
        .body(Map.class);
    return String.valueOf(response.get("html_url"));
  }

  private String uniqueBranch(String raw) {
    String cleaned = (raw == null || raw.isBlank()) ? "auto-heal/hotfix" : raw.trim();
    cleaned = cleaned.replace(" ", "-").replaceAll("[^a-zA-Z0-9_./-]", "-");
    return cleaned + "-" + LocalDateTime.now().format(TS);
  }

  private Map<String,Object> result(String status, String branch, String path, String prUrl) {
    Map<String,Object> out = new LinkedHashMap<>();
    out.put("status", status);
    out.put("owner", owner);
    out.put("repo", repo);
    out.put("baseBranch", baseBranch);
    out.put("branch", branch);
    out.put("filePath", path);
    out.put("pullRequestUrl", prUrl);
    return out;
  }

  private void validate(GitHubHotfixRequest req) {
    if (req.filePath() == null || req.filePath().isBlank()) throw new IllegalArgumentException("filePath is required");
    if (req.fileContent() == null || req.fileContent().isBlank()) throw new IllegalArgumentException("fileContent is required");
    if (req.commitMessage() == null || req.commitMessage().isBlank()) throw new IllegalArgumentException("commitMessage is required");
    if (req.prTitle() == null || req.prTitle().isBlank()) throw new IllegalArgumentException("prTitle is required");
  }

  private String explain(HttpClientErrorException e) {
    int status = e.getStatusCode().value();
    String body = e.getResponseBodyAsString();
    if (status == 401) return "GitHub 401 Unauthorized. Response: " + body;
    if (status == 403) return "GitHub 403 Forbidden. Fine-grained PAT needs Contents Read/Write + Pull Requests Read/Write. Response: " + body;
    if (status == 404) return "GitHub 404 Not Found. Response: " + body;
    if (status == 422) return "GitHub 422 Validation Failed. Response: " + body;
    return "GitHub API error " + status + ". Response: " + body;
  }
}
