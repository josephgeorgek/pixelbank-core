package com.example.agtstaffintent;

import com.example.agtstaffintent.domain.IntentTaxonomy;
import com.example.agtstaffintent.service.IntentSimilarityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class IntentSimilarityServiceTest {

    @Test
    void shouldRankMedicalReviewIntentHighest() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        IntentTaxonomy review;
        IntentTaxonomy approval;
        try (InputStream reviewStream = getClass().getResourceAsStream("/taxonomy/01-medical-cert-list-review.json");
             InputStream approvalStream = getClass().getResourceAsStream("/taxonomy/02-medical-cert-approval.json")) {
            review = mapper.readValue(reviewStream, IntentTaxonomy.class);
            approval = mapper.readValue(approvalStream, IntentTaxonomy.class);
        }

        IntentSimilarityService service = new IntentSimilarityService();
        var result = service.rank(
                "List all pending Medical leaves with medical certificate pending for my approval",
                "MANAGER",
                List.of(review, approval),
                2);

        assertThat(result.getFirst().taxonomy().intent())
                .isEqualTo("STAFF_LEAVE_APPLICATION_MEDICAL_CERT_LIST_AND_REVIEW");
        assertThat(result.getFirst().shortlisted()).isTrue();
    }

    @Test
    void shouldAvoidMatchingHipIssueToMedicalLeave() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        IntentTaxonomy medicalLeave;
        IntentTaxonomy issueStatus;
        try (InputStream medicalLeaveStream = getClass().getResourceAsStream("/taxonomy/05-self-medical-leave-status.json");
             InputStream issueStatusStream = getClass().getResourceAsStream("/taxonomy/06-self-case-status-tracking.json")) {
            medicalLeave = mapper.readValue(medicalLeaveStream, IntentTaxonomy.class);
            issueStatus = mapper.readValue(issueStatusStream, IntentTaxonomy.class);
        }

        IntentSimilarityService service = new IntentSimilarityService();
        var result = service.rank(
                "Find out status for my HIP issue raised",
                "STAFF",
                List.of(medicalLeave, issueStatus),
                2);

        assertThat(result.getFirst().taxonomy().intent())
                .isEqualTo("STAFF_SELF_CASE_STATUS_TRACKING");
        assertThat(result.stream()
                .filter(item -> item.taxonomy().intent().equals("STAFF_SELF_MEDICAL_LEAVE_STATUS_TRACKING"))
                .findFirst()
                .orElseThrow()
                .shortlisted()).isFalse();
    }
}
