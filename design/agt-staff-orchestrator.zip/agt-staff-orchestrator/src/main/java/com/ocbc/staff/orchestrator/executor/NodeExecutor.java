package com.ocbc.staff.orchestrator.executor;

import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;

import java.util.Map;

public interface NodeExecutor {

    boolean supports(GraphNodeDefinition node);

    Map<String, Object> execute(GraphNodeDefinition node, WorkflowState state);
}
