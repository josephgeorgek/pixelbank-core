# Component Dependencies (suggested)

## Common
- spring-boot-starter-actuator
- spring-boot-starter-validation
- spring-boot-starter-security
- springdoc-openapi-starter-webmvc-ui

## Agentic / AI services
- spring-ai-starter-model-openai-sdk (or your chosen provider)
- spring-ai-starter-mcp-client
- spring-ai-starter-vector-store-* (pick your store)
- LangGraph4j (or adapter library for Java graph execution)

## MCP server
- spring-ai-starter-mcp-server-webmvc

## Domain-facing services
- spring-boot-starter-web
- spring-boot-starter-webflux (if proxy/gateway/reactive)
