package com.ocbc.staff.orchestrator.executor;

import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import com.ocbc.staff.orchestrator.service.DelegateTaskClient;
import com.ocbc.staff.orchestrator.service.MappingResolverService;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class GenerateResponseNodeExecutor extends AbstractMappedNodeExecutor {

    public GenerateResponseNodeExecutor(MappingResolverService mappingResolverService,
                                        DelegateTaskClient delegateTaskClient) {
        super(mappingResolverService, delegateTaskClient);
    }

    @Override
    public boolean supports(GraphNodeDefinition node) {
        return "GENERATE_RESPONSE".equalsIgnoreCase(node.taskType());
    }

    @Override
    public Map<String, Object> execute(GraphNodeDefinition node, WorkflowState state) {
        return delegateTaskClient.invoke(node.delegateTo(), node.taskType(), resolvedPayload(node, state));
    }
}
