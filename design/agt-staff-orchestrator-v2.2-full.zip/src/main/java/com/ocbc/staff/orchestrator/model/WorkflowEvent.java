package com.ocbc.staff.orchestrator.model;

import java.time.Instant;

public class WorkflowEvent {
    private String executionId;
    private String nodeId;
    private String eventType;
    private String message;
    private Instant timestamp;
    private Long elapsedMs;

    public WorkflowEvent() {
    }

    public WorkflowEvent(String executionId, String nodeId, String eventType, String message, Instant timestamp) {
        this.executionId = executionId;
        this.nodeId = nodeId;
        this.eventType = eventType;
        this.message = message;
        this.timestamp = timestamp;
    }

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

    public Long getElapsedMs() {
        return elapsedMs;
    }

    public void setElapsedMs(Long elapsedMs) {
        this.elapsedMs = elapsedMs;
    }
}
