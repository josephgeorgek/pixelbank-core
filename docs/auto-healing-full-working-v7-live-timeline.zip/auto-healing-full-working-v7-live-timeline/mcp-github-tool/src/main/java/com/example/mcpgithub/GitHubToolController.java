package com.example.mcpgithub;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/tools/github")
public class GitHubToolController {

  private final GitHubPatchService service;

  public GitHubToolController(GitHubPatchService service) {
    this.service = service;
  }

  @PostMapping("/create-hotfix-pr")
  public Map<String,Object> createHotfixPr(@RequestBody GitHubHotfixRequest req) {
    return service.createHotfixPr(req);
  }

  @ExceptionHandler(GitHubToolException.class)
  @ResponseStatus(HttpStatus.BAD_GATEWAY)
  public Map<String,Object> handleGitHubToolException(GitHubToolException ex) {
    Map<String,Object> out = new LinkedHashMap<>();
    out.put("status", "GITHUB_TOOL_FAILED");
    out.put("message", ex.getMessage());
    return out;
  }

  @ExceptionHandler(IllegalArgumentException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public Map<String,Object> handleBadRequest(IllegalArgumentException ex) {
    Map<String,Object> out = new LinkedHashMap<>();
    out.put("status", "BAD_REQUEST");
    out.put("message", ex.getMessage());
    return out;
  }
}
