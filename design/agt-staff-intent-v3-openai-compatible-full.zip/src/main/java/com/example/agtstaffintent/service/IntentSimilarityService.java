package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentTaxonomy;
import com.example.agtstaffintent.domain.RankedIntent;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class IntentSimilarityService {

    public List<RankedIntent> rank(String normalizedPrompt, String userRole, List<IntentTaxonomy> taxonomies) {
        Set<String> promptTokens = tokens(normalizedPrompt);
        List<RankedIntent> ranked = new ArrayList<>();

        for (IntentTaxonomy taxonomy : taxonomies) {
            List<String> matchedSignals = new ArrayList<>();
            List<String> rejectedSignals = new ArrayList<>();

            double jaccard = jaccard(promptTokens, collectTokens(taxonomy.description(), taxonomy.intent()));
            double keywordBoost = overlapScore(promptTokens, taxonomy.keywords(), matchedSignals, "keyword") * 0.20;
            double synonymBoost = overlapScore(promptTokens, taxonomy.synonyms(), matchedSignals, "synonym") * 0.35;
            double exampleBoost = overlapScore(promptTokens, taxonomy.examples(), matchedSignals, "example") * 0.15;
            double negativePenalty = overlapScore(promptTokens, taxonomy.negativeKeywords(), rejectedSignals, "negative") * -0.40;

            double personaBoost = 0.0;
            if (taxonomy.persona() != null && !"ANY".equalsIgnoreCase(taxonomy.persona())) {
                if (taxonomy.persona().equalsIgnoreCase(userRole)) {
                    personaBoost = 0.20;
                    matchedSignals.add("persona-match");
                } else {
                    personaBoost = -0.35;
                    rejectedSignals.add("persona-mismatch");
                }
            }

            if (requiresMedicalAnchor(taxonomy.intent()) && !hasAny(promptTokens, Set.of("medical", "leave", "certificate"))) {
                rejectedSignals.add("missing-anchor:medical-leave");
            }

            if (requiresCaseAnchor(taxonomy.intent()) && !hasAny(promptTokens, Set.of("issue", "case", "ticket", "request", "status"))) {
                rejectedSignals.add("missing-anchor:case-status");
            }

            double finalScore = jaccard + keywordBoost + synonymBoost + exampleBoost + negativePenalty + personaBoost;
            ranked.add(new RankedIntent(taxonomy, finalScore, matchedSignals, rejectedSignals));
        }

        return ranked.stream()
                .sorted(Comparator.comparingDouble(RankedIntent::score).reversed())
                .limit(3)
                .collect(Collectors.toList());
    }

    private boolean requiresMedicalAnchor(String intent) {
        return Set.of(
                "STAFF_SELF_MEDICAL_LEAVE_STATUS_TRACKING",
                "STAFF_LEAVE_APPLICATION_MEDICAL_CERT_LIST_AND_REVIEW",
                "STAFF_LEAVE_APPLICATION_WITH_MEDICAL_CERT_APPROVAL"
        ).contains(intent);
    }

    private boolean requiresCaseAnchor(String intent) {
        return "STAFF_SELF_CASE_STATUS_TRACKING".equals(intent);
    }

    private boolean hasAny(Set<String> promptTokens, Set<String> anchors) {
        for (String token : anchors) {
            if (promptTokens.contains(token)) {
                return true;
            }
        }
        return false;
    }

    private Set<String> collectTokens(String... values) {
        Set<String> result = new HashSet<>();
        for (String value : values) {
            result.addAll(tokens(value));
        }
        return result;
    }

    private double overlapScore(Set<String> promptTokens, List<String> values, List<String> signalCollector, String prefix) {
        if (values == null || values.isEmpty()) {
            return 0.0;
        }
        double score = 0.0;
        for (String value : values) {
            Set<String> candidate = tokens(value);
            if (!Collections.disjoint(promptTokens, candidate)) {
                score += 1.0;
                signalCollector.add(prefix + ":" + value);
            }
        }
        return score;
    }

    private double jaccard(Set<String> a, Set<String> b) {
        if (a.isEmpty() || b.isEmpty()) {
            return 0.0;
        }
        Set<String> intersection = new HashSet<>(a);
        intersection.retainAll(b);
        Set<String> union = new HashSet<>(a);
        union.addAll(b);
        return union.isEmpty() ? 0.0 : ((double) intersection.size() / union.size());
    }

    private Set<String> tokens(String value) {
        if (value == null || value.isBlank()) {
            return Set.of();
        }
        return Arrays.stream(value.toLowerCase().split("\s+"))
                .filter(token -> !token.isBlank())
                .collect(Collectors.toSet());
    }
}
