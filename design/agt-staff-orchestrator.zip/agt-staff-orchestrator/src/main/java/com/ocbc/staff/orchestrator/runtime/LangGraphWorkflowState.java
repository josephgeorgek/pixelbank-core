package com.ocbc.staff.orchestrator.runtime;

import org.bsc.langgraph4j.state.AgentState;
import org.bsc.langgraph4j.state.Channel;
import org.bsc.langgraph4j.state.Channels;

import java.util.LinkedHashMap;
import java.util.Map;

public class LangGraphWorkflowState extends AgentState {

    public static final String WORKFLOW_STATE = "workflowState";

    public static final Map<String, Channel<?>> SCHEMA = Map.of(
            WORKFLOW_STATE, Channels.defaultTo(LinkedHashMap::new)
    );

    public LangGraphWorkflowState(Map<String, Object> initData) {
        super(initData);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> workflowState() {
        return this.<Map<String, Object>>value(WORKFLOW_STATE).orElseGet(LinkedHashMap::new);
    }
}
