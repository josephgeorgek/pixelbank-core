package com.joseph.deepwiki.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "code_files", indexes = @Index(name="idx_code_files_wiki", columnList="wikiId"))
public class CodeFileEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String wikiId;
    @Column(length = 2000) public String path;
    public String language;
    public long bytes;
    @Lob @Column(columnDefinition = "CLOB") public String preview;
    public CodeFileEntity() {}
}
