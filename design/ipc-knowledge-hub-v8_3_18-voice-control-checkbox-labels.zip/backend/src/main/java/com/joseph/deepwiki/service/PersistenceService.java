package com.joseph.deepwiki.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.joseph.deepwiki.entity.*;
import com.joseph.deepwiki.model.WikiModels.*;
import com.joseph.deepwiki.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PersistenceService {
    private final ObjectMapper objectMapper;
    private final WorkspaceRepository workspaceRepository;
    private final WikiRepository wikiRepository;
    private final CodeFileRepository codeFileRepository;
    private final CodeChunkRepository codeChunkRepository;
    private final SymbolRepository symbolRepository;
    private final GraphNodeRepository graphNodeRepository;
    private final GraphEdgeRepository graphEdgeRepository;
    private final DiagramArtifactRepository diagramArtifactRepository;
    private final IndexJobRepository indexJobRepository;
    private final KeyContributorRepository keyContributorRepository;

    public PersistenceService(ObjectMapper objectMapper,
                              WorkspaceRepository workspaceRepository,
                              WikiRepository wikiRepository,
                              CodeFileRepository codeFileRepository,
                              CodeChunkRepository codeChunkRepository,
                              SymbolRepository symbolRepository,
                              GraphNodeRepository graphNodeRepository,
                              GraphEdgeRepository graphEdgeRepository,
                              DiagramArtifactRepository diagramArtifactRepository,
                              IndexJobRepository indexJobRepository,
                              KeyContributorRepository keyContributorRepository) {
        this.objectMapper = objectMapper;
        this.workspaceRepository = workspaceRepository;
        this.wikiRepository = wikiRepository;
        this.codeFileRepository = codeFileRepository;
        this.codeChunkRepository = codeChunkRepository;
        this.symbolRepository = symbolRepository;
        this.graphNodeRepository = graphNodeRepository;
        this.graphEdgeRepository = graphEdgeRepository;
        this.diagramArtifactRepository = diagramArtifactRepository;
        this.indexJobRepository = indexJobRepository;
        this.keyContributorRepository = keyContributorRepository;
    }

    @Transactional
    public void saveWiki(WikiResponse wiki) {
        saveWiki(wiki, null);
    }

    @Transactional
    public void saveWiki(WikiResponse wiki, String workspaceId) {
        WikiEntity e = new WikiEntity();
        e.id = wiki.id(); e.workspaceId = workspaceId; e.repoUrl = wiki.repoUrl(); e.branch = wiki.branch();
        e.overview = wiki.overview(); e.architectureMermaid = wiki.architectureMermaid(); e.generatedAt = wiki.generatedAt();
        e.createdAt = Instant.now(); e.updatedAt = Instant.now(); e.jsonPayload = json(wiki);
        wikiRepository.save(e);

        codeFileRepository.deleteByWikiId(wiki.id());
        codeChunkRepository.deleteByWikiId(wiki.id());
        symbolRepository.deleteByWikiId(wiki.id());
        graphNodeRepository.deleteByWikiId(wiki.id());
        graphEdgeRepository.deleteByWikiId(wiki.id());
        diagramArtifactRepository.deleteByWikiId(wiki.id());

        for (FileSummary f : wiki.files()) {
            CodeFileEntity cf = new CodeFileEntity();
            cf.wikiId = wiki.id(); cf.path = f.path(); cf.language = f.language(); cf.bytes = f.bytes(); cf.preview = f.preview();
            codeFileRepository.save(cf);
        }
        for (CodeChunk c : wiki.chunks()) {
            CodeChunkEntity cc = new CodeChunkEntity();
            cc.id = c.id(); cc.wikiId = wiki.id(); cc.path = c.path(); cc.language = c.language(); cc.startLine = c.startLine(); cc.endLine = c.endLine(); cc.content = c.content(); cc.symbolsText = String.join(",", c.symbols());
            codeChunkRepository.save(cc);
        }
        for (SymbolRef s : wiki.symbols()) {
            SymbolEntity se = new SymbolEntity();
            se.wikiId = wiki.id(); se.path = s.path(); se.symbol = s.symbol(); se.kind = s.kind(); se.line = s.line();
            symbolRepository.save(se);
        }
        for (GraphNode n : wiki.architectureGraph().nodes()) {
            GraphNodeEntity ge = new GraphNodeEntity();
            ge.wikiId = wiki.id(); ge.nodeId = n.id(); ge.label = n.label(); ge.nodeType = n.type(); ge.path = n.path(); ge.language = n.language(); ge.groupName = n.group(); ge.bytes = n.bytes();
            ge.lineNumber = inferLine(wiki.symbols(), n.path(), n.label()); ge.evidenceKind = evidenceKindForNode(n); ge.confidence = confidenceForNode(n);
            graphNodeRepository.save(ge);
        }
        for (GraphEdge edge : wiki.architectureGraph().edges()) {
            GraphEdgeEntity ee = new GraphEdgeEntity();
            ee.wikiId = wiki.id(); ee.edgeId = edge.id(); ee.sourceNodeId = edge.source(); ee.targetNodeId = edge.target(); ee.edgeType = edge.kind(); ee.label = edge.label();
            ee.path = evidencePathForEdge(wiki, edge); ee.lineNumber = 0; ee.evidenceKind = evidenceKindForEdge(edge); ee.confidence = confidenceForEdge(edge);
            graphEdgeRepository.save(ee);
        }
        saveDiagram(wiki.id(), null, "COMPONENT", wiki.architectureMermaid(), status(wiki.architectureGraph().nodes().size(), wiki.architectureGraph().edges().size()), confidence(wiki.architectureGraph()), wiki.architectureGraph().nodes().size(), wiki.architectureGraph().edges().size(), evidenceSummary(wiki), "Generated from evidence-backed graph nodes and edges only.");
    }

    @Transactional
    public void saveWorkspace(WorkspaceResponse workspace) {
        WorkspaceEntity e = new WorkspaceEntity();
        e.id = workspace.id(); e.repoUrls = String.join("\n", workspace.repoUrls()); e.branch = workspace.branch(); e.summary = workspace.summary(); e.overview = workspace.overview(); e.generatedAt = workspace.generatedAt(); e.createdAt = Instant.now(); e.updatedAt = Instant.now(); e.jsonPayload = json(workspace);
        workspaceRepository.save(e);
        for (WikiResponse wiki : workspace.wikis()) saveWiki(wiki, workspace.id());
        diagramArtifactRepository.deleteByWorkspaceId(workspace.id());
        saveDiagram(null, workspace.id(), "WORKSPACE_INTERACTION", workspace.diagrams().interactionComponentMermaid(), diagramStatus(workspace.diagrams().interactionComponentMermaid()), "MEDIUM", workspace.totalGraphNodes(), workspace.totalGraphEdges(), "Cross-repo edges are based only on detected source references. If no evidence exists, diagram states insufficient evidence.", "No synthetic candidate arrows are generated.");
        saveDiagram(null, workspace.id(), "SEQUENCE", workspace.diagrams().sequenceMermaid(), diagramStatus(workspace.diagrams().sequenceMermaid()), "MEDIUM", workspace.totalGraphNodes(), workspace.totalGraphEdges(), "Sequence is generated only when controller/service/repository chains exist.", "Not runtime tracing.");
        saveDiagram(null, workspace.id(), "GITDIAGRAM", workspace.diagrams().combinedComponentMermaid(), "AVAILABLE", "HIGH", workspace.repositories().size(), 0, "Repository topology based on repo names, languages, file/chunk/symbol counts.", "Topology, not runtime flow.");
    }

    @Transactional
    public void saveKeyContributors(String workspaceId, List<com.joseph.deepwiki.model.WikiModels.KeyContributor> contributors) {
        keyContributorRepository.deleteByWorkspaceId(workspaceId);
        int i = 1;
        for (com.joseph.deepwiki.model.WikiModels.KeyContributor c : contributors.stream().limit(5).toList()) {
            KeyContributorEntity e = new KeyContributorEntity();
            e.workspaceId = workspaceId; e.repoName = c.repoName(); e.contributorName = c.name(); e.sourceType = c.sourceType(); e.rankOrder = i++;
            keyContributorRepository.save(e);
        }
    }

    @Transactional
    public void saveJob(String jobId, String jobType, String status, String stage, int progress, String message, String wikiId, String workspaceId, String error, Instant createdAt, Instant updatedAt) {
        IndexJobEntity e = indexJobRepository.findById(jobId).orElseGet(IndexJobEntity::new);
        e.jobId = jobId; e.jobType = jobType; e.status = status; e.stage = stage; e.progress = progress; e.message = message; e.wikiId = wikiId; e.workspaceId = workspaceId; e.error = error; e.createdAt = createdAt; e.updatedAt = updatedAt;
        indexJobRepository.save(e);
    }

    @Transactional(readOnly = true)
    public Optional<WikiResponse> findWiki(String id) {
        return wikiRepository.findById(id).flatMap(e -> fromJson(e.jsonPayload, WikiResponse.class));
    }

    @Transactional(readOnly = true)
    public Optional<WorkspaceResponse> findWorkspace(String id) {
        return workspaceRepository.findById(id).flatMap(e -> fromJson(e.jsonPayload, WorkspaceResponse.class));
    }

    @Transactional(readOnly = true)
    public Collection<WikiResponse> listWikis() {
        return wikiRepository.findAll().stream().map(e -> fromJson(e.jsonPayload, WikiResponse.class)).flatMap(Optional::stream).toList();
    }

    @Transactional(readOnly = true)
    public Collection<WorkspaceResponse> listWorkspaces() {
        return workspaceRepository.findAll().stream().map(e -> fromJson(e.jsonPayload, WorkspaceResponse.class)).flatMap(Optional::stream).toList();
    }


    @Transactional(readOnly = true)
    public List<Map<String, Object>> diagramsForWorkspace(String workspaceId) {
        return diagramArtifactRepository.findByWorkspaceId(workspaceId).stream().map(d -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("type", d.diagramType);
            map.put("status", d.status);
            map.put("confidence", d.confidenceLevel);
            map.put("nodeCount", d.nodeCount);
            map.put("edgeCount", d.edgeCount);
            map.put("evidenceSummary", d.evidenceSummary);
            map.put("notes", d.notes);
            map.put("mermaid", d.mermaidText);
            return map;
        }).toList();
    }

    @Transactional(readOnly = true)
    public Map<String, Object> storageStats() {
        return Map.of(
                "workspaces", workspaceRepository.count(),
                "wikis", wikiRepository.count(),
                "files", codeFileRepository.count(),
                "chunks", codeChunkRepository.count(),
                "symbols", symbolRepository.count(),
                "graphNodes", graphNodeRepository.count(),
                "graphEdges", graphEdgeRepository.count(),
                "diagrams", diagramArtifactRepository.count(),
                "keyContributors", keyContributorRepository.count(),
                "jobs", indexJobRepository.count()
        );
    }

    private void saveDiagram(String wikiId, String workspaceId, String type, String mermaid, String status, String conf, int nodes, int edges, String evidence, String notes) {
        DiagramArtifactEntity d = new DiagramArtifactEntity();
        d.wikiId = wikiId; d.workspaceId = workspaceId; d.diagramType = type; d.mermaidText = mermaid; d.status = status; d.confidenceLevel = conf; d.nodeCount = nodes; d.edgeCount = edges; d.evidenceSummary = evidence; d.notes = notes; d.generatedAt = Instant.now();
        diagramArtifactRepository.save(d);
    }

    private String json(Object o) { try { return objectMapper.writeValueAsString(o); } catch (Exception e) { throw new IllegalStateException("JSON persistence failed", e); } }
    private <T> Optional<T> fromJson(String json, Class<T> type) { try { return Optional.of(objectMapper.readValue(json, type)); } catch (Exception e) { return Optional.empty(); } }
    private int inferLine(List<SymbolRef> symbols, String path, String label) { return symbols.stream().filter(s -> Objects.equals(s.path(), path) && (s.symbol().equals(label) || label.contains(s.symbol()))).map(SymbolRef::line).findFirst().orElse(0); }
    private String evidenceKindForNode(GraphNode n) { return switch (n.type()) { case "controller" -> "spring-controller-or-route"; case "service" -> "service-class"; case "repository" -> "repository-or-dao"; case "react-component" -> "react-component"; case "config" -> "configuration-file"; default -> "source-file"; }; }
    private String confidenceForNode(GraphNode n) { return Set.of("controller","service","repository","react-component","config").contains(n.type()) ? "HIGH" : "MEDIUM"; }
    private String evidenceKindForEdge(GraphEdge e) { return Optional.ofNullable(e.kind()).orElse("dependency"); }
    private String confidenceForEdge(GraphEdge e) { return Set.of("import","react-import","spring-link","runtime-flow","dependency").contains(e.kind()) ? "MEDIUM" : "LOW"; }
    private String evidencePathForEdge(WikiResponse wiki, GraphEdge e) { return wiki.architectureGraph().nodes().stream().filter(n -> n.id().equals(e.source())).map(GraphNode::path).findFirst().orElse(""); }
    private String status(int nodes, int edges) { return nodes >= 3 && edges >= 1 ? "AVAILABLE" : "INSUFFICIENT_EVIDENCE"; }
    private String diagramStatus(String mermaid) { return mermaid != null && mermaid.contains("INSUFFICIENT_EVIDENCE") ? "INSUFFICIENT_EVIDENCE" : "AVAILABLE"; }
    private String confidence(ArchitectureGraph g) { return g.nodes().size() >= 5 && g.edges().size() >= 3 ? "HIGH" : "MEDIUM"; }
    private String evidenceSummary(WikiResponse wiki) {
        return wiki.architectureGraph().nodeTypeStats().entrySet().stream().map(e -> e.getKey()+": "+e.getValue()).collect(Collectors.joining(", "));
    }
}
