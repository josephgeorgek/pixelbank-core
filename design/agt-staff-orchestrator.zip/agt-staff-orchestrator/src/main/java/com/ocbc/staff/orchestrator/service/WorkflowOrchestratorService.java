package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.api.dto.StartWorkflowRequest;
import com.ocbc.staff.orchestrator.domain.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowExecutionStatus;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import com.ocbc.staff.orchestrator.runtime.LangGraphWorkflowRunner;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class WorkflowOrchestratorService {

    private final GraphRegistryService graphRegistryService;
    private final InMemoryWorkflowStateStore stateStore;
    private final LangGraphWorkflowRunner langGraphWorkflowRunner;

    public WorkflowOrchestratorService(GraphRegistryService graphRegistryService,
                                       InMemoryWorkflowStateStore stateStore,
                                       LangGraphWorkflowRunner langGraphWorkflowRunner) {
        this.graphRegistryService = graphRegistryService;
        this.stateStore = stateStore;
        this.langGraphWorkflowRunner = langGraphWorkflowRunner;
    }

    public WorkflowState start(StartWorkflowRequest request) {
        GraphDefinition graph = graphRegistryService.require(request.getGraphId());

        WorkflowState state = new WorkflowState();
        state.setExecutionId(UUID.randomUUID().toString());
        state.setGraphId(graph.graphId());
        state.setGraphVersion(graph.version());
        state.setStatus(WorkflowExecutionStatus.RUNNING);
        state.setInput(request.getInput());
        state.setIntentResult(request.getIntentResult());
        state.setStartedAt(Instant.now());
        state.setUpdatedAt(Instant.now());

        WorkflowState executed = langGraphWorkflowRunner.run(graph, state);
        stateStore.save(executed);
        return executed;
    }

    public WorkflowState get(String executionId) {
        return stateStore.get(executionId);
    }
}
