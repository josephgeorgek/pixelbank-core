package com.ocbc.staff.orchestrator.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ocbc.staff.orchestrator.graph.ErrorHandlerDefinition;
import com.ocbc.staff.orchestrator.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.model.NodeStatus;
import com.ocbc.staff.orchestrator.model.WorkflowEvent;
import com.ocbc.staff.orchestrator.model.WorkflowExecution;
import com.ocbc.staff.orchestrator.model.WorkflowState;
import com.ocbc.staff.orchestrator.model.WorkflowStatus;
import com.ocbc.staff.orchestrator.repository.InMemoryWorkflowRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class WorkflowEngine {
    private static final Logger log = LoggerFactory.getLogger(WorkflowEngine.class);

    private final MappingResolverService resolver;
    private final TransitionEvaluationService transitionEvaluationService;
    private final ExternalNodeExecutionService externalNodeExecutionService;
    private final InMemoryWorkflowRepository repository;
    private final ObjectMapper objectMapper;

    public WorkflowEngine(MappingResolverService resolver,
                          TransitionEvaluationService transitionEvaluationService,
                          ExternalNodeExecutionService externalNodeExecutionService,
                          InMemoryWorkflowRepository repository,
                          ObjectMapper objectMapper) {
        this.resolver = resolver;
        this.transitionEvaluationService = transitionEvaluationService;
        this.externalNodeExecutionService = externalNodeExecutionService;
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    public void execute(GraphDefinition graph, WorkflowState state) {
        Map<String, GraphNodeDefinition> nodeIndex = new LinkedHashMap<>();
        for (GraphNodeDefinition node : graph.getNodes()) {
            nodeIndex.put(node.getId(), node);
            state.getNodeStatuses().putIfAbsent(node.getId(), NodeStatus.PENDING);
        }
        persist(state);

        log.info("[WORKFLOW_EXECUTION_START] executionId={} graphId={} entryNode={}", state.getExecutionId(), graph.getGraphId(), graph.getEntryNode());

        while (state.getCurrentNodeId() != null) {
            GraphNodeDefinition node = nodeIndex.get(state.getCurrentNodeId());
            if (node == null) {
                fail(state, "Unknown nodeId: " + state.getCurrentNodeId(), null);
                return;
            }

            log.info("[NODE_CURRENT] executionId={} currentNode={} nodeType={} taskType={}",
                    state.getExecutionId(), node.getId(), node.getType(), node.getTaskType());

            if ("END".equalsIgnoreCase(node.getType())) {
                handleEndNode(state, node);
                return;
            }

            Instant start = Instant.now();
            state.getNodeStatuses().put(node.getId(), NodeStatus.RUNNING);
            state.setUpdatedAt(Instant.now());
            persist(state);
            event(state.getExecutionId(), node.getId(), "NODE_START", "Node started", null);

            try {
                Map<String, Object> result = "STATE_UPDATE".equalsIgnoreCase(node.getTaskType())
                        ? applyStateUpdate(node, state)
                        : externalNodeExecutionService.execute(node, state);

                log.info("[NODE_RESULT] executionId={} nodeId={} result={}", state.getExecutionId(), node.getId(), toJson(result));
                applyNodeResultToState(node, state, result);

                log.info("[STATE_AFTER_NODE] executionId={} nodeId={} stateFields={{allowed:{}, pendingLeavesSize:{}, reviewResult:{}, finalResponse:{}, outcome:{}}}",
                        state.getExecutionId(), node.getId(), state.getAllowed(),
                        state.getPendingLeaves() == null ? 0 : state.getPendingLeaves().size(),
                        toJson(state.getReviewResult()), toJson(state.getFinalResponse()), toJson(state.getOutcome()));

                state.getNodeStatuses().put(node.getId(), NodeStatus.COMPLETED);
                state.setUpdatedAt(Instant.now());

                long elapsedMs = Duration.between(start, Instant.now()).toMillis();
                String nextNode = transitionEvaluationService.resolveNextNode(node, state);

                event(state.getExecutionId(), node.getId(), "NODE_END", "Node completed", elapsedMs);
                event(state.getExecutionId(), node.getId(), "TRANSITION", "Transition selected -> " + nextNode, null);

                log.info("[NODE_END] executionId={} nodeId={} taskType={} delegateTo={} nextNode={} elapsedMs={}",
                        state.getExecutionId(), node.getId(), node.getTaskType(), node.getDelegateTo(), nextNode, elapsedMs);

                state.setCurrentNodeId(nextNode);
                persist(state);
            } catch (Exception ex) {
                handleNodeError(state, node, ex);
                if (state.getStatus() == WorkflowStatus.FAILED) return;
            }
        }

        fail(state, "Workflow stopped without reaching an END node", null);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> applyStateUpdate(GraphNodeDefinition node, WorkflowState state) {
        Map<String, Object> config = castMap(node.getConfig());
        Map<String, Object> stateMapping = castMap(config.get("stateMapping"));
        Map<String, Object> resolved = resolver.resolveTemplate(stateMapping, state);
        if (resolved.containsKey("outcome")) {
            Object outcome = resolved.get("outcome");
            if (outcome instanceof Map<?, ?> map) {
                state.setOutcome((Map<String, Object>) map);
            }
        }
        return resolved;
    }

    @SuppressWarnings("unchecked")
    private void applyNodeResultToState(GraphNodeDefinition node, WorkflowState state, Map<String, Object> result) {
        switch (node.getId()) {
            case "node_guard_list_review_access" -> {
                Object allowed = result.get("allowed");
                if (allowed instanceof Boolean value) state.setAllowed(value);
            }
            case "node_list_pending_medical_leaves", "node_list_action_medical_leaves" -> {
                Object items = result.get("items");
                if (items instanceof List<?> list) state.setPendingLeaves((List<Map<String, Object>>) list);
            }
            case "node_bulk_ocr_and_validate", "node_approve_medical_leaves" -> state.setReviewResult(result);
            case "node_prepare_terminal_response", "node_prepare_review_summary" -> state.setFinalResponse(result);
            default -> {
            }
        }
    }

    private void handleEndNode(WorkflowState state, GraphNodeDefinition node) {
        Map<String, Object> outputMapping = castMap(node.getConfig().getOrDefault("outputMapping", Map.of()));
        log.info("[END_NODE_START] executionId={} nodeId={} outputMapping={}", state.getExecutionId(), node.getId(), toJson(outputMapping));
        state.setFinalOutput(resolver.applyOutputMapping(outputMapping, state));
        state.getNodeStatuses().put(node.getId(), NodeStatus.COMPLETED);
        state.setStatus("FAILED".equals(String.valueOf(state.getFinalOutput().get("status"))) ? WorkflowStatus.FAILED : WorkflowStatus.COMPLETED);
        state.setCompletedAt(Instant.now());
        state.setUpdatedAt(state.getCompletedAt());
        log.info("[END_NODE_OUTPUT] executionId={} nodeId={} finalOutput={}", state.getExecutionId(), node.getId(), toJson(state.getFinalOutput()));
        event(state.getExecutionId(), node.getId(), "WORKFLOW_END", "Workflow reached end node", null);
        persist(state);
        log.info("[WORKFLOW_EXECUTION_END] executionId={} finalNode={} finalStatus={}", state.getExecutionId(), node.getId(), state.getStatus());
    }

    private void handleNodeError(WorkflowState state, GraphNodeDefinition node, Exception ex) {
        state.getNodeStatuses().put(node.getId(), NodeStatus.FAILED);
        state.setUpdatedAt(Instant.now());

        Map<String, Object> error = new LinkedHashMap<>();
        error.put("nodeId", node.getId());
        error.put("message", ex.getMessage());
        error.put("timestamp", Instant.now().toString());
        state.getErrors().add(error);

        log.error("[NODE_ERROR] executionId={} nodeId={} error={} errors={}",
                state.getExecutionId(), node.getId(), ex.getMessage(), toJson(state.getErrors()));

        event(state.getExecutionId(), node.getId(), "NODE_ERROR", ex.getMessage(), null);

        ErrorHandlerDefinition onError = node.getOnError();
        if (onError != null) {
            log.warn("[NODE_ERROR_TRANSITION] executionId={} nodeId={} nextNode={} reason=onError handler",
                    state.getExecutionId(), node.getId(), onError.getNext());
            state.setCurrentNodeId(onError.getNext());
            persist(state);
            return;
        }

        fail(state, ex.getMessage(), node.getId());
    }

    private void fail(WorkflowState state, String message, String nodeId) {
        Map<String, Object> error = new LinkedHashMap<>();
        error.put("nodeId", nodeId);
        error.put("message", message);
        error.put("timestamp", Instant.now().toString());
        state.getErrors().add(error);

        state.setStatus(WorkflowStatus.FAILED);
        state.setCompletedAt(Instant.now());
        state.setUpdatedAt(state.getCompletedAt());
        persist(state);

        log.error("[WORKFLOW_FAILED] executionId={} nodeId={} message={} errors={}",
                state.getExecutionId(), nodeId, message, toJson(state.getErrors()));

        event(state.getExecutionId(), nodeId, "WORKFLOW_FAILED", message, null);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> castMap(Object value) {
        if (value instanceof Map<?, ?> map) return (Map<String, Object>) map;
        return new LinkedHashMap<>();
    }

    private void persist(WorkflowState state) {
        repository.saveState(state);
        repository.saveExecution(snapshot(state));
    }

    private WorkflowExecution snapshot(WorkflowState state) {
        WorkflowExecution execution = new WorkflowExecution();
        execution.setExecutionId(state.getExecutionId());
        execution.setGraphId(state.getGraphId());
        execution.setGraphVersion(state.getGraphVersion());
        execution.setStatus(state.getStatus());
        execution.setCurrentNodeId(state.getCurrentNodeId());
        execution.setStartedAt(state.getStartedAt());
        execution.setUpdatedAt(state.getUpdatedAt());
        execution.setCompletedAt(state.getCompletedAt());
        execution.setNodeStatuses(new LinkedHashMap<>(state.getNodeStatuses()));
        execution.setFinalOutput(new LinkedHashMap<>(state.getFinalOutput()));
        if (!state.getErrors().isEmpty()) {
            execution.setFailureReason(String.valueOf(state.getErrors().get(state.getErrors().size() - 1).get("message")));
        }
        return execution;
    }

    private void event(String executionId, String nodeId, String type, String message, Long elapsedMs) {
        WorkflowEvent event = new WorkflowEvent(executionId, nodeId, type, message, Instant.now());
        event.setElapsedMs(elapsedMs);
        repository.addEvent(executionId, event);
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException ex) {
            return String.valueOf(value);
        }
    }
}
