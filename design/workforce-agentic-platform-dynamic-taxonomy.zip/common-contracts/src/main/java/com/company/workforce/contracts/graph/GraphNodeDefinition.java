package com.company.workforce.contracts.graph;

import java.util.List;
import java.util.Map;

public record GraphNodeDefinition(
        String id,
        String type,
        String taskType,
        String delegateTo,
        Map<String, Object> config,
        List<String> candidateIntents,
        String domain,
        String next
) {
}
