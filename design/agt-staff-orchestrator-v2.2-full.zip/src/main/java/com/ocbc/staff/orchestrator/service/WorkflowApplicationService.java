package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.api.dto.StartWorkflowRequest;
import com.ocbc.staff.orchestrator.api.dto.StartWorkflowResponse;
import com.ocbc.staff.orchestrator.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.model.WorkflowEvent;
import com.ocbc.staff.orchestrator.model.WorkflowExecution;
import com.ocbc.staff.orchestrator.model.WorkflowState;
import com.ocbc.staff.orchestrator.model.WorkflowStatus;
import com.ocbc.staff.orchestrator.repository.InMemoryWorkflowRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.ExecutorService;

@Service
public class WorkflowApplicationService {
    private static final Logger log = LoggerFactory.getLogger(WorkflowApplicationService.class);

    private final InMemoryWorkflowRepository repository;
    private final GraphRegistryService graphRegistryService;
    private final WorkflowEngine workflowEngine;
    private final ExecutorService workflowExecutorService;

    public WorkflowApplicationService(InMemoryWorkflowRepository repository,
                                      GraphRegistryService graphRegistryService,
                                      WorkflowEngine workflowEngine,
                                      ExecutorService workflowExecutorService) {
        this.repository = repository;
        this.graphRegistryService = graphRegistryService;
        this.workflowEngine = workflowEngine;
        this.workflowExecutorService = workflowExecutorService;
    }

    public StartWorkflowResponse start(StartWorkflowRequest request) {
        GraphDefinition graph = graphRegistryService.getRequiredGraph(request.getGraphId());

        WorkflowState state = new WorkflowState();
        state.setExecutionId(UUID.randomUUID().toString());
        state.setGraphId(graph.getGraphId());
        state.setGraphVersion(graph.getVersion());
        state.setStatus(WorkflowStatus.RUNNING);
        state.setCurrentNodeId(graph.getEntryNode());
        state.setStartedAt(Instant.now());
        state.setUpdatedAt(state.getStartedAt());
        state.setInput(request.getInput() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(request.getInput()));
        state.setIntentResult(request.getIntentResult() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(request.getIntentResult()));

        repository.saveState(state);
        repository.saveExecution(snapshot(state));
        repository.addEvent(state.getExecutionId(), new WorkflowEvent(state.getExecutionId(), null, "WORKFLOW_START", "Workflow accepted for execution", Instant.now()));

        workflowExecutorService.submit(() -> workflowEngine.execute(graph, state));

        return new StartWorkflowResponse(state.getExecutionId(), state.getGraphId(), state.getStatus(), state.getCurrentNodeId(), state.getStartedAt());
    }

    public StartWorkflowResponse resume(String executionId) {
        WorkflowState state = repository.getState(executionId);
        if (state == null) throw new NoSuchElementException("Unknown executionId: " + executionId);

        GraphDefinition graph = graphRegistryService.getRequiredGraph(state.getGraphId());

        if (state.getStatus() == WorkflowStatus.COMPLETED) {
            throw new IllegalArgumentException("Workflow already completed for executionId: " + executionId);
        }
        if (state.getCurrentNodeId() == null || state.getCurrentNodeId().isBlank()) {
            throw new IllegalArgumentException("Workflow has no resumable currentNodeId for executionId: " + executionId);
        }

        state.setStatus(WorkflowStatus.RUNNING);
        state.setUpdatedAt(Instant.now());
        state.setCompletedAt(null);

        repository.saveState(state);
        repository.saveExecution(snapshot(state));
        repository.addEvent(state.getExecutionId(), new WorkflowEvent(state.getExecutionId(), state.getCurrentNodeId(), "WORKFLOW_RESUME", "Workflow resumed from current node", Instant.now()));

        log.info("[WORKFLOW_RESUME_REQUEST] executionId={} resumeNode={} graphId={}", state.getExecutionId(), state.getCurrentNodeId(), state.getGraphId());
        workflowExecutorService.submit(() -> workflowEngine.execute(graph, state));

        return new StartWorkflowResponse(state.getExecutionId(), state.getGraphId(), state.getStatus(), state.getCurrentNodeId(), state.getStartedAt());
    }

    public WorkflowExecution getExecution(String executionId) {
        WorkflowExecution execution = repository.getExecution(executionId);
        if (execution == null) throw new NoSuchElementException("Unknown executionId: " + executionId);
        return execution;
    }

    public Map<String, Object> getState(String executionId) {
        WorkflowState state = repository.getState(executionId);
        if (state == null) throw new NoSuchElementException("Unknown executionId: " + executionId);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("executionId", state.getExecutionId());
        out.put("graphId", state.getGraphId());
        out.put("graphVersion", state.getGraphVersion());
        out.put("status", state.getStatus());
        out.put("currentNodeId", state.getCurrentNodeId());
        out.put("input", state.getInput());
        out.put("intentResult", state.getIntentResult());
        out.put("allowed", state.getAllowed());
        out.put("pendingLeaves", state.getPendingLeaves());
        out.put("reviewResult", state.getReviewResult());
        out.put("finalResponse", state.getFinalResponse());
        out.put("outcome", state.getOutcome());
        out.put("nodeStatuses", state.getNodeStatuses());
        out.put("errors", state.getErrors());
        out.put("finalOutput", state.getFinalOutput());
        out.put("startedAt", state.getStartedAt());
        out.put("updatedAt", state.getUpdatedAt());
        out.put("completedAt", state.getCompletedAt());
        return out;
    }

    public List<WorkflowEvent> getEvents(String executionId) {
        return repository.getEvents(executionId);
    }

    private WorkflowExecution snapshot(WorkflowState state) {
        WorkflowExecution execution = new WorkflowExecution();
        execution.setExecutionId(state.getExecutionId());
        execution.setGraphId(state.getGraphId());
        execution.setGraphVersion(state.getGraphVersion());
        execution.setStatus(state.getStatus());
        execution.setCurrentNodeId(state.getCurrentNodeId());
        execution.setStartedAt(state.getStartedAt());
        execution.setUpdatedAt(state.getUpdatedAt());
        execution.setCompletedAt(state.getCompletedAt());
        execution.setNodeStatuses(new LinkedHashMap<>(state.getNodeStatuses()));
        execution.setFinalOutput(new LinkedHashMap<>(state.getFinalOutput()));
        if (!state.getErrors().isEmpty()) {
            execution.setFailureReason(String.valueOf(state.getErrors().get(state.getErrors().size() - 1).get("message")));
        }
        return execution;
    }
}
