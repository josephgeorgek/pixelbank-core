package com.ocbc.staff.orchestrator.model;

public enum WorkflowStatus {
    RUNNING, COMPLETED, FAILED
}
