# Development Steps

1. Define common contracts: request, intent, graph state, response, entitlement.
2. Stand up the taxonomy and knowledge service (`ms-workforce-knowledgebase`).
3. Implement deterministic control gate (`ms-control-gate`).
4. Publish approved MCP tools (`mcp-server-workplace`).
5. Implement `intent-agent` to retrieve taxonomy context and confirm intent.
6. Implement `fulfilment-agent` for schema-based request formation and post-processing.
7. Implement `agentic-orchestrator` to load graph config and execute nodes.
8. Wire `ms-agentic-buddy` to capture user context and call orchestrator.
9. Add audit, idempotency, tracing, retries, and OpenShift deployment descriptors.
