package com.ocbc.staff.orchestrator.api.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.LinkedHashMap;
import java.util.Map;

public class StartWorkflowRequest {
    @NotBlank
    private String graphId;
    private Map<String, Object> input = new LinkedHashMap<>();
    private Map<String, Object> intentResult = new LinkedHashMap<>();

    public String getGraphId() {
        return graphId;
    }

    public void setGraphId(String graphId) {
        this.graphId = graphId;
    }

    public Map<String, Object> getInput() {
        return input;
    }

    public void setInput(Map<String, Object> input) {
        this.input = input;
    }

    public Map<String, Object> getIntentResult() {
        return intentResult;
    }

    public void setIntentResult(Map<String, Object> intentResult) {
        this.intentResult = intentResult;
    }
}
