package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.GraphNodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface GraphNodeRepository extends JpaRepository<GraphNodeEntity, Long> { void deleteByWikiId(String wikiId); long countByWikiId(String wikiId); }
