package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.RankedIntent;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class IntentShortlistService {

    public List<RankedIntent> shortlist(List<RankedIntent> ranked) {
        return ranked.stream()
                .filter(item -> item.score() >= 0.15)
                .filter(item -> item.matchedSignals().size() >= 1 || "UNKNOWN_OR_UNSUPPORTED_REQUEST".equals(item.taxonomy().intent()))
                .filter(item -> item.rejectedSignals().stream().noneMatch(signal ->
                        signal.startsWith("persona-mismatch")
                                || signal.startsWith("missing-anchor")))
                .collect(Collectors.toList());
    }
}
