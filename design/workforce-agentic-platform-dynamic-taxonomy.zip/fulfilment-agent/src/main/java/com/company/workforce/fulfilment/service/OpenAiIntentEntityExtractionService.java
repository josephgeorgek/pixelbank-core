package com.company.workforce.fulfilment.service;

import com.company.workforce.fulfilment.service.model.IntentTaxonomyContext;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.time.ZonedDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class OpenAiIntentEntityExtractionService {

    private static final Logger log = LoggerFactory.getLogger(OpenAiIntentEntityExtractionService.class);

    private final ChatClient chatClient;
    private final ObjectMapper objectMapper;
    private final InMemoryIntentTaxonomyService taxonomyService;
    private final PromptBuilderService promptBuilderService;

    public OpenAiIntentEntityExtractionService(ChatClient.Builder chatClientBuilder,
                                               ObjectMapper objectMapper,
                                               InMemoryIntentTaxonomyService taxonomyService,
                                               PromptBuilderService promptBuilderService) {
        this.chatClient = chatClientBuilder.build();
        this.objectMapper = objectMapper;
        this.taxonomyService = taxonomyService;
        this.promptBuilderService = promptBuilderService;
    }

    public Map<String, Object> extract(String utterance, String domain, List<String> candidateIntents) {
        long t0 = System.nanoTime();
        IntentTaxonomyContext context = taxonomyService.getContext(utterance, domain, candidateIntents);
        long t1 = System.nanoTime();

        ZonedDateTime singaporeNow = ZonedDateTime.now(promptBuilderService.getSingaporeZoneId());
        String systemPrompt = promptBuilderService.buildSystemPrompt(context, singaporeNow);
        String userPrompt = utterance;
        long t2 = System.nanoTime();

        log.info("LLM_SYSTEM_PROMPT=\n{}", systemPrompt);
        log.info("LLM_USER_PROMPT=\n{}", userPrompt);

        ChatResponse response = chatClient.prompt()
                .system(systemPrompt)
                .user(userPrompt)
                .call()
                .chatResponse();
        long t3 = System.nanoTime();

        String responseText = extractResponseText(response);
        Map<String, Object> usage = extractUsageMetadata(response);
        String model = extractModel(response);

        log.info("LLM_RESPONSE_TEXT=\n{}", responseText);
        log.info("LLM_RESPONSE_MODEL={}", model);
        log.info("LLM_USAGE={}", usage);

        Map<String, Object> parsed;
        try {
            parsed = objectMapper.readValue(responseText, new TypeReference<>() {});
        } catch (Exception e) {
            throw new IllegalStateException("LLM returned non-JSON or invalid JSON. Raw response: " + responseText, e);
        }
        long t4 = System.nanoTime();

        Map<String, Object> timings = new LinkedHashMap<>();
        timings.put("taxonomy_lookup", toMs(t1 - t0));
        timings.put("prompt_build", toMs(t2 - t1));
        timings.put("llm_round_trip", toMs(t3 - t2));
        timings.put("response_parse", toMs(t4 - t3));
        timings.put("total_fulfilment_agent", toMs(t4 - t0));

        Map<String, Object> metadata = new LinkedHashMap<>();
        metadata.put("domain", domain);
        metadata.put("candidateIntents", candidateIntents);
        metadata.put("model", model);
        metadata.put("timings_ms", timings);
        metadata.put("token_usage", usage);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("extraction", parsed);
        result.put("metadata", metadata);
        return result;
    }

    private long toMs(long nanos) {
        return nanos / 1_000_000;
    }

    private String extractResponseText(ChatResponse response) {
        try {
            Object result = invoke(response, "getResult");
            Object output = invoke(result, "getOutput");
            Object text = invoke(output, "getText");
            return String.valueOf(text);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to extract LLM response text from ChatResponse", ex);
        }
    }

    private Map<String, Object> extractUsageMetadata(ChatResponse response) {
        Map<String, Object> result = new LinkedHashMap<>();
        try {
            Object metadata = invoke(response, "getMetadata");
            Object usage = invoke(metadata, "getUsage");
            result.put("raw", String.valueOf(usage));

            Object promptTokens = safeInvoke(usage, "getPromptTokens");
            Object completionTokens = safeInvoke(usage, "getCompletionTokens");
            Object totalTokens = safeInvoke(usage, "getTotalTokens");

            if (promptTokens != null) result.put("promptTokens", promptTokens);
            if (completionTokens != null) result.put("completionTokens", completionTokens);
            if (totalTokens != null) result.put("totalTokens", totalTokens);
        } catch (Exception ex) {
            result.put("raw", "UNAVAILABLE");
        }
        return result;
    }

    private String extractModel(ChatResponse response) {
        try {
            Object metadata = invoke(response, "getMetadata");
            Object model = safeInvoke(metadata, "getModel");
            return model != null ? String.valueOf(model) : "UNKNOWN";
        } catch (Exception ex) {
            return "UNKNOWN";
        }
    }

    private Object invoke(Object target, String methodName) throws Exception {
        Method method = target.getClass().getMethod(methodName);
        return method.invoke(target);
    }

    private Object safeInvoke(Object target, String methodName) {
        try {
            Method method = target.getClass().getMethod(methodName);
            return method.invoke(target);
        } catch (Exception ex) {
            return null;
        }
    }
}
