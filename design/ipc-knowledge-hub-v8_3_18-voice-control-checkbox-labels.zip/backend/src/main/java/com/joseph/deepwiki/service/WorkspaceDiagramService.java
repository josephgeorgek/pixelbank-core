package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class WorkspaceDiagramService {
    public WorkspaceDiagrams generate(List<WikiResponse> wikis) {
        Map<String, String> individual = new LinkedHashMap<>();
        for (WikiResponse wiki : wikis) individual.put(repoName(wiki.repoUrl()), wiki.architectureMermaid());
        return new WorkspaceDiagrams(interaction(wikis), sequence(wikis), gitTopology(wikis), individual);
    }

    private String interaction(List<WikiResponse> wikis) {
        List<CrossRef> refs = crossRefs(wikis);
        if (wikis.size() < 2) {
            return "flowchart TB\n  INSUFFICIENT_EVIDENCE[Workspace interaction diagram requires two or more repositories]\n";
        }
        if (refs.isEmpty()) {
            return "flowchart TB\n  INSUFFICIENT_EVIDENCE[Workspace interaction diagram unavailable: no cross-repo source references detected]\n";
        }
        StringBuilder m = new StringBuilder("flowchart LR\n");
        for (int i = 0; i < wikis.size(); i++) {
            m.append("  R").append(i).append("[").append(escape(repoName(wikis.get(i).repoUrl()))).append("]\n");
        }
        for (CrossRef ref : refs) {
            m.append("  R").append(ref.source()).append(" -->|source reference| R").append(ref.target()).append("\n");
        }
        return m.toString();
    }

    private String sequence(List<WikiResponse> wikis) {
        Optional<Chain> chain = wikis.stream().map(this::chainFor).flatMap(Optional::stream).findFirst();
        if (chain.isEmpty()) {
            return "sequenceDiagram\n  participant Evidence\n  Note over Evidence: Sequence diagram unavailable: no controller-service-repository chain detected.\n";
        }
        Chain c = chain.get();
        StringBuilder m = new StringBuilder("sequenceDiagram\n");
        m.append("  actor User\n");
        m.append("  participant C as ").append(escape(c.controller().label())).append("\n");
        m.append("  participant S as ").append(escape(c.service().label())).append("\n");
        m.append("  participant R as ").append(escape(c.repository().label())).append("\n");
        m.append("  User->>C: HTTP/API request evidenced by controller node\n");
        m.append("  C->>S: dependency edge / service usage\n");
        m.append("  S->>R: dependency edge / repository usage\n");
        m.append("  R-->>S: data result\n");
        m.append("  S-->>C: service response\n");
        m.append("  C-->>User: API response\n");
        return m.toString();
    }

    private String gitTopology(List<WikiResponse> wikis) {
        StringBuilder m = new StringBuilder("flowchart TB\n");
        m.append("  Workspace[GitDiagram - repository topology, not runtime flow]\n");
        for (int i = 0; i < wikis.size(); i++) {
            WikiResponse wiki = wikis.get(i);
            String id = "R" + i;
            m.append("  Workspace --> ").append(id).append("[").append(escape(repoName(wiki.repoUrl()))).append("]\n");
            wiki.languageStats().entrySet().stream().limit(4).forEach(e -> m.append("  ").append(id).append(" --> ").append(id).append(safe(e.getKey())).append("[").append(escape(e.getKey())).append(": ").append(e.getValue()).append("]\n"));
            m.append("  ").append(id).append(" --> ").append(id).append("Files[").append(wiki.files().size()).append(" files]\n");
            m.append("  ").append(id).append(" --> ").append(id).append("Chunks[").append(wiki.chunks().size()).append(" chunks]\n");
            m.append("  ").append(id).append(" --> ").append(id).append("Symbols[").append(wiki.symbols().size()).append(" symbols]\n");
        }
        return m.toString();
    }

    private Optional<Chain> chainFor(WikiResponse wiki) {
        List<GraphNode> controllers = nodes(wiki, "controller");
        List<GraphNode> services = nodes(wiki, "service");
        List<GraphNode> repositories = nodes(wiki, "repository");
        for (GraphNode c : controllers) for (GraphNode s : services) for (GraphNode r : repositories) {
            if (connected(wiki, c.id(), s.id()) && connected(wiki, s.id(), r.id())) return Optional.of(new Chain(c, s, r));
        }
        return Optional.empty();
    }

    private List<GraphNode> nodes(WikiResponse wiki, String type) { return wiki.architectureGraph().nodes().stream().filter(n -> type.equals(n.type())).toList(); }
    private boolean connected(WikiResponse wiki, String a, String b) { return wiki.architectureGraph().edges().stream().anyMatch(e -> (e.source().equals(a) && e.target().equals(b)) || (e.source().equals(b) && e.target().equals(a))); }

    private List<CrossRef> crossRefs(List<WikiResponse> wikis) {
        List<CrossRef> refs = new ArrayList<>();
        for (int i = 0; i < wikis.size(); i++) {
            String text = wikis.get(i).chunks().stream().limit(120).map(CodeChunk::content).collect(Collectors.joining("\n")).toLowerCase(Locale.ROOT);
            for (int j = 0; j < wikis.size(); j++) {
                if (i == j) continue;
                String other = repoName(wikis.get(j).repoUrl()).toLowerCase(Locale.ROOT);
                String repoOnly = other.contains("/") ? other.substring(other.indexOf('/') + 1) : other;
                if (text.contains(other) || text.contains(repoOnly)) refs.add(new CrossRef(i, j));
            }
        }
        return refs.stream().distinct().limit(24).toList();
    }

    private String repoName(String url) {
        try {
            String[] parts = java.net.URI.create(url).getPath().replaceAll("^/+", "").replaceAll("/+$", "").split("/");
            if (parts.length >= 2) return parts[0] + "/" + parts[1].replaceAll("\\.git$", "");
        } catch (Exception ignored) {}
        return url;
    }

    private String safe(String id) { return id.replaceAll("[^a-zA-Z0-9_]", "_"); }
    private String escape(String s) { return Optional.ofNullable(s).orElse("").replace("[", "(").replace("]", ")").replace("\"", "'"); }
    private record CrossRef(int source, int target) {}
    private record Chain(GraphNode controller, GraphNode service, GraphNode repository) {}
}
