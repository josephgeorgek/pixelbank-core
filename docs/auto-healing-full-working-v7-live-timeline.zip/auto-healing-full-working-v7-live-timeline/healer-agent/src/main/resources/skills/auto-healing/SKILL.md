# Auto-Healing Skill

## Purpose
Analyze runtime failures across any microservice and produce a safe, evidence-backed healing plan.

## Core Principle
Do not assume the root cause or fix upfront. Infer from evidence only.

## Required Flow
1. DETECT
2. COLLECT_EVIDENCE
3. AI_ANALYZE
4. CLASSIFY
5. ROOT_CAUSE
6. PLAN
7. VALIDATE_PLAN
8. CREATE_REVIEW_PATCH
9. TEST
10. PROMOTE

## Required JSON Output
Return JSON only:
{
  "service": "",
  "environment": "",
  "errorSignature": "",
  "classification": "",
  "rootCause": {
    "summary": "",
    "technicalCause": "",
    "businessImpact": "",
    "confidence": 0.0,
    "evidence": []
  },
  "proposedFix": {
    "fixType": "",
    "filesToChange": [],
    "patchContent": "",
    "requiresBusinessValueReview": false,
    "unknowns": []
  },
  "testPlan": [],
  "rollbackPlan": "",
  "riskLevel": "",
  "requiresHumanApproval": true,
  "shouldCreatePr": true,
  "shouldAutoApply": false
}

## Allowed Classifications
CONFIG_DEFAULT_GAP, REFERENCE_DATA_GAP, ENVIRONMENT_CONFIG_GAP, DOWNSTREAM_UNAVAILABLE,
TIMEOUT_OR_RETRY_POLICY_GAP, API_CONTRACT_MISMATCH, DATABASE_SCHEMA_MISMATCH,
AUTHENTICATION_FAILURE, AUTHORIZATION_FAILURE, DEPLOYMENT_STARTUP_FAILURE,
RESOURCE_EXHAUSTION, DATA_VALIDATION_GAP, CODE_DEFECT_REQUIRES_DEV,
UNKNOWN_REQUIRES_INVESTIGATION

## Allowed Fix Types
CONFIG_PATCH, REFERENCE_DATA_PATCH, ENV_VAR_PATCH, ROUTING_PATCH, TIMEOUT_RETRY_POLICY_PATCH,
API_CONTRACT_PATCH, SCHEMA_MAPPING_PATCH, VALIDATION_RULE_PATCH, STARTUP_CONFIG_PATCH,
RESOURCE_LIMIT_PATCH, TEST_ONLY_REPRODUCTION, ESCALATE_TO_DEVELOPER

## Guardrails
- Never patch production directly.
- Never delete or mutate business data without explicit human approval.
- Never invent business values.
- Prefer config/reference-data fixes over code changes when safe.
- Prefer PR-based review over direct mutation.
- Always include rollback.
- Always include test plan.
- Always mark uncertain values as REVIEW_REQUIRED.
- Always require human approval for production promotion.
