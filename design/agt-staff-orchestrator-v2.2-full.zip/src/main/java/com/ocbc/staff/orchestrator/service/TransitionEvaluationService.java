package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.graph.TransitionDefinition;
import com.ocbc.staff.orchestrator.model.WorkflowState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;

@Service
public class TransitionEvaluationService {
    private static final Logger log = LoggerFactory.getLogger(TransitionEvaluationService.class);
    private final MappingResolverService resolver;

    public TransitionEvaluationService(MappingResolverService resolver) {
        this.resolver = resolver;
    }

    public String resolveNextNode(GraphNodeDefinition node, WorkflowState state) {
        Map<String, Object> root = resolver.root(state);
        for (TransitionDefinition t : node.getTransitions()) {
            EvaluationResult result = evaluate(t, root);
            if ("ALWAYS".equalsIgnoreCase(t.getKind())) {
                log.info("[TRANSITION_EVAL] executionId={} nodeId={} kind=ALWAYS next={} matched=true reason=always", state.getExecutionId(), node.getId(), t.getNext());
            } else {
                log.info("[TRANSITION_EVAL] executionId={} nodeId={} path={} operator={} expected={} actual={} next={} matched={}",
                        state.getExecutionId(), node.getId(), t.getPath(), t.getOperator(), String.valueOf(t.getValue()), String.valueOf(result.actual()), t.getNext(), result.matched());
            }
            if (result.matched()) {
                log.info("[TRANSITION_SELECTED] executionId={} currentNode={} nextNode={} basedOnPath={} operator={} expected={} actual={}",
                        state.getExecutionId(), node.getId(), t.getNext(), t.getPath(), t.getOperator(), String.valueOf(t.getValue()), String.valueOf(result.actual()));
                return t.getNext();
            }
        }
        log.warn("[TRANSITION_SELECTED] executionId={} currentNode={} nextNode=null reason=no transition matched", state.getExecutionId(), node.getId());
        return null;
    }

    private EvaluationResult evaluate(TransitionDefinition t, Map<String, Object> root) {
        if ("ALWAYS".equalsIgnoreCase(t.getKind())) return new EvaluationResult(true, null);
        Object actual = resolver.getByPath(root, t.getPath());
        Object expected = t.getValue();
        boolean matched = switch (t.getOperator()) {
            case "EQ" -> Objects.equals(actual, expected);
            case "NE" -> !Objects.equals(actual, expected);
            case "IS_TRUE" -> Boolean.TRUE.equals(actual);
            case "IS_FALSE" -> Boolean.FALSE.equals(actual);
            case "GT" -> toDouble(actual) > toDouble(expected);
            case "GTE" -> toDouble(actual) >= toDouble(expected);
            case "LT" -> toDouble(actual) < toDouble(expected);
            case "LTE" -> toDouble(actual) <= toDouble(expected);
            case "SIZE_GT" -> sizeOf(actual) > toDouble(expected);
            case "SIZE_EQ" -> sizeOf(actual) == toDouble(expected);
            case "EXISTS" -> actual != null;
            case "NOT_EXISTS" -> actual == null;
            default -> false;
        };
        return new EvaluationResult(matched, actual);
    }

    private double toDouble(Object value) {
        if (value == null) return 0;
        if (value instanceof Number n) return n.doubleValue();
        return Double.parseDouble(String.valueOf(value));
    }

    private int sizeOf(Object value) {
        if (value == null) return 0;
        if (value instanceof Collection<?> c) return c.size();
        if (value instanceof Map<?, ?> m) return m.size();
        return 0;
    }

    private record EvaluationResult(boolean matched, Object actual) {}
}
