package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class WorkspaceService {
    private final WikiGenerationService wikiGenerationService;
    private final WorkspaceDiagramService workspaceDiagramService;
    private final GitHubAnalyticsService gitHubAnalyticsService;
    private final KeyContributorService keyContributorService;
    private final PersistenceService persistenceService;
    private final Map<String, WorkspaceResponse> store = new ConcurrentHashMap<>();

    public WorkspaceService(WikiGenerationService wikiGenerationService,
                            WorkspaceDiagramService workspaceDiagramService,
                            GitHubAnalyticsService gitHubAnalyticsService,
                            KeyContributorService keyContributorService,
                            PersistenceService persistenceService) {
        this.wikiGenerationService = wikiGenerationService;
        this.workspaceDiagramService = workspaceDiagramService;
        this.gitHubAnalyticsService = gitHubAnalyticsService;
        this.keyContributorService = keyContributorService;
        this.persistenceService = persistenceService;
    }

    public WorkspaceResponse generate(MultiRepoIndexRequest request) {
        List<String> repoUrls = parseRepoUrls(request);
        if (repoUrls.isEmpty()) throw new IllegalArgumentException("Provide at least one repository URL.");
        List<WikiResponse> wikis = new ArrayList<>();
        List<WorkspaceRepoSummary> repos = new ArrayList<>();
        List<PullRequestReviewer> reviewers = new ArrayList<>();
        List<CommitHighlight> commits = new ArrayList<>();

        int index = 0;
        for (String repoUrl : repoUrls) {
            WikiResponse wiki = wikiGenerationService.generate(new GenerateWikiRequest(repoUrl, request.branch(), request.accessToken()));
            wikis.add(wiki);
            repos.add(summaryFor(index++, wiki));
            reviewers.addAll(gitHubAnalyticsService.reviewers(repoUrl, request.accessToken()));
            commits.addAll(gitHubAnalyticsService.commits(repoUrl, request.accessToken()));
        }

        Map<String, Long> combinedLanguages = combinedLanguages(wikis);
        WorkspaceDiagrams diagrams = workspaceDiagramService.generate(wikis);
        String id = UUID.randomUUID().toString();
        List<KeyContributor> keyContributors = keyContributorService.topContributors(reviewers, commits);
        String summary = summary(repos, keyContributors);
        String overview = overview(repos, combinedLanguages, keyContributors);
        AiGeneratedSections aiGeneratedSections = wikiGenerationService.generateWorkspaceDocumentation(wikis);
        WorkspaceResponse response = new WorkspaceResponse(
                id,
                Instant.now(),
                repoUrls,
                Optional.ofNullable(request.branch()).filter(StringUtils::hasText).orElse("default"),
                summary,
                overview,
                aiGeneratedSections,
                combinedLanguages,
                wikis.stream().mapToInt(w -> w.files().size()).sum(),
                wikis.stream().mapToInt(w -> w.chunks().size()).sum(),
                wikis.stream().mapToInt(w -> w.symbols().size()).sum(),
                wikis.stream().mapToInt(w -> w.architectureGraph().nodes().size()).sum(),
                wikis.stream().mapToInt(w -> w.architectureGraph().edges().size()).sum(),
                repos,
                diagrams,
                keyContributors,
                wikis
        );
        store.put(id, response);
        persistenceService.saveWorkspace(response);
        persistenceService.saveKeyContributors(response.id(), keyContributors);
        return response;
    }

    public Optional<WorkspaceResponse> find(String id) {
        WorkspaceResponse cached = store.get(id);
        return cached != null ? Optional.of(cached) : persistenceService.findWorkspace(id);
    }
    public Collection<WorkspaceResponse> list() {
        LinkedHashMap<String, WorkspaceResponse> all = new LinkedHashMap<>();
        persistenceService.listWorkspaces().forEach(w -> all.put(w.id(), w));
        store.values().forEach(w -> all.put(w.id(), w));
        return all.values();
    }

    private List<String> parseRepoUrls(MultiRepoIndexRequest request) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        if (request.repoUrls() != null) request.repoUrls().stream().filter(StringUtils::hasText).map(this::normalize).forEach(urls::add);
        if (StringUtils.hasText(request.repoInput())) {
            Arrays.stream(request.repoInput().split("[,\\n\\r\\t ]+"))
                    .map(this::normalize)
                    .filter(StringUtils::hasText)
                    .filter(s -> s.startsWith("https://"))
                    .forEach(urls::add);
        }
        return urls.stream().limit(8).toList();
    }

    private String normalize(String url) {
        String value = Optional.ofNullable(url).orElse("").trim();
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private WorkspaceRepoSummary summaryFor(int index, WikiResponse wiki) {
        String name = repoName(wiki.repoUrl());
        String summary = firstSentences(wiki.overview());
        return new WorkspaceRepoSummary(
                "repo-" + index,
                wiki.repoUrl(),
                name,
                wiki.branch(),
                wiki.id(),
                summary,
                wiki.languageStats(),
                wiki.files().size(),
                wiki.chunks().size(),
                wiki.symbols().size(),
                wiki.architectureGraph().nodes().size(),
                wiki.architectureGraph().edges().size()
        );
    }

    private Map<String, Long> combinedLanguages(List<WikiResponse> wikis) {
        Map<String, Long> map = new TreeMap<>();
        for (WikiResponse wiki : wikis) wiki.languageStats().forEach((k, v) -> map.merge(k, v, Long::sum));
        return map;
    }

    private String summary(List<WorkspaceRepoSummary> repos, List<KeyContributor> keyContributors) {
        String names = keyContributors.isEmpty() ? "no contributor names returned" : keyContributors.stream().map(KeyContributor::name).collect(Collectors.joining(", "));
        return "Indexed " + repos.size() + " repos with " + repos.stream().mapToInt(WorkspaceRepoSummary::files).sum() + " files, "
                + repos.stream().mapToInt(WorkspaceRepoSummary::chunks).sum() + " chunks, "
                + repos.stream().mapToInt(WorkspaceRepoSummary::symbols).sum() + " symbols. Key contributors: " + names + ".";
    }

    private String overview(List<WorkspaceRepoSummary> repos, Map<String, Long> languages, List<KeyContributor> keyContributors) {
        String repoBullets = repos.stream()
                .map(r -> "- `" + r.name() + "`: " + r.files() + " files, " + r.chunks() + " chunks, " + r.graphNodes() + " graph nodes")
                .collect(Collectors.joining("\n"));
        String langBullets = languages.entrySet().stream()
                .map(e -> "- `" + e.getKey() + "`: " + e.getValue())
                .collect(Collectors.joining("\n"));
        String contributorBullets = keyContributors.isEmpty() ? "- No contributor names returned from GitHub API." : keyContributors.stream().map(c -> "- `" + c.name() + "`" + (StringUtils.hasText(c.repoName()) ? " — " + c.repoName() : "")).collect(Collectors.joining("\n"));
        return """
                ## Workspace overview

                This workspace is generated from repository source scans, chunk-level evidence, symbol extraction, and evidence-gated diagrams. Unsupported diagrams are marked as insufficient evidence instead of being invented.

                ### Repositories

                %s

                ### Combined technology signal

                %s

                ### Key contributors

                %s
                """.formatted(repoBullets, langBullets, contributorBullets);
    }

    private String firstSentences(String markdown) {
        String plain = Optional.ofNullable(markdown).orElse("").replaceAll("[#*_`>]", "").replaceAll("\\s+", " ").trim();
        if (plain.length() > 280) return plain.substring(0, 280) + "…";
        return plain;
    }

    private String repoName(String url) {
        try {
            String[] parts = java.net.URI.create(url).getPath().replaceAll("^/+", "").replaceAll("/+$", "").split("/");
            if (parts.length >= 2) return parts[0] + "/" + parts[1].replaceAll("\\.git$", "");
        } catch (Exception ignored) {}
        return url;
    }
}
