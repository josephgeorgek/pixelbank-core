package com.ocbc.staff.orchestrator.domain.graph;

import java.util.List;
import java.util.Map;

public record GraphDefinition(
        String graphId,
        String version,
        String description,
        String entryNode,
        List<String> finishNodes,
        Map<String, Object> metadata,
        List<GraphNodeDefinition> nodes
) {
}
