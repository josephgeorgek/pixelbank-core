package com.ocbc.staff.orchestrator.graph;

public class TransitionDefinition {
    private String kind;
    private String path;
    private String operator;
    private Object value;
    private String next;

    public String getKind() { return kind; }
    public void setKind(String kind) { this.kind = kind; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public String getOperator() { return operator; }
    public void setOperator(String operator) { this.operator = operator; }
    public Object getValue() { return value; }
    public void setValue(Object value) { this.value = value; }
    public String getNext() { return next; }
    public void setNext(String next) { this.next = next; }
}
