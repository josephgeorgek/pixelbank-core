package com.company.workforce.fulfilment.service;

import com.company.workforce.fulfilment.service.model.IntentDefinition;
import com.company.workforce.fulfilment.service.model.IntentTaxonomyContext;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class InMemoryIntentTaxonomyService implements IntentTaxonomyService {

    private final Map<String, List<IntentDefinition>> taxonomyByDomain = new HashMap<>();

    public InMemoryIntentTaxonomyService() {
        taxonomyByDomain.put("HR", List.of(
                new IntentDefinition(
                        "LEAVE_APPLICATION",
                        "Employee wants to apply, submit, or request leave.",
                        List.of("apply leave", "submit leave", "request leave", "take leave", "annual leave"),
                        Map.of(
                                "duration_days", "Number of leave days",
                                "start_date_expression", "Natural language date phrase such as next monday",
                                "resolved_start_date", "Resolved leave start date in YYYY-MM-DD",
                                "resolved_end_date", "Resolved leave end date in YYYY-MM-DD",
                                "leave_type", "Type of leave if present"
                        ),
                        List.of(
                                "When the utterance says 'for N days from DATE', interpret DATE as the start date and N as the duration.",
                                "Do not merge the duration phrase into the start date expression.",
                                "Assume duration means calendar days unless the user explicitly says working days or business days."
                        ),
                        List.of(
                                "I need to apply for 2 days leave from next Monday",
                                "Submit annual leave for tomorrow"
                        )
                ),
                new IntentDefinition(
                        "LEAVE_BALANCE_QUERY",
                        "Employee asks how much leave remains or what leave balance is available.",
                        List.of("leave balance", "how many leave days left", "remaining leave"),
                        Map.of("leave_type", "Leave type if stated"),
                        List.of("This intent is for asking balance, not for applying leave."),
                        List.of("How many annual leave days do I have left?")
                ),
                new IntentDefinition(
                        "MEETING_BOOKING",
                        "User wants to book or schedule a meeting.",
                        List.of("book meeting", "schedule meeting", "set up meeting"),
                        Map.of(
                                "dates", "Meeting date phrases",
                                "people", "Attendees or participants",
                                "locations", "Meeting room or location"
                        ),
                        List.of("Extract attendees if they are explicitly mentioned."),
                        List.of("Book a meeting with HR tomorrow afternoon")
                ),
                new IntentDefinition(
                        "POLICY_SEARCH",
                        "User wants to search, fetch, or view a policy or document.",
                        List.of("show policy", "find policy", "search policy", "fetch document"),
                        Map.of(
                                "documents", "Document or policy terms",
                                "dates", "Relevant date phrases if present"
                        ),
                        List.of("Use this intent for search or lookup style requests."),
                        List.of("Show me the parental leave policy")
                )
        ));
    }

    @Override
    public IntentTaxonomyContext getContext(String utterance, String domain, List<String> candidateIntents) {
        List<IntentDefinition> all = taxonomyByDomain.getOrDefault(domain, List.of());
        List<IntentDefinition> filtered = all;

        if (candidateIntents != null && !candidateIntents.isEmpty()) {
            Set<String> candidateSet = new HashSet<>(candidateIntents);
            filtered = all.stream()
                    .filter(intent -> candidateSet.contains(intent.intent()))
                    .collect(Collectors.toList());
        }

        if (filtered.isEmpty()) {
            filtered = all;
        }

        List<String> globalRules = List.of(
                "Return valid JSON only.",
                "Resolve relative dates using the supplied Singapore date-time.",
                "If confidence is low, still return the best-fit intent and explain uncertainty in notes.",
                "Do not ask follow-up questions.",
                "Do not return markdown or code fences."
        );

        return new IntentTaxonomyContext(domain, globalRules, filtered);
    }
}
