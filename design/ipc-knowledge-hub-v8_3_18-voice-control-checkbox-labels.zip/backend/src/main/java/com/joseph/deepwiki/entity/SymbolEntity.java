package com.joseph.deepwiki.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "symbols", indexes = @Index(name="idx_symbols_wiki", columnList="wikiId"))
public class SymbolEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String wikiId;
    @Column(length = 2000) public String path;
    public String symbol;
    public String kind;
    public int line;
    public SymbolEntity() {}
}
