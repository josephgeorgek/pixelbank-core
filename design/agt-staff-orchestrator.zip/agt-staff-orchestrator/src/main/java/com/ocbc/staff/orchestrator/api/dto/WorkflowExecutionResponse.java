package com.ocbc.staff.orchestrator.api.dto;

import java.util.Map;

public record WorkflowExecutionResponse(
        String executionId,
        String graphId,
        String status,
        String currentNodeId,
        Map<String, Object> finalOutput
) {
}
