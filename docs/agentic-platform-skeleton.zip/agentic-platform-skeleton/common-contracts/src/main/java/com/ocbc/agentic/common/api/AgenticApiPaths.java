package com.ocbc.agentic.common.api;

public final class AgenticApiPaths {
    public static final String BUDDY = "/api/buddy";
    public static final String ORCHESTRATE = "/api/orchestrator/execute";
    public static final String INTENT_RESOLVE = "/api/intents/resolve";
    public static final String ENTITLEMENT_CHECK = "/api/control/entitlements/check";
    public static final String KNOWLEDGE_SEARCH = "/api/knowledge/search";
    public static final String DOMAIN_PROXY = "/api/gateway/domain";

    private AgenticApiPaths() {}
}
