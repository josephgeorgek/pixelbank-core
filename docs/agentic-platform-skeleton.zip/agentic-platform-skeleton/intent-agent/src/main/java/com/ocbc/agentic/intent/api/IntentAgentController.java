package com.ocbc.agentic.intent.api;

import com.ocbc.agentic.common.model.IntentResolution;
import com.ocbc.agentic.common.model.UserRequest;
import com.ocbc.agentic.intent.service.IntentResolutionService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/intents")
public class IntentAgentController {
    private final IntentResolutionService service;

    public IntentAgentController(IntentResolutionService service) {
        this.service = service;
    }

    @PostMapping("/resolve")
    public IntentResolution resolve(@RequestBody UserRequest request) {
        return service.resolve(request);
    }
}
