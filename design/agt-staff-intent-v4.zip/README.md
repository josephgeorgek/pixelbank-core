# agt-staff-intent v4

Azure OpenAI enabled version.

## Env
AZURE_OPENAI_API_KEY
AZURE_OPENAI_ENDPOINT
AZURE_OPENAI_DEPLOYMENT
