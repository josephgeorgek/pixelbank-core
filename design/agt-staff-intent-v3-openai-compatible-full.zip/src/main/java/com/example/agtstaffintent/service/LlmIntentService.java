package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.LlmSelectionResult;
import com.example.agtstaffintent.domain.RankedIntent;
import com.example.agtstaffintent.domain.ServiceCandidate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class LlmIntentService {

    private static final Pattern SELECTED_INTENT_PATTERN =
            Pattern.compile("\"selectedIntent\"\s*:\s*\"([^\"]+)\"");
    private static final Pattern CONFIDENCE_PATTERN =
            Pattern.compile("\"confidence\"\s*:\s*([0-9.]+)");
    private static final Pattern RATIONALE_PATTERN =
            Pattern.compile("\"rationale\"\s*:\s*\"([^\"]*)\"");

    private final ChatClient chatClient;

    public LlmIntentService(ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    public LlmSelectionResult resolveIntent(String prompt, String userRole, List<RankedIntent> shortlisted) {
        if (shortlisted.isEmpty()) {
            return fallback("UNKNOWN_OR_UNSUPPORTED_REQUEST",
                    "No credible taxonomy candidate matched after deterministic filtering.");
        }

        String systemPrompt = buildSystemPrompt(shortlisted);
        long start = System.nanoTime();
        try {
            String content = chatClient.prompt()
                    .system(systemPrompt)
                    .user("User role: " + userRole + "\nUser prompt: " + prompt)
                    .call()
                    .content();

            long elapsedMs = (System.nanoTime() - start) / 1_000_000;
            log.info("LLM_CALL_TIMING provider=openai-compatible-gateway elapsedMs={}", elapsedMs);

            return parseOrFallback(content, shortlisted);
        } catch (Exception ex) {
            long elapsedMs = (System.nanoTime() - start) / 1_000_000;
            log.error("LLM_CALL_FAILED provider=openai-compatible-gateway elapsedMs={} error={}",
                    elapsedMs, ex.getMessage(), ex);
            RankedIntent best = shortlisted.getFirst();
            return new LlmSelectionResult(
                    best.taxonomy().intent(),
                    Math.max(0.1, Math.min(0.95, best.score())),
                    "LLM call failed, using deterministic best candidate fallback.",
                    defaultEntities(best.taxonomy().intent()),
                    best.taxonomy().serviceCandidates()
            );
        }
    }

    private String buildSystemPrompt(List<RankedIntent> shortlisted) {
        StringBuilder sb = new StringBuilder();
        sb.append("You are an enterprise intent classifier. ")
          .append("Choose only one intent from the shortlisted taxonomies. ")
          .append("If none is credible, return selectedIntent as UNKNOWN_OR_UNSUPPORTED_REQUEST. ")
          .append("Return JSON only with fields selectedIntent, confidence, rationale.\n\n")
          .append("Shortlisted intents:\n");
        for (RankedIntent item : shortlisted) {
            sb.append("- intent: ").append(item.taxonomy().intent()).append("\n")
              .append("  description: ").append(item.taxonomy().description()).append("\n")
              .append("  persona: ").append(item.taxonomy().persona()).append("\n")
              .append("  examples: ").append(item.taxonomy().examples()).append("\n")
              .append("  rules: ").append(item.taxonomy().rules()).append("\n");
        }
        return sb.toString();
    }

    private LlmSelectionResult parseOrFallback(String content, List<RankedIntent> shortlisted) {
        String intent = extract(content, SELECTED_INTENT_PATTERN);
        String confidenceStr = extract(content, CONFIDENCE_PATTERN);
        String rationale = extract(content, RATIONALE_PATTERN);

        if (intent == null || intent.isBlank()) {
            RankedIntent best = shortlisted.getFirst();
            return new LlmSelectionResult(
                    best.taxonomy().intent(),
                    Math.max(0.1, Math.min(0.95, best.score())),
                    "LLM response could not be parsed, using deterministic best candidate.",
                    defaultEntities(best.taxonomy().intent()),
                    best.taxonomy().serviceCandidates()
            );
        }

        Optional<RankedIntent> matched = shortlisted.stream()
                .filter(item -> item.taxonomy().intent().equalsIgnoreCase(intent))
                .findFirst();

        if ("UNKNOWN_OR_UNSUPPORTED_REQUEST".equals(intent) || matched.isEmpty()) {
            return fallback("UNKNOWN_OR_UNSUPPORTED_REQUEST",
                    rationale != null ? rationale : "LLM rejected all shortlisted candidates.");
        }

        RankedIntent winner = matched.get();
        double confidence = confidenceStr != null ? Double.parseDouble(confidenceStr)
                : Math.max(0.1, Math.min(0.95, winner.score()));
        return new LlmSelectionResult(
                winner.taxonomy().intent(),
                confidence,
                rationale != null ? rationale : "Selected based on shortlisted taxonomy fit.",
                defaultEntities(winner.taxonomy().intent()),
                winner.taxonomy().serviceCandidates()
        );
    }

    private LlmSelectionResult fallback(String intent, String rationale) {
        return new LlmSelectionResult(
                intent,
                0.31,
                rationale,
                new LinkedHashMap<>(Map.of(
                        "scope", "SELF",
                        "issueType", "UNKNOWN",
                        "status", "UNKNOWN"
                )),
                List.of(new ServiceCandidate(
                        "ms-agentic-buddy",
                        "GENERIC",
                        "ClarificationOrRouting",
                        "ASK"
                ))
        );
    }

    private Map<String, Object> defaultEntities(String intent) {
        Map<String, Object> entities = new LinkedHashMap<>();
        switch (intent) {
            case "STAFF_SELF_CASE_STATUS_TRACKING" -> {
                entities.put("scope", "SELF");
                entities.put("issueType", "UNKNOWN");
                entities.put("caseId", null);
                entities.put("status", "UNKNOWN");
            }
            case "STAFF_SELF_MEDICAL_LEAVE_STATUS_TRACKING" -> {
                entities.put("scope", "SELF");
                entities.put("leaveApplicationId", null);
                entities.put("status", null);
            }
            case "STAFF_LEAVE_APPLICATION_MEDICAL_CERT_LIST_AND_REVIEW" -> {
                entities.put("scope", "TEAM");
                entities.put("team", null);
                entities.put("certificateStatus", "PENDING_REVIEW");
            }
            case "STAFF_LEAVE_APPLICATION_WITH_MEDICAL_CERT_APPROVAL" -> {
                entities.put("leaveApplicationId", null);
                entities.put("decision", null);
            }
            default -> entities.put("scope", "UNKNOWN");
        }
        return entities;
    }

    private String extract(String content, Pattern pattern) {
        if (content == null) {
            return null;
        }
        Matcher matcher = pattern.matcher(content);
        return matcher.find() ? matcher.group(1) : null;
    }
}
