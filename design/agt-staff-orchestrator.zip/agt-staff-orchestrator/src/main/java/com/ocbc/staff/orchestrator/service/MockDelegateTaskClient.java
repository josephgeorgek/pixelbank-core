package com.ocbc.staff.orchestrator.service;

import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class MockDelegateTaskClient implements DelegateTaskClient {

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> invoke(String delegateTo, String taskType, Map<String, Object> payload) {
        return switch (taskType) {
            case "ACCESS_GUARD" -> guard(payload);
            case "DOMAIN_EXECUTION" -> listPendingLeaves(payload);
            case "LLM_STRUCTURED_TASK" -> reviewMedicalCertificates(payload);
            case "GENERATE_RESPONSE" -> generateResponse(payload);
            default -> throw new IllegalArgumentException("Unsupported taskType: " + taskType);
        };
    }

    private Map<String, Object> guard(Map<String, Object> payload) {
        Map<String, Object> userContext = safeMap(payload.get("userContext"));
        String role = String.valueOf(userContext.getOrDefault("role", "Staff"));
        boolean allowed = "Manager".equalsIgnoreCase(role) || "SeniorManager".equalsIgnoreCase(role);
        return Map.of(
                "allowed", allowed,
                "checkedRole", role
        );
    }

    private Map<String, Object> listPendingLeaves(Map<String, Object> payload) {
        Map<String, Object> userContext = safeMap(payload.get("userContext"));
        String userId = String.valueOf(userContext.getOrDefault("userId", "UNKNOWN"));

        if ("M00000".equalsIgnoreCase(userId)) {
            return Map.of("items", List.of(), "itemsCount", 0);
        }

        List<Map<String, Object>> items = new ArrayList<>();
        items.add(Map.of(
                "applicationId", "ML-1001",
                "employeeName", "Alice Tan",
                "clinicName", "Raffles Clinic",
                "leaveStartDate", "2026-04-05",
                "leaveEndDate", "2026-04-06",
                "medicalCertificateText", "Medical certificate issued to Alice Tan by Raffles Clinic for 2 days from 2026-04-05 to 2026-04-06"
        ));
        items.add(Map.of(
                "applicationId", "ML-1002",
                "employeeName", "Ben Wong",
                "clinicName", "City Care Medical",
                "leaveStartDate", "2026-04-06",
                "leaveEndDate", "2026-04-06",
                "medicalCertificateText", "MC issued to Ben Wong by City Care Medical for 1 day on 2026-04-06"
        ));

        return Map.of("items", items, "itemsCount", items.size());
    }

    private Map<String, Object> reviewMedicalCertificates(Map<String, Object> payload) {
        List<Map<String, Object>> leaves = safeList(payload.get("leaveApplications"));
        List<Map<String, Object>> reviews = new ArrayList<>();

        for (Map<String, Object> leave : leaves) {
            String employeeName = String.valueOf(leave.get("employeeName"));
            String clinicName = String.valueOf(leave.get("clinicName"));
            String start = String.valueOf(leave.get("leaveStartDate"));
            String end = String.valueOf(leave.get("leaveEndDate"));
            String text = String.valueOf(leave.getOrDefault("medicalCertificateText", ""));

            boolean employeeNameMatched = text.contains(employeeName);
            boolean clinicNameMatched = text.contains(clinicName);
            boolean startMatched = text.contains(start);
            boolean endMatched = text.contains(end);
            boolean overallMatch = employeeNameMatched && clinicNameMatched && startMatched && endMatched;

            reviews.add(Map.of(
                    "applicationId", leave.get("applicationId"),
                    "employeeName", employeeName,
                    "clinicName", clinicName,
                    "overallMatch", overallMatch,
                    "checks", Map.of(
                            "employeeNameMatched", employeeNameMatched,
                            "clinicNameMatched", clinicNameMatched,
                            "leaveStartDateMatched", startMatched,
                            "leaveEndDateMatched", endMatched
                    )
            ));
        }

        long matched = reviews.stream().filter(r -> Boolean.TRUE.equals(r.get("overallMatch"))).count();
        long mismatched = reviews.size() - matched;

        return Map.of(
                "summary", "Reviewed %d medical leave applications. %d matched fully and %d need manual attention."
                        .formatted(reviews.size(), matched, mismatched),
                "stats", Map.of(
                        "total", reviews.size(),
                        "matched", matched,
                        "mismatched", mismatched
                ),
                "items", reviews
        );
    }

    private Map<String, Object> generateResponse(Map<String, Object> payload) {
        Map<String, Object> domainResult = safeMap(payload.get("domainResult"));
        Map<String, Object> stats = safeMap(domainResult.get("stats"));
        return Map.of(
                "message",
                "I reviewed the pending medical leave applications. %s Proceed with matched items and inspect mismatches."
                        .formatted(domainResult.getOrDefault("summary", "Review completed.")),
                "decisionPrompt",
                "Do you want to proceed with matched applications only?",
                "stats", stats,
                "items", domainResult.getOrDefault("items", List.of())
        );
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> safeMap(Object value) {
        if (value instanceof Map<?, ?> map) {
            return (Map<String, Object>) map;
        }
        return new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> safeList(Object value) {
        if (value instanceof List<?> list) {
            return (List<Map<String, Object>>) list;
        }
        return List.of();
    }
}
