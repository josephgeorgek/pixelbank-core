package com.ocbc.staff.orchestrator.api.dto;

import jakarta.validation.constraints.NotBlank;

public class ResumeWorkflowRequest {
    @NotBlank
    private String executionId;

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }
}
