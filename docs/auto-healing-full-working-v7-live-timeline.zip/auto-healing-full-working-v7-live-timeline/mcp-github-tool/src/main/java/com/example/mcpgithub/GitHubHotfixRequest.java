package com.example.mcpgithub;

public record GitHubHotfixRequest(
  String incidentId,
  String branchName,
  String filePath,
  String fileContent,
  String commitMessage,
  String prTitle,
  String prBody
) {}
