# agt-staff-intent v3 gateway edition

This package preserves the v3 intent discovery logic and timings, and only switches the LLM connectivity
to an OpenAI-compatible gateway:

`https://genaiplatform-appgw.dev.c2.ocbc.com/foundryeastus2/openai`

## What stayed the same
- POST `/v1/intent/discover`
- taxonomy loading and caching
- prompt normalization and alias expansion
- similarity ranking and shortlist filtering
- UNKNOWN fallback
- request id filter
- HTTP timing filter
- step timing collector
- optional response debug timings using `X-Debug: true`

## What changed
- Spring AI model starter is OpenAI-compatible
- `spring.ai.openai.base-url` points to the bank gateway
- `spring.ai.openai.api-key` uses `GENAI_API_KEY`
- model is addressed by model name, default `gpt-4.1`

## Environment
```bash
export GENAI_API_KEY=xxxx
export GENAI_BASE_URL=https://genaiplatform-appgw.dev.c2.ocbc.com/foundryeastus2/openai
export GENAI_MODEL=gpt-4.1
```

## Run
```bash
mvn spring-boot:run
```

## Test
```bash
curl -X POST http://localhost:8080/v1/intent/discover \
  -H "Content-Type: application/json" \
  -H "X-Request-Id: demo-001" \
  -H "X-Debug: true" \
  -d '{
    "prompt": "Find out status for my HIP issue raised",
    "userRole": "Staff",
    "userId": "M12345"
  }'
```
