package com.joseph.deepwiki.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "wikis")
public class WikiEntity {
    @Id public String id;
    public String workspaceId;
    @Column(length = 2000) public String repoUrl;
    public String branch;
    @Lob @Column(columnDefinition = "CLOB") public String overview;
    @Lob @Column(columnDefinition = "CLOB") public String architectureMermaid;
    public Instant generatedAt;
    public Instant createdAt;
    public Instant updatedAt;
    @Lob @Column(columnDefinition = "CLOB") public String jsonPayload;
    public WikiEntity() {}
}
