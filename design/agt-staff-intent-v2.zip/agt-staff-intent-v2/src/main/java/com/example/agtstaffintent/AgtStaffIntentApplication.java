package com.example.agtstaffintent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgtStaffIntentApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgtStaffIntentApplication.class, args);
    }
}
