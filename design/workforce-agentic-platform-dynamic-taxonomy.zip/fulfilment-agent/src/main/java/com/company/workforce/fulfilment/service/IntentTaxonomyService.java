package com.company.workforce.fulfilment.service;

import com.company.workforce.fulfilment.service.model.IntentTaxonomyContext;
import java.util.List;

public interface IntentTaxonomyService {
    IntentTaxonomyContext getContext(String utterance, String domain, List<String> candidateIntents);
}
