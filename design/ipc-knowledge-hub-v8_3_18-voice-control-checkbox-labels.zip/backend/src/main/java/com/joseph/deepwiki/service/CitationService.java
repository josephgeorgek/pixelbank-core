package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.CodeChunk;
import com.joseph.deepwiki.model.WikiModels.SearchHit;
import org.springframework.stereotype.Service;

@Service
public class CitationService {
    public String format(CodeChunk chunk) {
        return chunk.path() + ":" + chunk.startLine() + "-" + chunk.endLine();
    }

    public String format(SearchHit hit) {
        return hit.path() + ":" + hit.startLine() + "-" + hit.endLine();
    }
}
