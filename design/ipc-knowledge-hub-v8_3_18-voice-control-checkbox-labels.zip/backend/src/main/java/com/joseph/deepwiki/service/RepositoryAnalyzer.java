package com.joseph.deepwiki.service;

import com.joseph.deepwiki.config.DeepWikiProperties;
import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class RepositoryAnalyzer {
    private static final Set<String> SKIP_DIRS = Set.of(".git", "node_modules", "target", "build", "dist", ".next", ".idea", ".vscode", "coverage");
    private static final Set<String> TEXT_EXTENSIONS = Set.of("java", "js", "jsx", "ts", "tsx", "py", "go", "rs", "kt", "yml", "yaml", "json", "xml", "md", "sql", "sh", "css", "html", "properties", "gradle", "pom");
    private static final Pattern JAVA_IMPORT = Pattern.compile("(?m)^\\s*import\\s+([a-zA-Z0-9_.*]+);");
    private static final Pattern JS_IMPORT = Pattern.compile("(?m)^\\s*import\\s+(?:[^'\"]+from\\s+)?['\"]([^'\"]+)['\"]");
    private static final Pattern SPRING_ROUTE = Pattern.compile("@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|RequestMapping)(\\([^)]*\\))?");
    private static final Pattern REACT_COMPONENT = Pattern.compile("(?m)(?:function|const)\\s+([A-Z][A-Za-z0-9_]*)");
    private final DeepWikiProperties properties;

    public RepositoryAnalyzer(DeepWikiProperties properties) {
        this.properties = properties;
    }

    public AnalysisResult analyze(String repoUrl, String branch, String token) {
        String normalizedRepoUrl = normalizeRepoUrl(repoUrl);
        validateRepoUrl(normalizedRepoUrl);
        Path tempDir;
        try {
            tempDir = Files.createTempDirectory("deepwiki-repo-");
            cloneRepository(normalizedRepoUrl, branch, token, tempDir);
            List<FileSummary> files = summarizeFiles(tempDir);
            List<CodeChunk> chunks = chunkFiles(files);
            List<SymbolRef> symbols = extractSymbols(files);
            Map<String, Long> stats = languageStats(files);
            ArchitectureGraph graph = buildArchitectureGraph(files);
            return new AnalysisResult(tempDir, files, chunks, symbols, stats, graph);
        } catch (Exception e) {
            throw new IllegalStateException("Repository analysis failed: " + e.getMessage(), e);
        }
    }

    private void cloneRepository(String repoUrl, String branch, String token, Path tempDir) throws IOException, InterruptedException {
        CloneResult firstAttempt = runClone(repoUrl, branch, token, tempDir);
        if (firstAttempt.success()) {
            return;
        }

        boolean branchMissing = StringUtils.hasText(branch)
                && (firstAttempt.output().contains("Remote branch")
                || firstAttempt.output().contains("not found in upstream origin")
                || firstAttempt.output().contains("couldn't find remote ref"));

        if (branchMissing) {
            clearDirectory(tempDir);
            CloneResult fallbackAttempt = runClone(repoUrl, null, token, tempDir);
            if (fallbackAttempt.success()) {
                return;
            }
            throw new IllegalStateException("git clone failed. Requested branch `" + branch + "` was not found, and default-branch clone also failed: " + scrub(fallbackAttempt.output()));
        }

        throw new IllegalStateException("git clone failed: " + scrub(firstAttempt.output()));
    }

    private CloneResult runClone(String repoUrl, String branch, String token, Path tempDir) throws IOException, InterruptedException {
        List<String> command = new ArrayList<>(List.of("git", "clone", "--depth", "1"));
        if (StringUtils.hasText(branch)) {
            command.addAll(List.of("--branch", branch.trim()));
        }
        command.add(withToken(repoUrl, token));
        command.add(tempDir.toString());

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();
        boolean ok = process.waitFor(properties.getCloneTimeoutSeconds(), TimeUnit.SECONDS);
        String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        if (!ok) {
            process.destroyForcibly();
            return new CloneResult(false, "git clone timed out");
        }
        return new CloneResult(process.exitValue() == 0, output);
    }

    private void clearDirectory(Path directory) throws IOException {
        if (!Files.exists(directory)) {
            return;
        }
        try (Stream<Path> walk = Files.walk(directory)) {
            List<Path> paths = walk.sorted(Comparator.reverseOrder()).toList();
            for (Path path : paths) {
                if (!path.equals(directory)) {
                    Files.deleteIfExists(path);
                }
            }
        }
    }

    private record CloneResult(boolean success, String output) {}

    private String normalizeRepoUrl(String repoUrl) {
        String normalized = Optional.ofNullable(repoUrl).orElse("").trim();
        while (normalized.endsWith("/")) {
            normalized = normalized.substring(0, normalized.length() - 1);
        }
        if (normalized.endsWith(".git")) {
            return normalized;
        }
        return normalized;
    }

    private String withToken(String repoUrl, String token) {
        if (!StringUtils.hasText(token)) return repoUrl;
        URI uri = URI.create(repoUrl);
        String cleanToken = token.trim();
        return uri.getScheme() + "://x-access-token:" + cleanToken + "@" + uri.getHost() + uri.getPath();
    }

    private void validateRepoUrl(String repoUrl) {
        URI uri = URI.create(repoUrl);
        if (!"https".equalsIgnoreCase(uri.getScheme())) throw new IllegalArgumentException("Only HTTPS Git URLs are accepted");
        String host = Optional.ofNullable(uri.getHost()).orElse("").toLowerCase(Locale.ROOT);
        if (!(host.endsWith("github.com") || host.endsWith("gitlab.com") || host.endsWith("bitbucket.org"))) {
            throw new IllegalArgumentException("Only GitHub, GitLab, or Bitbucket hosts are accepted by default");
        }
    }

    private List<FileSummary> summarizeFiles(Path repo) throws IOException {
        List<FileSummary> results = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(repo)) {
            paths.filter(Files::isRegularFile)
                    .filter(path -> !isSkipped(repo.relativize(path)))
                    .filter(this::isReadableText)
                    .limit(properties.getMaxFiles())
                    .forEach(path -> results.add(toSummary(repo, path)));
        }
        return results;
    }

    private boolean isSkipped(Path relative) {
        for (Path part : relative) if (SKIP_DIRS.contains(part.toString())) return true;
        return false;
    }

    private boolean isReadableText(Path path) {
        try {
            if (Files.size(path) > properties.getMaxFileBytes()) return false;
            String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
            String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : name;
            return TEXT_EXTENSIONS.contains(ext) || name.equals("dockerfile") || name.equals("pom.xml");
        } catch (IOException e) {
            return false;
        }
    }

    private FileSummary toSummary(Path repo, Path path) {
        try {
            String content = Files.readString(path, StandardCharsets.UTF_8);
            String preview = content.lines().limit(160).reduce("", (a, b) -> a + b + "\n");
            String relative = repo.relativize(path).toString().replace('\\', '/');
            return new FileSummary(relative, language(relative), Files.size(path), preview.trim());
        } catch (Exception e) {
            return new FileSummary(repo.relativize(path).toString().replace('\\', '/'), "unknown", 0, "");
        }
    }


    private List<CodeChunk> chunkFiles(List<FileSummary> files) {
        List<CodeChunk> chunks = new ArrayList<>();
        for (FileSummary file : files) {
            List<String> lines = Optional.ofNullable(file.preview()).orElse("").lines().toList();
            if (lines.isEmpty()) {
                chunks.add(new CodeChunk(chunkId(file.path(), 1), file.path(), file.language(), 1, 1, "", List.of()));
                continue;
            }
            int window = 80;
            for (int start = 0; start < lines.size(); start += window) {
                int end = Math.min(lines.size(), start + window);
                String content = String.join("\n", lines.subList(start, end));
                List<String> symbols = classNames(content).stream().limit(12).toList();
                chunks.add(new CodeChunk(chunkId(file.path(), start + 1), file.path(), file.language(), start + 1, end, content, symbols));
            }
        }
        return chunks;
    }

    private List<SymbolRef> extractSymbols(List<FileSummary> files) {
        List<SymbolRef> symbols = new ArrayList<>();
        for (FileSummary file : files) {
            List<String> lines = Optional.ofNullable(file.preview()).orElse("").lines().toList();
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                Matcher javaType = Pattern.compile("\\b(class|interface|record|enum)\\s+([A-Za-z0-9_]+)").matcher(line);
                if (javaType.find()) symbols.add(new SymbolRef(file.path(), javaType.group(2), javaType.group(1), i + 1));
                Matcher javaMethod = Pattern.compile("(?:public|private|protected)?\\s*(?:static\\s+)?[A-Za-z0-9_<>, ?]+\\s+([a-zA-Z_][A-Za-z0-9_]*)\\s*\\([^;]*\\)\\s*(?:\\{|throws)").matcher(line);
                if (javaMethod.find()) symbols.add(new SymbolRef(file.path(), javaMethod.group(1), "method", i + 1));
                Matcher route = SPRING_ROUTE.matcher(line);
                if (route.find()) symbols.add(new SymbolRef(file.path(), route.group(1), "spring-route", i + 1));
                Matcher react = REACT_COMPONENT.matcher(line);
                if (react.find()) symbols.add(new SymbolRef(file.path(), react.group(1), "react-component", i + 1));
            }
        }
        return symbols.stream().limit(1200).toList();
    }

    private Map<String, Long> languageStats(List<FileSummary> files) {
        Map<String, Long> stats = new TreeMap<>();
        for (FileSummary file : files) stats.merge(file.language(), 1L, Long::sum);
        return stats;
    }

    public ArchitectureGraph buildArchitectureGraph(List<FileSummary> files) {
        List<GraphNode> nodes = new ArrayList<>();
        List<GraphEdge> edges = new ArrayList<>();
        Map<String, String> pathToId = new LinkedHashMap<>();
        Map<String, String> simpleNameToId = new HashMap<>();

        for (FileSummary file : files) {
            String id = nodeId(file.path());
            pathToId.put(file.path(), id);
            simpleNameToId.put(simpleName(file.path()), id);
            classNames(file.preview()).forEach(name -> simpleNameToId.putIfAbsent(name, id));
            nodes.add(new GraphNode(id, label(file.path()), nodeType(file), file.path(), file.language(), area(file), file.bytes()));
        }

        int counter = 0;
        for (FileSummary file : files) {
            String source = pathToId.get(file.path());
            Set<String> targets = inferTargets(file, simpleNameToId, pathToId);
            for (String target : targets) {
                if (!source.equals(target)) {
                    edges.add(new GraphEdge("e" + (++counter), source, target, edgeKind(file), "uses/imports"));
                }
            }
        }

        counter = addAreaFlowEdges(files, pathToId, edges, counter);
        Map<String, Long> nodeStats = nodes.stream().collect(Collectors.groupingBy(GraphNode::type, TreeMap::new, Collectors.counting()));
        Map<String, Long> edgeStats = edges.stream().collect(Collectors.groupingBy(GraphEdge::kind, TreeMap::new, Collectors.counting()));
        return new ArchitectureGraph(nodes, edges.stream().limit(420).toList(), nodeStats, edgeStats);
    }

    private int addAreaFlowEdges(List<FileSummary> files, Map<String, String> pathToId, List<GraphEdge> edges, int counter) {
        Optional<FileSummary> api = files.stream().filter(f -> area(f).equals("api-layer")).findFirst();
        Optional<FileSummary> domain = files.stream().filter(f -> area(f).equals("domain-services")).findFirst();
        Optional<FileSummary> data = files.stream().filter(f -> area(f).equals("data-layer")).findFirst();
        if (api.isPresent() && domain.isPresent()) edges.add(new GraphEdge("e" + (++counter), pathToId.get(api.get().path()), pathToId.get(domain.get().path()), "runtime-flow", "API calls service"));
        if (domain.isPresent() && data.isPresent()) edges.add(new GraphEdge("e" + (++counter), pathToId.get(domain.get().path()), pathToId.get(data.get().path()), "runtime-flow", "service uses data"));
        return counter;
    }

    private Set<String> inferTargets(FileSummary file, Map<String, String> simpleNameToId, Map<String, String> pathToId) {
        Set<String> targets = new LinkedHashSet<>();
        if (file.language().equals("Java")) {
            Matcher m = JAVA_IMPORT.matcher(file.preview());
            while (m.find()) {
                String imported = m.group(1);
                String name = imported.substring(imported.lastIndexOf('.') + 1).replace("*", "");
                if (simpleNameToId.containsKey(name)) targets.add(simpleNameToId.get(name));
            }
        }
        if (file.language().equals("JavaScript") || file.language().equals("TypeScript")) {
            Matcher m = JS_IMPORT.matcher(file.preview());
            while (m.find()) {
                String imported = m.group(1);
                resolveJsImport(file.path(), imported, pathToId).ifPresent(targets::add);
            }
        }
        Matcher route = SPRING_ROUTE.matcher(file.preview());
        if (route.find()) {
            pathToId.entrySet().stream()
                    .filter(e -> e.getKey().toLowerCase(Locale.ROOT).contains("service"))
                    .limit(3)
                    .map(Map.Entry::getValue)
                    .forEach(targets::add);
        }
        return targets;
    }

    private Optional<String> resolveJsImport(String sourcePath, String imported, Map<String, String> pathToId) {
        if (!imported.startsWith(".")) return Optional.empty();
        Path base = Paths.get(sourcePath).getParent();
        Path normalized = base == null ? Paths.get(imported).normalize() : base.resolve(imported).normalize();
        String partial = normalized.toString().replace('\\', '/').replaceAll("^/", "");
        return pathToId.entrySet().stream()
                .filter(e -> e.getKey().equals(partial) || e.getKey().equals(partial + ".js") || e.getKey().equals(partial + ".jsx") || e.getKey().equals(partial + ".ts") || e.getKey().equals(partial + ".tsx") || e.getKey().equals(partial + "/index.js") || e.getKey().equals(partial + "/index.jsx"))
                .map(Map.Entry::getValue)
                .findFirst();
    }

    private List<String> classNames(String preview) {
        List<String> names = new ArrayList<>();
        Matcher javaMatcher = Pattern.compile("(?m)(class|interface|record|enum)\\s+([A-Za-z0-9_]+)").matcher(preview == null ? "" : preview);
        while (javaMatcher.find()) names.add(javaMatcher.group(2));
        Matcher reactMatcher = REACT_COMPONENT.matcher(preview == null ? "" : preview);
        while (reactMatcher.find()) names.add(reactMatcher.group(1));
        return names;
    }

    public String area(FileSummary file) {
        String path = file.path().replace('\\', '/').toLowerCase(Locale.ROOT);
        if (path.contains("/controller") || path.contains("/routes") || path.contains("/api")) return "api-layer";
        if (path.contains("/service") || path.contains("/domain") || path.contains("/usecase")) return "domain-services";
        if (path.contains("/repository") || path.contains("/dao") || path.contains("/entity") || path.contains("/model")) return "data-layer";
        if (path.contains("/components") || path.endsWith(".jsx") || path.endsWith(".tsx")) return "frontend-components";
        if (path.contains("dockerfile") || path.contains("docker-compose") || path.endsWith(".yml") || path.endsWith(".yaml")) return "deployment-config";
        if (path.endsWith("readme.md") || path.endsWith(".md")) return "documentation";
        if (path.contains("/test")) return "tests";
        return "source-overview";
    }

    private String edgeKind(FileSummary file) {
        if (file.language().equals("Java") && file.preview().contains("Mapping")) return "api-dependency";
        if (file.language().equals("JavaScript") || file.language().equals("TypeScript")) return "component-import";
        return "dependency";
    }

    private String nodeType(FileSummary file) {
        String path = file.path().toLowerCase(Locale.ROOT);
        String preview = Optional.ofNullable(file.preview()).orElse("");
        if (preview.contains("@RestController") || preview.contains("@Controller")) return "controller";
        if (preview.contains("@Service")) return "service";
        if (preview.contains("@Repository")) return "repository";
        if (preview.contains("@Entity") || path.contains("/model/")) return "model";
        if (file.language().equals("TypeScript") || file.language().equals("JavaScript")) return path.endsWith(".tsx") || path.endsWith(".jsx") ? "react-component" : "script";
        if (area(file).equals("deployment-config")) return "config";
        if (file.language().equals("Markdown")) return "documentation";
        return "source-file";
    }

    private String language(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".java")) return "Java";
        if (lower.endsWith(".tsx") || lower.endsWith(".ts")) return "TypeScript";
        if (lower.endsWith(".jsx") || lower.endsWith(".js")) return "JavaScript";
        if (lower.endsWith(".py")) return "Python";
        if (lower.endsWith(".yml") || lower.endsWith(".yaml")) return "YAML";
        if (lower.endsWith(".md")) return "Markdown";
        if (lower.endsWith("pom.xml")) return "Maven";
        if (lower.endsWith("dockerfile")) return "Docker";
        return "Other";
    }

    private String simpleName(String path) {
        String file = label(path);
        int dot = file.lastIndexOf('.');
        return dot > 0 ? file.substring(0, dot) : file;
    }

    private String label(String path) {
        int slash = path.lastIndexOf('/');
        return slash >= 0 ? path.substring(slash + 1) : path;
    }

    private String nodeId(String path) { return "n_" + Integer.toHexString(path.hashCode()).replace('-', 'x'); }
    private String chunkId(String path, int startLine) { return "c_" + Integer.toHexString((path + ":" + startLine).hashCode()).replace('-', 'x'); }
    private String scrub(String text) { return text.replaceAll("https://[^@\\s]+@", "https://***@"); }

    public record AnalysisResult(Path repoPath, List<FileSummary> files, List<CodeChunk> chunks, List<SymbolRef> symbols, Map<String, Long> languageStats, ArchitectureGraph architectureGraph) {}
}
