package com.example.agtstaffintent.domain;

public record ServiceCandidate(
        String service,
        String domain,
        String function,
        String action
) {
}
