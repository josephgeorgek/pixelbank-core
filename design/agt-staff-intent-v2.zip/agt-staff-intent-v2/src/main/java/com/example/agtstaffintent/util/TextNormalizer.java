package com.example.agtstaffintent.util;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public final class TextNormalizer {

    private static final Map<String, String> ALIAS_MAP = new LinkedHashMap<>();

    static {
        ALIAS_MAP.put("hip", "hip issue ticket case request");
        ALIAS_MAP.put("ticket", "ticket issue case request");
        ALIAS_MAP.put("incident", "incident issue case request");
    }

    private TextNormalizer() {
    }

    public static String normalize(String value) {
        if (value == null) {
            return "";
        }
        return Normalizer.normalize(value, Normalizer.Form.NFKC)
                .replaceAll("[^a-zA-Z0-9\\s-]", " ")
                .toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", " ")
                .trim();
    }

    public static String normalizeAndExpand(String value) {
        String normalized = normalize(value);
        if (normalized.isBlank()) {
            return normalized;
        }
        String expanded = normalized;
        for (Map.Entry<String, String> entry : ALIAS_MAP.entrySet()) {
            expanded = expanded.replaceAll("(?i)\\b" + java.util.regex.Pattern.quote(entry.getKey()) + "\\b", entry.getValue());
        }
        return expanded.replaceAll("\\s+", " ").trim();
    }

    public static Set<String> tokens(String value) {
        String normalized = normalizeAndExpand(value);
        if (normalized.isBlank()) {
            return Set.of();
        }
        return Arrays.stream(normalized.split("\\s+"))
                .filter(token -> token.length() > 1)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }
}
