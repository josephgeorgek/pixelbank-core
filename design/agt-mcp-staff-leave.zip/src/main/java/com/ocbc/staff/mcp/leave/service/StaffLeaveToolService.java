package com.ocbc.staff.mcp.leave.service;

import com.ocbc.staff.mcp.leave.config.StaffLeaveProperties;
import com.ocbc.staff.mcp.leave.model.ToolModels.ApproveMedicalLeavesArgs;
import com.ocbc.staff.mcp.leave.model.ToolModels.GetMedicalLeaveDocumentsArgs;
import com.ocbc.staff.mcp.leave.model.ToolModels.ListPendingMedicalLeavesArgs;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StaffLeaveToolService {
    private final StaffLeaveProperties properties;
    private final DownstreamHttpService http;

    public StaffLeaveToolService(StaffLeaveProperties properties, DownstreamHttpService http) {
        this.properties = properties;
        this.http = http;
    }

    public Map<String, Object> listPendingMedicalLeaves(ListPendingMedicalLeavesArgs args) {
        String url = properties.getBaseUrl() + properties.getListPendingEndpoint();
        Map<String, Object> req = new LinkedHashMap<>();
        req.put("managerId", args.getManagerId());
        req.put("status", args.getStatus());
        req.put("certificateRequired", args.isCertificateRequired());
        req.put("fetchAll", args.isFetchAll());
        req.put("maxRecords", Math.min(args.getMaxRecords() == null ? properties.getMaxPageSize() : args.getMaxRecords(), properties.getMaxPageSize()));

        Map<String, Object> integration;
        try { integration = http.post(url, req); }
        catch (Exception ex) { integration = Map.of("integrationError", ex.getMessage()); }

        List<Map<String, Object>> items = List.of(
            leave("ML-1001","John Tan","2026-04-07","2026-04-08","HealthPlus Clinic","mc_john_tan.pdf"),
            leave("ML-1002","Asha Devi","2026-04-08","2026-04-08","City Medical","mc_asha_devi.pdf"),
            leave("ML-1003","Marcus Lee","2026-04-09","2026-04-09","GoodCare Clinic","mc_marcus_lee.pdf"),
            leave("ML-1004","Priya Nair","2026-04-10","2026-04-10","Wellness Family Clinic","mc_priya_nair.pdf"),
            leave("ML-1005","Daniel Ong","2026-04-10","2026-04-11","Central GP","mc_daniel_ong.pdf")
        );

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("summary", items.size() + " pending medical leave applications returned");
        out.put("items", items);
        out.put("itemsCount", items.size());
        out.put("hasMore", false);
        out.put("nextCursor", null);
        out.put("fetchedAt", Instant.now().toString());
        out.put("integration", integration);
        return out;
    }

    public Map<String, Object> getMedicalLeaveDocuments(GetMedicalLeaveDocumentsArgs args) {
        String url = properties.getBaseUrl() + properties.getDocumentsEndpoint();
        Map<String, Object> integration;
        try { integration = http.post(url, Map.of("leaveIds", args.getLeaveIds())); }
        catch (Exception ex) { integration = Map.of("integrationError", ex.getMessage()); }

        List<Map<String, Object>> documents = args.getLeaveIds().stream()
            .map(id -> Map.<String, Object>of(
                "leaveId", id,
                "documentId", "DOC-" + id,
                "fileName", "mc_" + id.toLowerCase() + ".pdf",
                "contentType", "application/pdf",
                "filePath", "/mock/mc/" + id.toLowerCase() + ".pdf"
            ))
            .collect(Collectors.toList());

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("documents", documents);
        out.put("missingDocuments", List.of());
        out.put("fetchedAt", Instant.now().toString());
        out.put("integration", integration);
        return out;
    }

    public Map<String, Object> approveMedicalLeaves(ApproveMedicalLeavesArgs args) {
        String url = properties.getBaseUrl() + properties.getApproveEndpoint();
        List<Map<String, Object>> filtered = args.getLeaveApplications().stream()
            .filter(item -> !"MATCH_TRUE_ONLY".equals(args.getApprovalMode()) || Boolean.TRUE.equals(item.get("match")))
            .collect(Collectors.toList());

        Map<String, Object> req = new LinkedHashMap<>();
        req.put("approverId", args.getApproverId());
        req.put("approvalMode", args.getApprovalMode());
        req.put("leaveApplications", filtered);

        Map<String, Object> integration;
        try { integration = http.post(url, req); }
        catch (Exception ex) { integration = Map.of("integrationError", ex.getMessage()); }

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("summary", filtered.size() + " medical leave applications approved");
        out.put("approved", filtered);
        out.put("failed", List.of());
        out.put("stats", Map.of("approved", filtered.size(), "failed", 0));
        out.put("processedAt", Instant.now().toString());
        out.put("integration", integration);
        return out;
    }

    private Map<String, Object> leave(String leaveId, String patientName, String from, String to, String clinic, String fileName) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("leaveId", leaveId);
        item.put("patientName", patientName);
        item.put("medicalLeaveDateFrom", from);
        item.put("medicalLeaveDateTo", to);
        item.put("clinicName", clinic);
        item.put("medicalCertificateAttached", true);
        item.put("medicalCertificateFileName", fileName);
        item.put("medicalCertificateContentType", "application/pdf");
        item.put("medicalCertificateFilePath", "/mock/mc/" + fileName);
        return item;
    }
}
