package com.example.healer;

public record ErrorEvent(
  String service,
  String incidentId,
  String transactionType,
  Double amount,
  String error,
  String timestamp
) {}
