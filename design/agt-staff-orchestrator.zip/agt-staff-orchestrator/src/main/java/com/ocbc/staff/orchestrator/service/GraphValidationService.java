package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.domain.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class GraphValidationService {

    public void validate(GraphDefinition graph) {
        if (graph.graphId() == null || graph.graphId().isBlank()) {
            throw new IllegalArgumentException("graphId is required");
        }
        if (graph.entryNode() == null || graph.entryNode().isBlank()) {
            throw new IllegalArgumentException("entryNode is required");
        }
        if (graph.nodes() == null || graph.nodes().isEmpty()) {
            throw new IllegalArgumentException("nodes are required");
        }

        Set<String> nodeIds = new HashSet<>();
        for (GraphNodeDefinition node : graph.nodes()) {
            if (!nodeIds.add(node.id())) {
                throw new IllegalArgumentException("Duplicate node id: " + node.id());
            }
        }

        if (!nodeIds.contains(graph.entryNode())) {
            throw new IllegalArgumentException("entryNode does not exist: " + graph.entryNode());
        }

        for (GraphNodeDefinition node : graph.nodes()) {
            if (node.transitions() != null) {
                node.transitions().forEach(transition -> {
                    if (transition.next() != null && !nodeIds.contains(transition.next())) {
                        throw new IllegalArgumentException("Unknown next node '" + transition.next() + "' from node " + node.id());
                    }
                });
            }
            if (node.onError() != null && node.onError().next() != null && !nodeIds.contains(node.onError().next())) {
                throw new IllegalArgumentException("Unknown onError next node '" + node.onError().next() + "' from node " + node.id());
            }
        }
    }
}
