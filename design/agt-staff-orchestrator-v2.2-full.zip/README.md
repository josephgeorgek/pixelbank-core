# agt-staff-orchestrator v2.2 full code

Includes the full Spring Boot codebase with:
- review graph
- approval graph
- endpoint-driven task execution
- detailed logging
- resume API
- normalized terminal outcomes
- generic terminal response generation
- STATE_UPDATE support

## Run
```bash
mvn clean compile
mvn spring-boot:run
```
