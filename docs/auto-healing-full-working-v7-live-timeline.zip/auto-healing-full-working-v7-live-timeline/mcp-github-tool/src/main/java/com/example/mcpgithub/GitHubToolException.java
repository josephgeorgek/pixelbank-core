package com.example.mcpgithub;

public class GitHubToolException extends RuntimeException {
  public GitHubToolException(String message, Throwable cause) {
    super(message, cause);
  }
}
