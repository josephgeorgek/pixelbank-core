const API_BASE = (typeof window !== 'undefined' && window.__IPC_API_BASE__) || '/api';

function normalizeError(status, payload, text) {
  const message = payload?.message || text || `HTTP ${status}`;
  if (status === 504) return 'Indexing timed out. Try fewer/lighter repos, leave Branch blank, or increase DEEPWIKI_CLONE_TIMEOUT_SECONDS.';
  if (status === 502) return message || 'Backend failed while cloning or analyzing the repository.';
  return message;
}

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    let payload = null;
    let text = '';
    try { payload = await res.clone().json(); } catch { text = await res.text(); }
    throw new Error(normalizeError(res.status, payload, text));
  }
  return res.json();
}

export function getCapabilities() { return request('/wiki/capabilities'); }
export function startWorkspaceIndex(payload) { return request('/workspaces/index', { method: 'POST', body: JSON.stringify(payload) }); }
export function getWorkspaceJob(jobId) { return request(`/workspaces/jobs/${jobId}`); }
export function generateWiki(payload) { return request('/wiki/generate', { method: 'POST', body: JSON.stringify(payload) }); }
export function askWiki(payload) { return request('/wiki/chat', { method: 'POST', body: JSON.stringify(payload) }); }
export function searchWiki(wikiId, query, limit = 10) { return request(`/wiki/${wikiId}/search?query=${encodeURIComponent(query)}&limit=${limit}`); }
export function listMcpTools() { return request('/mcp/tools'); }
export function callMcpTool(payload) { return request('/mcp/tools/call', { method: 'POST', body: JSON.stringify(payload) }); }

export function getRepoInsights(repoUrl) { return request(`/github/insights?repoUrl=${encodeURIComponent(repoUrl)}`); }

export function searchGitHubRepositories(query) { return request(`/github/repositories/search?query=${encodeURIComponent(query)}`); }

export function listWorkspaces() { return request('/workspaces'); }
