# Trace-enabled healer-agent

Drop-in replacement for `healer-agent`.

## Replace

```bash
rm -rf healer-agent
unzip healer-agent-trace-enabled.zip -d healer-agent
```

## docker-compose env

```yaml
healer-agent:
  environment:
    MCP_GITHUB_TOOL_URL: http://mcp-github-tool:8083
    OPENAI_API_KEY: ${OPENAI_API_KEY}
    OPENAI_MODEL: ${OPENAI_MODEL:-gpt-4.1-mini}
```

## Run

```bash
export OPENAI_API_KEY="your_key"
docker compose down -v --remove-orphans
docker compose up --build
```

## See traces

```bash
docker compose logs -f healer-agent
curl http://localhost:8081/api/healing/status
```

Fields added:
- aiRequestPrompt
- aiResponseRaw
- aiPlanJson
- aiRationale
- validationStatus
- trace
