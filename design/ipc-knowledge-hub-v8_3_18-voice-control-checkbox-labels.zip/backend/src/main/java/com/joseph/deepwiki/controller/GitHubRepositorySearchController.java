package com.joseph.deepwiki.controller;

import com.joseph.deepwiki.service.GitHubRepositorySearchService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/github")
public class GitHubRepositorySearchController {
    private final GitHubRepositorySearchService service;

    public GitHubRepositorySearchController(GitHubRepositorySearchService service) {
        this.service = service;
    }

    @GetMapping("/repositories/search")
    public GitHubRepositorySearchService.SearchResponse searchRepositories(@RequestParam String query) {
        return service.search(query);
    }
}
