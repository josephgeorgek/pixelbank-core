package com.ocbc.staff.orchestrator.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ocbc.staff.orchestrator.graph.GraphDefinition;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class GraphRegistryService {
    private final ObjectMapper objectMapper;
    private final Map<String, GraphDefinition> registry = new LinkedHashMap<>();

    public GraphRegistryService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() throws Exception {
        load("graphs/staff_leave_application_medical_cert_list_and_review.v2_1_1.json");
        load("graphs/staff_leave_application_medical_cert_approval.v2_1_1.json");
    }

    private void load(String path) throws Exception {
        ClassPathResource resource = new ClassPathResource(path);
        try (InputStream in = resource.getInputStream()) {
            GraphDefinition graph = objectMapper.readValue(in, GraphDefinition.class);
            registry.put(graph.getGraphId(), graph);
        }
    }

    public GraphDefinition getRequiredGraph(String graphId) {
        GraphDefinition graph = registry.get(graphId);
        if (graph == null) throw new IllegalArgumentException("Unknown graphId: " + graphId);
        return graph;
    }
}
