package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RepoMermaidGenerator {
    public String generate(ArchitectureGraph graph) {
        List<GraphNode> evidenceNodes = graph.nodes().stream()
                .filter(n -> Set.of("controller", "service", "repository", "model", "react-component", "config").contains(n.type()))
                .limit(60)
                .toList();
        Set<String> nodeIds = evidenceNodes.stream().map(GraphNode::id).collect(Collectors.toSet());
        List<GraphEdge> evidenceEdges = graph.edges().stream()
                .filter(e -> nodeIds.contains(e.source()) && nodeIds.contains(e.target()))
                .filter(e -> !e.source().equals(e.target()))
                .limit(80)
                .toList();
        if (evidenceNodes.size() < 3 || evidenceEdges.isEmpty()) {
            return """
                    flowchart TB
                      INSUFFICIENT_EVIDENCE[Component diagram unavailable: insufficient evidence-backed architecture nodes or edges]
                    """;
        }
        StringBuilder m = new StringBuilder("flowchart LR\n");
        Map<String, List<GraphNode>> byType = evidenceNodes.stream().collect(Collectors.groupingBy(GraphNode::type));
        addSubgraph(m, "Frontend", byType.getOrDefault("react-component", List.of()), 10);
        addSubgraph(m, "API", byType.getOrDefault("controller", List.of()), 10);
        addSubgraph(m, "Services", byType.getOrDefault("service", List.of()), 14);
        addSubgraph(m, "Data", concat(byType.getOrDefault("repository", List.of()), byType.getOrDefault("model", List.of())), 14);
        addSubgraph(m, "Config", byType.getOrDefault("config", List.of()), 8);
        for (GraphEdge edge : evidenceEdges) {
            m.append("  ").append(safe(edge.source())).append(" -->|").append(label(edge.kind())).append("| ").append(safe(edge.target())).append("\n");
        }
        return m.toString();
    }

    private List<GraphNode> concat(List<GraphNode> a, List<GraphNode> b) {
        List<GraphNode> list = new ArrayList<>(a);
        list.addAll(b);
        return list;
    }

    private void addSubgraph(StringBuilder m, String name, List<GraphNode> nodes, int limit) {
        if (nodes.isEmpty()) return;
        m.append("  subgraph ").append(safe(name)).append("[").append(name).append("]\n");
        nodes.stream().limit(limit).forEach(node -> m.append("    ").append(safe(node.id())).append("[").append(escape(node.label())).append("]\n"));
        m.append("  end\n");
    }

    private String label(String kind) { return Optional.ofNullable(kind).orElse("uses").replace("|", "/"); }
    private String safe(String id) { return id.replaceAll("[^a-zA-Z0-9_]", "_"); }
    private String escape(String s) { return Optional.ofNullable(s).orElse("").replace("[", "(").replace("]", ")").replace("\"", "'"); }
}
