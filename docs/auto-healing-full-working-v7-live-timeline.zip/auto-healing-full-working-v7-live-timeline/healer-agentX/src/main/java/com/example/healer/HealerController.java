package com.example.healer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.*;

@RestController
@RequestMapping("/api/healing")
public class HealerController {
  private static final Logger log = LoggerFactory.getLogger(HealerController.class);

  private final RestClient githubToolClient;
  private final AiHealingPlanner aiPlanner;
  private final HealingStatus status = new HealingStatus();

  private int stage = 0;
  private boolean prCreated = false;
  private long lastAdvanceMs = 0;

  public HealerController(@Value("${mcp.github-tool.url}") String mcpUrl, AiHealingPlanner aiPlanner) {
    log.info("[HEALER] MCP GitHub Tool URL={}", mcpUrl);
    this.githubToolClient = RestClient.builder().baseUrl(mcpUrl).build();
    this.aiPlanner = aiPlanner;
  }

  @PostMapping("/ingest-error")
  public Map<String,Object> ingestError(@RequestBody ErrorEvent event) {
    log.warn("[HEALER] Error ingested service={} txType={} error={}", event.service(), event.transactionType(), event.error());

    status.status = "INCIDENT_DETECTED";
    status.incidentId = event.incidentId() == null ? "PAY-99283" : event.incidentId();
    status.title = "SWIFT Bridge Fault";
    status.service = "Payment-Service";
    status.severity = "HIGH";
    status.affectedContainers = "3 of 12";
    status.error = event.error();
    status.transactionType = event.transactionType();
    status.actionRequired = "OPEN_INCIDENT";
    status.classification = null;
    status.branch = null;
    status.pullRequestUrl = null;
    status.aiPlanJson = null;
    status.timeline.clear();
    add("[DETECT] Runtime fault detected in payment-ms");
    stage = 1;
    prCreated = false;
    lastAdvanceMs = System.currentTimeMillis();

    return Map.of("status", "INGESTED", "incidentId", status.incidentId);
  }

  @GetMapping("/status")
  public HealingStatus getStatus() {
    autoAdvance();
    return status;
  }

  @PostMapping("/promote")
  public HealingStatus promote() {
    add("[PROMOTE] PROD deployment approved by Josh | Commander");
    add("[RESTORE] Payment-Service restored. Promotion completed.");
    status.status = "RESTORED";
    status.severity = "NORMAL";
    status.affectedContainers = "0 of 12";
    status.actionRequired = "NONE";
    return status;
  }

  @PostMapping("/reset")
  public HealingStatus reset() {
    stage = 0;
    prCreated = false;
    lastAdvanceMs = 0;
    status.status = "HEALTHY";
    status.incidentId = null;
    status.title = null;
    status.severity = "NORMAL";
    status.classification = null;
    status.affectedContainers = "0 of 12";
    status.branch = null;
    status.pullRequestUrl = null;
    status.error = null;
    status.transactionType = null;
    status.actionRequired = "NONE";
    status.aiPlanJson = null;
    status.timeline.clear();
    return status;
  }

  @PostMapping("/analyze")
  public String analyze(@RequestBody String error) {
    return aiPlanner.createPlan(error, "https://github.com/josephgeorgek/payment-processor-demo");
  }

  private void autoAdvance() {
    if (stage == 0 || "RESTORED".equals(status.status)) return;

    long now = System.currentTimeMillis();
    if (now - lastAdvanceMs < 3500) return;
    lastAdvanceMs = now;

    switch (stage) {
      case 1 -> {
        status.status = "AI_ANALYZING";
        add("[AI_ANALYZE] Spring AI/OpenAI analyzing exception, payload, and repo context");
        status.aiPlanJson = aiPlanner.createPlan(status.error, "https://github.com/josephgeorgek/payment-processor-demo");
        stage = 2;
      }
      case 2 -> {
        status.status = "ROOT_CAUSE_IDENTIFIED";
        status.classification = "PAYMENT_DEFAULT_CONFIG_DATA_GAP";
        add("[CLASSIFY] PAYMENT_DEFAULT_CONFIG_DATA_GAP");
        add("[ROOT_CAUSE] AI identified likely missing payment default/config/reference mapping for SWIFT_INTL");
        stage = 3;
      }
      case 3 -> {
        status.status = "PLAN_READY";
        add("[PLAN] AI-generated healing plan prepared with rollback and test plan");
        stage = 4;
      }
      case 4 -> {
        status.status = "CREATING_GITHUB_PR";
        add("[FIX] AI-proposed patch prepared for GitOps review");
        createGitHubPr();
        stage = 5;
      }
      case 5 -> {
        status.status = "AWAITING_PROD_APPROVAL";
        status.actionRequired = "PROMOTE_TO_PROD";
        add("[GITOPS] Hotfix branch created and PR opened for review");
        add("[PROMOTE] Awaiting PROD approval via GitHub PR");
        stage = 6;
      }
      default -> {}
    }
  }

  private void createGitHubPr() {
    if (prCreated) return;
    prCreated = true;

    Map<String,Object> req = Map.of(
      "incidentId", status.incidentId,
      "branchName", "auto-heal/PAY-99283-ai-healing",
      "filePath", "db/migration/V20260425__ai_healing_plan.sql",
      "fileContent", status.aiPlanJson == null ? "-- AI plan unavailable" : "-- AI-generated healing plan requires review\n" + status.aiPlanJson,
      "commitMessage", "Auto-heal PAY-99283: AI-generated healing plan",
      "prTitle", "Auto-heal PAY-99283: AI-generated healing plan",
      "prBody", "Generated by healer-agent using SKILL.md + Spring AI/OpenAI. Human review required before PROD."
    );

    Map result = githubToolClient.post()
      .uri("/tools/github/create-hotfix-pr")
      .body(req)
      .retrieve()
      .body(Map.class);

    status.branch = String.valueOf(result.get("branch"));
    status.pullRequestUrl = String.valueOf(result.get("pullRequestUrl"));
  }

  private void add(String line) {
    if (!status.timeline.contains(line)) status.timeline.add(line);
  }
}
