package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentTaxonomy;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class TaxonomyLoader {

    private final ObjectMapper objectMapper;
    private volatile List<IntentTaxonomy> cache = List.of();

    public TaxonomyLoader(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() {
        long start = System.nanoTime();
        this.cache = loadFromResources();
        long elapsedMs = (System.nanoTime() - start) / 1_000_000;
        log.info("TAXONOMY_CACHE_INIT count={} elapsedMs={}", cache.size(), elapsedMs);
    }

    public List<IntentTaxonomy> loadAll() {
        return cache;
    }

    private List<IntentTaxonomy> loadFromResources() {
        try {
            Resource[] resources = new PathMatchingResourcePatternResolver()
                    .getResources("classpath*:taxonomy/*.json");
            List<IntentTaxonomy> result = new ArrayList<>();
            for (Resource resource : resources) {
                try (InputStream is = resource.getInputStream()) {
                    result.add(objectMapper.readValue(is, IntentTaxonomy.class));
                }
            }
            return result;
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to load taxonomy files", ex);
        }
    }
}
