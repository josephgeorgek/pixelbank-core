package com.joseph.deepwiki.repository;
import com.joseph.deepwiki.entity.KeyContributorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface KeyContributorRepository extends JpaRepository<KeyContributorEntity, Long> { void deleteByWorkspaceId(String workspaceId); List<KeyContributorEntity> findByWorkspaceIdOrderByRankOrderAsc(String workspaceId); }
