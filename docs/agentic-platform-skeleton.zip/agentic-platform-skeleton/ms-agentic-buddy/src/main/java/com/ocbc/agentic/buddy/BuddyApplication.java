package com.ocbc.agentic.buddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuddyApplication {
    public static void main(String[] args) {
        SpringApplication.run(BuddyApplication.class, args);
    }
}
