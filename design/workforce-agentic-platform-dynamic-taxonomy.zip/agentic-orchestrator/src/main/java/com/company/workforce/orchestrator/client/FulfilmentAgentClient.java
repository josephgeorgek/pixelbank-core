package com.company.workforce.orchestrator.client;

import com.company.workforce.contracts.api.TaskExecutionRequest;
import com.company.workforce.contracts.api.TaskExecutionResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class FulfilmentAgentClient {

    private final WebClient webClient;

    public FulfilmentAgentClient(@Value("${services.fulfilment-agent.base-url}") String baseUrl) {
        this.webClient = WebClient.builder().baseUrl(baseUrl).build();
    }

    public TaskExecutionResponse executeTask(TaskExecutionRequest request) {
        return webClient.post()
                .uri("/v1/tasks/execute")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(TaskExecutionResponse.class)
                .block();
    }
}
