package com.company.workforce.orchestrator.controller;

import com.company.workforce.contracts.api.IntentExecutionRequest;
import com.company.workforce.contracts.api.IntentExecutionResponse;
import com.company.workforce.orchestrator.service.IntentExecutionService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1")
public class ExecutionController {

    private final IntentExecutionService intentExecutionService;

    public ExecutionController(IntentExecutionService intentExecutionService) {
        this.intentExecutionService = intentExecutionService;
    }

    @PostMapping("/execute/{intentId}")
    public IntentExecutionResponse execute(@PathVariable String intentId, @RequestBody IntentExecutionRequest request) {
        return intentExecutionService.execute(intentId, request);
    }
}
