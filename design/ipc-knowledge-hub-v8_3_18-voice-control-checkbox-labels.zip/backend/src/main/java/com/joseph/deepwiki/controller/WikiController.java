package com.joseph.deepwiki.controller;

import com.joseph.deepwiki.model.WikiModels.*;
import com.joseph.deepwiki.service.IndexJobService;
import com.joseph.deepwiki.service.WikiGenerationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Collection;
import java.util.Map;
import static java.util.Map.entry;

@RestController
@RequestMapping("/api/wiki")
@CrossOrigin(origins = "*")
public class WikiController {
    private final WikiGenerationService wikiGenerationService;
    private final IndexJobService indexJobService;

    public WikiController(WikiGenerationService wikiGenerationService, IndexJobService indexJobService) {
        this.wikiGenerationService = wikiGenerationService;
        this.indexJobService = indexJobService;
    }

    @PostMapping("/index")
    public ResponseEntity<IndexJobResponse> startIndex(@Valid @RequestBody GenerateWikiRequest request) {
        return ResponseEntity.accepted().body(indexJobService.start(request));
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<IndexJobStatus> job(@PathVariable String jobId) {
        return ResponseEntity.ok(indexJobService.get(jobId));
    }

    @PostMapping("/generate")
    public ResponseEntity<WikiResponse> generate(@Valid @RequestBody GenerateWikiRequest request) {
        return ResponseEntity.ok(wikiGenerationService.generate(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<WikiResponse> get(@PathVariable String id) {
        return wikiGenerationService.find(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public Collection<WikiResponse> list() { return wikiGenerationService.list(); }

    @PostMapping("/chat")
    public ResponseEntity<ChatResponse> chat(@Valid @RequestBody ChatRequest request) {
        return ResponseEntity.ok(wikiGenerationService.chat(request));
    }

    @GetMapping("/{id}/search")
    public ResponseEntity<SearchResponse> search(@PathVariable String id, @RequestParam String query, @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(wikiGenerationService.search(id, query, limit));
    }

    @GetMapping("/capabilities")
    public Map<String, Object> capabilities() {
        boolean openAiConfigured = System.getenv("OPENAI_API_KEY") != null && !System.getenv("OPENAI_API_KEY").isBlank();
        return Map.ofEntries(
                entry("applicationName", "Live Docs Knowledge Hub"),
                entry("version", "v8.3.18-landing-ui-indexed-cards"),
                entry("llmProvider", openAiConfigured ? "openai" : "none"),
                entry("llmConfigured", openAiConfigured),
                entry("asyncIndexing", true),
                entry("repoSpecificMermaid", true),
                entry("lineRangeCitations", true),
                entry("codeChunkIndex", true),
                entry("symbolExtraction", true),
                entry("search", true),
                entry("mcpBridge", true),
                entry("multiRepoWorkspaces", true),
                entry("workspaceInteractionDiagrams", true),
                entry("sequenceDiagrams", true),
                entry("keyContributorsOnly", true),
                entry("h2Persistence", true),
                entry("evidenceGatedDiagrams", true),
                entry("notes", openAiConfigured ? "Spring AI OpenAI ChatClient is configured." : "OpenAI key is not configured. Static analysis mode only.")
        );
    }
}
