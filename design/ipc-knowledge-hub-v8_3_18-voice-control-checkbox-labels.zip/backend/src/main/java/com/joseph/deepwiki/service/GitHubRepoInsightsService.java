package com.joseph.deepwiki.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class GitHubRepoInsightsService {
    private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public RepoInsights insights(String repoUrl, String token) {
        Optional<RepoRef> ref = parse(repoUrl);
        if (ref.isEmpty()) {
            return RepoInsights.empty(repoUrl, "Invalid GitHub repository URL");
        }
        RepoRef r = ref.get();
        Map<String, Object> about = new LinkedHashMap<>();
        Map<String, Object> security = new LinkedHashMap<>();
        Map<String, Object> pulse = new LinkedHashMap<>();
        Map<String, Object> performance = new LinkedHashMap<>();
        List<String> notes = new ArrayList<>();

        try {
            JsonNode repo = get("https://api.github.com/repos/" + r.owner() + "/" + r.repo(), token);
            about.put("repo", r.name());
            about.put("description", repo.path("description").asText("No repository About description returned."));
            about.put("homepage", repo.path("homepage").asText(""));
            about.put("stars", repo.path("stargazers_count").asInt(0));
            about.put("forks", repo.path("forks_count").asInt(0));
            about.put("openIssues", repo.path("open_issues_count").asInt(0));
            about.put("defaultBranch", repo.path("default_branch").asText("default"));
            about.put("topics", readTopics(repo.path("topics")));
            about.put("language", repo.path("language").asText("Not reported"));
        } catch (Exception e) {
            notes.add("About data unavailable from GitHub API: " + e.getMessage());
        }

        try {
            JsonNode community = get("https://api.github.com/repos/" + r.owner() + "/" + r.repo() + "/community/profile", token);
            security.put("healthPercentage", community.path("health_percentage").asInt(-1));
            JsonNode files = community.path("files");
            security.put("securityPolicy", fileState(files.path("security_policy")));
            security.put("codeOfConduct", fileState(files.path("code_of_conduct")));
            security.put("license", fileState(files.path("license")));
            security.put("contributing", fileState(files.path("contributing")));
            security.put("issueTemplate", fileState(files.path("issue_template")));
            security.put("pullRequestTemplate", fileState(files.path("pull_request_template")));
        } catch (Exception e) {
            security.put("securityPolicy", "Not available through GitHub community profile API.");
            notes.add("Security tab/community profile unavailable: " + e.getMessage());
        }

        try {
            String since = Instant.now().minus(30, ChronoUnit.DAYS).toString();
            JsonNode commits = get("https://api.github.com/repos/" + r.owner() + "/" + r.repo() + "/commits?since=" + since + "&per_page=30", token);
            JsonNode prs = get("https://api.github.com/repos/" + r.owner() + "/" + r.repo() + "/pulls?state=all&sort=updated&direction=desc&per_page=30", token);
            JsonNode issues = get("https://api.github.com/repos/" + r.owner() + "/" + r.repo() + "/issues?state=all&since=" + since + "&per_page=30", token);
            pulse.put("last30DaysCommits", commits.isArray() ? commits.size() : 0);
            pulse.put("recentPullRequests", prs.isArray() ? prs.size() : 0);
            pulse.put("recentIssuesAndPRs", issues.isArray() ? issues.size() : 0);
            pulse.put("summary", "Pulse approximation from GitHub API: recent commits, PRs, and issues in the last 30 days / latest page. The GitHub Pulse UI itself is not scraped.");
        } catch (Exception e) {
            pulse.put("summary", "Pulse data unavailable from GitHub API.");
            notes.add("Pulse data unavailable: " + e.getMessage());
        }

        try {
            JsonNode runs = get("https://api.github.com/repos/" + r.owner() + "/" + r.repo() + "/actions/runs?per_page=30", token);
            int total = 0, success = 0, failure = 0, inProgress = 0;
            long durationSumMs = 0;
            int durationCount = 0;
            if (runs.path("workflow_runs").isArray()) {
                for (JsonNode run : runs.path("workflow_runs")) {
                    total++;
                    String conclusion = run.path("conclusion").asText("");
                    String status = run.path("status").asText("");
                    if ("success".equalsIgnoreCase(conclusion)) success++;
                    if ("failure".equalsIgnoreCase(conclusion) || "timed_out".equalsIgnoreCase(conclusion) || "cancelled".equalsIgnoreCase(conclusion)) failure++;
                    if (!"completed".equalsIgnoreCase(status)) inProgress++;
                    try {
                        Instant created = Instant.parse(run.path("created_at").asText());
                        Instant updated = Instant.parse(run.path("updated_at").asText());
                        long d = Duration.between(created, updated).toMillis();
                        if (d > 0) { durationSumMs += d; durationCount++; }
                    } catch (Exception ignored) {}
                }
            }
            performance.put("workflowRunsSample", total);
            performance.put("successfulRuns", success);
            performance.put("failedOrCancelledRuns", failure);
            performance.put("inProgressRuns", inProgress);
            performance.put("averageRunMinutes", durationCount == 0 ? "Not available" : Math.round((durationSumMs / 60000.0 / durationCount) * 10.0) / 10.0);
            performance.put("summary", "Actions performance approximation from recent workflow runs. GitHub Actions metrics UI is not scraped.");
        } catch (Exception e) {
            performance.put("summary", "Actions performance data unavailable from GitHub API.");
            notes.add("Actions performance unavailable: " + e.getMessage());
        }

        return new RepoInsights(r.name(), repoUrl, about, security, pulse, performance, notes);
    }

    private String fileState(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return "Not detected";
        String html = node.path("html_url").asText("");
        String name = node.path("name").asText("");
        return StringUtils.hasText(name) ? name + (StringUtils.hasText(html) ? " — " + html : "") : "Detected";
    }

    private List<String> readTopics(JsonNode topics) {
        List<String> result = new ArrayList<>();
        if (topics.isArray()) topics.forEach(t -> result.add(t.asText()));
        return result;
    }

    private JsonNode get(String apiUrl, String token) throws Exception {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(apiUrl))
                .timeout(Duration.ofSeconds(12))
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "ipc-knowledge-hub");
        if (StringUtils.hasText(token)) builder.header("Authorization", "Bearer " + token.trim());
        HttpResponse<String> response = httpClient.send(builder.GET().build(), HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("GitHub API returned HTTP " + response.statusCode());
        }
        return objectMapper.readTree(response.body());
    }

    private Optional<RepoRef> parse(String repoUrl) {
        try {
            URI uri = URI.create(repoUrl);
            if (!"github.com".equalsIgnoreCase(uri.getHost())) return Optional.empty();
            String[] parts = uri.getPath().replaceAll("^/+", "").replaceAll("/+$", "").split("/");
            if (parts.length < 2) return Optional.empty();
            String repo = parts[1].replaceAll("\\.git$", "");
            return Optional.of(new RepoRef(parts[0], repo));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private record RepoRef(String owner, String repo) { String name() { return owner + "/" + repo; } }

    public record RepoInsights(String repo, String repoUrl, Map<String, Object> about, Map<String, Object> security, Map<String, Object> pulse, Map<String, Object> performance, List<String> notes) {
        static RepoInsights empty(String repoUrl, String note) {
            return new RepoInsights(repoUrl, repoUrl, Map.of(), Map.of(), Map.of(), Map.of(), List.of(note));
        }
    }
}
