package com.company.workforce.fulfilment.service.model;

import java.util.List;
import java.util.Map;

public record IntentDefinition(
        String intent,
        String description,
        List<String> synonyms,
        Map<String, String> entityHints,
        List<String> rules,
        List<String> examples
) {
}
