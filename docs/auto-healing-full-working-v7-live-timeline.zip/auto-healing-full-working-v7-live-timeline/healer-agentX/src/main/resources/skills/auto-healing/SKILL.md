# Auto-Healing Skill

## Purpose
Analyze runtime failures and propose the safest recoverable fix using evidence, repo context, and approved guardrails.

## Core Rule
Do not assume the fix upfront.

Infer from:
- runtime error
- logs
- failed payload
- service context
- repository reference
- allowed healing patterns

## Required JSON Output
Return JSON only:
{
  "classification": "",
  "rootCause": "",
  "confidence": 0.0,
  "proposedFixType": "",
  "filesToChange": [],
  "patchContent": "",
  "testPlan": [],
  "rollbackPlan": "",
  "requiresHumanApproval": true
}

## Allowed Fix Types
- CONFIG_DEFAULT_PATCH
- REFERENCE_DATA_PATCH
- ENV_CONFIG_PATCH
- ROUTING_CONFIG_PATCH
- TIMEOUT_RETRY_POLICY_PATCH
- SCHEMA_MAPPING_PATCH
- TEST_ONLY_REPRODUCTION
- ESCALATE_TO_DEVELOPER

## Guardrails
- Prefer config/reference-data over code changes.
- Never patch PROD directly.
- Never invent business values unless found in repo or policy.
- If uncertain, use REVIEW_REQUIRED.
- Always include rollback.
- Always include test plan.
- Always create GitHub PR for human review.
