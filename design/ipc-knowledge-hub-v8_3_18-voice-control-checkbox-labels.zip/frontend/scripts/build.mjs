import { build } from 'esbuild';
import { mkdir, rm, writeFile } from 'node:fs/promises';

await rm('dist', { recursive: true, force: true });
await mkdir('dist/assets', { recursive: true });
await build({
  entryPoints: ['src/main.jsx'],
  bundle: true,
  outfile: 'dist/assets/index-v8316.js',
  format: 'esm',
  minify: true,
  sourcemap: false,
  loader: { '.ts': 'ts', '.jsx': 'jsx', '.css': 'css' },
  jsx: 'automatic',
  target: ['es2020']
});
await writeFile('dist/index.html', `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Live Docs Knowledge Hub</title>
    <link rel="stylesheet" href="/assets/index-v8316.css" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/assets/index-v8316.js"></script>
  </body>
</html>
`);
