package com.company.workforce.contracts.enums;

public enum TaskType {
    API_CALL,
    AI_EXTRACT
}
