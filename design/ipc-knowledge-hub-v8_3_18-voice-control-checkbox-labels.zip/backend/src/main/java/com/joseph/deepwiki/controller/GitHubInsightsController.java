package com.joseph.deepwiki.controller;

import com.joseph.deepwiki.service.GitHubRepoInsightsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/github")
public class GitHubInsightsController {
    private final GitHubRepoInsightsService service;

    public GitHubInsightsController(GitHubRepoInsightsService service) {
        this.service = service;
    }

    @GetMapping("/insights")
    public GitHubRepoInsightsService.RepoInsights insights(@RequestParam String repoUrl,
                                                           @RequestParam(required = false) String token) {
        return service.insights(repoUrl, token);
    }
}
