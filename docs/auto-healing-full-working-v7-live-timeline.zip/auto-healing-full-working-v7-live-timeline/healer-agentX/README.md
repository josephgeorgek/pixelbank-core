# healer-agent AI + SKILL.md v2

Drop-in replacement for the existing `healer-agent` folder.

## Replace

```bash
rm -rf healer-agent
unzip healer-agent-ai-skill-v2.zip -d healer-agent
```

## Required env

```bash
export OPENAI_API_KEY="your_openai_key"
```

Existing compose should already provide:

```text
MCP_GITHUB_TOOL_URL=http://mcp-github-tool:8083
```

## Run

```bash
docker compose up --build
```

This keeps existing `/api/healing/status`, `/api/healing/ingest-error`, `/api/healing/promote` APIs and adds AI SKILL.md analysis.
