package com.ocbc.agentic.common.model;

import jakarta.validation.constraints.NotBlank;

public record UserRequest(
        @NotBlank String userId,
        @NotBlank String sessionId,
        @NotBlank String text,
        String channel,
        String locale) {
}
