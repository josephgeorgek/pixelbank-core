package com.ocbc.agentic.orchestrator.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.ocbc.agentic.common.model.GraphState;
import com.ocbc.agentic.common.model.IntentResolution;
import com.ocbc.agentic.common.model.OrchestrationResponse;
import com.ocbc.agentic.common.model.UserRequest;
import com.ocbc.agentic.orchestrator.graph.GraphLoader;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OrchestratorService {
    private final GraphLoader graphLoader;

    public OrchestratorService(GraphLoader graphLoader) {
        this.graphLoader = graphLoader;
    }

    public OrchestrationResponse execute(UserRequest request) {
        // TODO: replace with HTTP/WebClient calls to intent-agent, ms-control-gate, fulfilment-agent.
        IntentResolution resolution = new IntentResolution(
                "HOTDESK_BOOKING",
                Map.of("location", "OCBC Changi", "date", "2026-03-18", "timeSlot", "MORNING"),
                "ms-workplace-booking",
                "book_hot_desk_v1",
                0.93,
                true
        );

        JsonNode graph = graphLoader.load(resolution.graphId());
        GraphState state = new GraphState()
                .put("userRequest", request)
                .put("intent", resolution)
                .put("graph", graph);

        return new OrchestrationResponse(
                request.sessionId(),
                "SUCCESS",
                "Graph loaded and ready for execution",
                Map.of("graphId", resolution.graphId(), "state", state.asMap()));
    }
}
