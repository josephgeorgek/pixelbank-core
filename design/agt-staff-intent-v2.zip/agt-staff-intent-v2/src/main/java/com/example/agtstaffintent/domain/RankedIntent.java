package com.example.agtstaffintent.domain;

import java.util.List;

public record RankedIntent(
        IntentTaxonomy taxonomy,
        double similarityScore,
        List<String> matchedSignals,
        List<String> rejectedSignals,
        boolean shortlisted
) {
}
