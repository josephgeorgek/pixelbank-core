package com.example.agtstaffintent.api;

import com.example.agtstaffintent.domain.IntentRequest;
import com.example.agtstaffintent.domain.IntentResponse;
import com.example.agtstaffintent.service.IntentDiscoveryService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/intent")
public class IntentController {

    private final IntentDiscoveryService intentDiscoveryService;

    public IntentController(IntentDiscoveryService intentDiscoveryService) {
        this.intentDiscoveryService = intentDiscoveryService;
    }

    @PostMapping("/discover")
    public IntentResponse discover(@Valid @RequestBody IntentRequest request,
                                   @RequestHeader(value = "X-Debug", required = false) String debugHeader) {
        boolean debug = "true".equalsIgnoreCase(debugHeader);
        return intentDiscoveryService.discover(request, debug);
    }
}
