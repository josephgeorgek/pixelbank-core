package com.company.workforce.contracts.api;

import java.util.Map;

public record IntentExecutionRequest(Map<String, Object> input) {
}
