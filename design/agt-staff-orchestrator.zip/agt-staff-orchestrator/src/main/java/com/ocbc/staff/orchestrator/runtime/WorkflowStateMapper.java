package com.ocbc.staff.orchestrator.runtime;

import com.ocbc.staff.orchestrator.domain.runtime.WorkflowExecutionStatus;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public final class WorkflowStateMapper {

    private WorkflowStateMapper() {
    }

    @SuppressWarnings("unchecked")
    public static WorkflowState fromMap(Map<String, Object> source) {
        WorkflowState state = new WorkflowState();
        state.setExecutionId(stringValue(source.get("executionId")));
        state.setGraphId(stringValue(source.get("graphId")));
        state.setGraphVersion(stringValue(source.get("graphVersion")));
        String status = stringValue(source.get("status"));
        if (status != null && !status.isBlank()) {
            state.setStatus(WorkflowExecutionStatus.valueOf(status));
        }
        state.setCurrentNodeId(stringValue(source.get("currentNodeId")));
        state.setInput((Map<String, Object>) source.getOrDefault("input", new LinkedHashMap<>()));
        state.setIntentResult((Map<String, Object>) source.getOrDefault("intentResult", new LinkedHashMap<>()));
        state.getTaskResults().putAll((Map<String, Object>) source.getOrDefault("taskResults", new LinkedHashMap<>()));
        state.setFinalOutput((Map<String, Object>) source.getOrDefault("finalOutput", new LinkedHashMap<>()));
        state.getErrors().addAll((java.util.List<Map<String, Object>>) source.getOrDefault("errors", java.util.List.of()));
        if (source.get("startedAt") != null) {
            state.setStartedAt(Instant.parse(stringValue(source.get("startedAt"))));
        }
        if (source.get("updatedAt") != null) {
            state.setUpdatedAt(Instant.parse(stringValue(source.get("updatedAt"))));
        }
        if (source.get("completedAt") != null) {
            state.setCompletedAt(Instant.parse(stringValue(source.get("completedAt"))));
        }
        return state;
    }

    public static Map<String, Object> toMap(WorkflowState state) {
        return state.asMap();
    }

    private static String stringValue(Object value) {
        return value == null ? null : String.valueOf(value);
    }
}
