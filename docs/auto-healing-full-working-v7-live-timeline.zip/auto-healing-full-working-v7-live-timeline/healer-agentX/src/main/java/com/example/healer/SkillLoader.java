package com.example.healer;

import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;

@Service
public class SkillLoader {
  public String loadAutoHealingSkill() {
    try (var in = getClass().getResourceAsStream("/skills/auto-healing/SKILL.md")) {
      if (in == null) throw new IllegalStateException("SKILL.md not found");
      return new String(in.readAllBytes(), StandardCharsets.UTF_8);
    } catch (Exception e) {
      throw new IllegalStateException("Unable to load Auto-Healing SKILL.md", e);
    }
  }
}
