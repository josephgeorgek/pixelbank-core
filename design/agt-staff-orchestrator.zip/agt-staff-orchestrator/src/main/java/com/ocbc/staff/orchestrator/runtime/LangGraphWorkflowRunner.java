package com.ocbc.staff.orchestrator.runtime;

import com.ocbc.staff.orchestrator.domain.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import com.ocbc.staff.orchestrator.service.WorkflowEngine;
import org.bsc.langgraph4j.StateGraph;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

@Component
public class LangGraphWorkflowRunner {

    private final WorkflowEngine workflowEngine;

    public LangGraphWorkflowRunner(WorkflowEngine workflowEngine) {
        this.workflowEngine = workflowEngine;
    }

    public WorkflowState run(GraphDefinition graph, WorkflowState workflowState) {
        try {
            var stateGraph = new StateGraph<>(LangGraphWorkflowState.SCHEMA, LangGraphWorkflowState::new)
                    .addNode("json_graph_orchestrator", node_async(state -> {
                        Map<String, Object> root = state.workflowState();
                        WorkflowState materialized = WorkflowStateMapper.fromMap(root);
                        WorkflowState executed = workflowEngine.execute(graph, materialized);
                        return Map.of(LangGraphWorkflowState.WORKFLOW_STATE, WorkflowStateMapper.toMap(executed));
                    }))
                    .addEdge(START, "json_graph_orchestrator")
                    .addEdge("json_graph_orchestrator", END);

            var compiled = stateGraph.compile();
            Map<String, Object> init = new LinkedHashMap<>();
            init.put(LangGraphWorkflowState.WORKFLOW_STATE, WorkflowStateMapper.toMap(workflowState));

            Map<String, Object> latest = null;
            for (Object item : compiled.stream(init)) {
                if (item instanceof Map<?, ?> map) {
                    latest = castMap(map);
                }
            }
            if (latest == null) {
                return workflowState;
            }
            Object nested = latest.get(LangGraphWorkflowState.WORKFLOW_STATE);
            if (nested instanceof Map<?, ?> map) {
                return WorkflowStateMapper.fromMap(castMap(map));
            }
            return workflowState;
        } catch (Exception e) {
            throw new IllegalStateException("LangGraph4j execution failed", e);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> castMap(Map<?, ?> map) {
        Map<String, Object> result = new LinkedHashMap<>();
        map.forEach((k, v) -> result.put(String.valueOf(k), v));
        return result;
    }
}
