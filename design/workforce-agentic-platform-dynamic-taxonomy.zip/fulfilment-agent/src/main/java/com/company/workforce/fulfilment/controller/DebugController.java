package com.company.workforce.fulfilment.controller;

import com.company.workforce.fulfilment.service.InMemoryIntentTaxonomyService;
import com.company.workforce.fulfilment.service.PromptBuilderService;
import com.company.workforce.fulfilment.service.model.IntentTaxonomyContext;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/debug")
public class DebugController {

    private final InMemoryIntentTaxonomyService taxonomyService;
    private final PromptBuilderService promptBuilderService;

    public DebugController(InMemoryIntentTaxonomyService taxonomyService,
                           PromptBuilderService promptBuilderService) {
        this.taxonomyService = taxonomyService;
        this.promptBuilderService = promptBuilderService;
    }

    @PostMapping("/render-prompt")
    public Map<String, Object> renderPrompt(@RequestBody Map<String, Object> request) {
        String utterance = String.valueOf(request.getOrDefault("utterance", ""));
        String domain = String.valueOf(request.getOrDefault("domain", "HR"));
        @SuppressWarnings("unchecked")
        List<String> candidateIntents = (List<String>) request.getOrDefault("candidateIntents", List.of());
        IntentTaxonomyContext context = taxonomyService.getContext(utterance, domain, candidateIntents);
        String systemPrompt = promptBuilderService.buildSystemPrompt(context, ZonedDateTime.now(promptBuilderService.getSingaporeZoneId()));
        return Map.of(
                "utterance", utterance,
                "domain", domain,
                "candidateIntents", candidateIntents,
                "taxonomyContext", context,
                "systemPrompt", systemPrompt
        );
    }
}
