package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.*;

@Service
public class WorkspaceIndexJobService {
    private final WorkspaceService workspaceService;
    private final PersistenceService persistenceService;
    private final ExecutorService executor = Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors() / 2));
    private final Map<String, MutableWorkspaceJob> jobs = new ConcurrentHashMap<>();

    public WorkspaceIndexJobService(WorkspaceService workspaceService, PersistenceService persistenceService) {
        this.workspaceService = workspaceService;
        this.persistenceService = persistenceService;
    }

    public WorkspaceIndexJobResponse start(MultiRepoIndexRequest request) {
        String jobId = UUID.randomUUID().toString();
        MutableWorkspaceJob job = new MutableWorkspaceJob(jobId);
        jobs.put(jobId, job);
        persistenceService.saveJob(jobId, "WORKSPACE", job.status, job.stage, job.progress, job.message, null, null, null, job.createdAt, job.updatedAt);
        executor.submit(() -> run(job, request));
        return new WorkspaceIndexJobResponse(jobId, "/api/workspaces/jobs/" + jobId);
    }

    public WorkspaceIndexJobStatus get(String jobId) {
        MutableWorkspaceJob job = jobs.get(jobId);
        if (job == null) throw new NoSuchElementException("Workspace index job not found: " + jobId);
        return job.toStatus();
    }

    private void run(MutableWorkspaceJob job, MultiRepoIndexRequest request) {
        try {
            job.update("RUNNING", "CLONING", 12, "Cloning repositories"); persist(job);
            job.update("RUNNING", "INDEXING", 36, "Chunking code, extracting symbols, and building per-repo graphs"); persist(job);
            WorkspaceResponse workspace = workspaceService.generate(request);
            job.workspace = workspace;
            job.workspaceId = workspace.id();
            job.update("READY", "READY", 100, "Workspace diagrams, repo summaries, and key contributors are ready"); persist(job);
        } catch (Exception e) {
            job.error = e.getMessage() == null ? e.toString() : e.getMessage();
            job.update("FAILED", "FAILED", 100, job.error); persist(job);
        }
    }

    private void persist(MutableWorkspaceJob job) {
        persistenceService.saveJob(job.jobId, "WORKSPACE", job.status, job.stage, job.progress, job.message, null, job.workspaceId, job.error, job.createdAt, job.updatedAt);
    }

    private static class MutableWorkspaceJob {
        final String jobId;
        final Instant createdAt = Instant.now();
        volatile Instant updatedAt = Instant.now();
        volatile String status = "QUEUED";
        volatile String stage = "QUEUED";
        volatile int progress = 5;
        volatile String message = "Queued";
        volatile String workspaceId;
        volatile WorkspaceResponse workspace;
        volatile String error;

        MutableWorkspaceJob(String jobId) { this.jobId = jobId; }
        void update(String status, String stage, int progress, String message) {
            this.status = status; this.stage = stage; this.progress = progress; this.message = message; this.updatedAt = Instant.now();
        }
        WorkspaceIndexJobStatus toStatus() { return new WorkspaceIndexJobStatus(jobId, status, stage, progress, message, workspaceId, workspace, error, createdAt, updatedAt); }
    }
}
