package com.ocbc.staff.orchestrator.service;

import com.ocbc.staff.orchestrator.domain.graph.GraphDefinition;
import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.NodeExecutionRecord;
import com.ocbc.staff.orchestrator.domain.runtime.NodeExecutionStatus;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowExecutionStatus;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import com.ocbc.staff.orchestrator.executor.NodeExecutor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class WorkflowEngine {

    private final NodeExecutorRegistry nodeExecutorRegistry;
    private final TransitionEvaluationService transitionEvaluationService;
    private final MappingResolverService mappingResolverService;

    public WorkflowEngine(NodeExecutorRegistry nodeExecutorRegistry,
                          TransitionEvaluationService transitionEvaluationService,
                          MappingResolverService mappingResolverService) {
        this.nodeExecutorRegistry = nodeExecutorRegistry;
        this.transitionEvaluationService = transitionEvaluationService;
        this.mappingResolverService = mappingResolverService;
    }

    public WorkflowState execute(GraphDefinition graph, WorkflowState state) {
        Map<String, GraphNodeDefinition> nodeIndex = graph.nodes().stream()
                .collect(Collectors.toMap(GraphNodeDefinition::id, Function.identity()));

        state.setStatus(WorkflowExecutionStatus.RUNNING);
        state.setCurrentNodeId(graph.entryNode());

        while (state.getCurrentNodeId() != null) {
            GraphNodeDefinition node = nodeIndex.get(state.getCurrentNodeId());
            if (node == null) {
                throw new IllegalStateException("Unknown node: " + state.getCurrentNodeId());
            }

            if (node.isEndNode()) {
                Map<String, Object> outputMapping = safeMap(node.config().get("outputMapping"));
                Map<String, Object> resolvedOutput = mappingResolverService.resolveMap(outputMapping, state);
                state.setFinalOutput(resolvedOutput);
                state.setStatus(WorkflowExecutionStatus.COMPLETED);
                state.setCompletedAt(Instant.now());
                return state;
            }

            Instant startedAt = Instant.now();
            String nextNode;
            Map<String, Object> output;

            try {
                NodeExecutor executor = nodeExecutorRegistry.require(node);
                Map<String, Object> inputPayload = extractInputPayload(node, state);
                output = executor.execute(node, state);
                if (node.outputKey() != null && !node.outputKey().isBlank()) {
                    state.putTaskResult(node.outputKey(), output);
                }
                nextNode = transitionEvaluationService.determineNext(node, state);

                NodeExecutionRecord record = new NodeExecutionRecord(
                        node.id(),
                        node.type(),
                        node.taskType(),
                        node.delegateTo(),
                        NodeExecutionStatus.SUCCESS,
                        inputPayload,
                        output,
                        nextNode,
                        null,
                        startedAt,
                        Instant.now(),
                        Instant.now().toEpochMilli() - startedAt.toEpochMilli()
                );
                state.addAudit(record);
            } catch (Exception ex) {
                state.addError(node.id(), ex.getMessage());
                nextNode = node.onError() != null ? node.onError().next() : null;

                if (node.onError() != null && node.onError().outputKey() != null) {
                    Map<String, Object> errorPayload = Map.of("message", ex.getMessage());
                    state.putTaskResult(node.onError().outputKey(), errorPayload);
                }

                NodeExecutionRecord record = new NodeExecutionRecord(
                        node.id(),
                        node.type(),
                        node.taskType(),
                        node.delegateTo(),
                        NodeExecutionStatus.FAILED,
                        extractInputPayload(node, state),
                        Map.of(),
                        nextNode,
                        ex.getMessage(),
                        startedAt,
                        Instant.now(),
                        Instant.now().toEpochMilli() - startedAt.toEpochMilli()
                );
                state.addAudit(record);

                if (nextNode == null) {
                    state.setStatus(WorkflowExecutionStatus.FAILED);
                    state.setCompletedAt(Instant.now());
                    return state;
                }
            }

            state.setCurrentNodeId(nextNode);
            state.setUpdatedAt(Instant.now());
        }

        state.setStatus(WorkflowExecutionStatus.FAILED);
        state.setCompletedAt(Instant.now());
        return state;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> extractInputPayload(GraphNodeDefinition node, WorkflowState state) {
        if (node.config() == null) {
            return Map.of();
        }
        Object inputMapping = node.config().get("inputMapping");
        if (inputMapping instanceof Map<?, ?> map) {
            return mappingResolverService.resolveMap((Map<String, Object>) map, state);
        }
        return new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> safeMap(Object value) {
        if (value instanceof Map<?, ?> map) {
            return (Map<String, Object>) map;
        }
        return new LinkedHashMap<>();
    }
}
