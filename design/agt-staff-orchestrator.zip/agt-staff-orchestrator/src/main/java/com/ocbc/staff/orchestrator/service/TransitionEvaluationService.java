package com.ocbc.staff.orchestrator.service;

import com.jayway.jsonpath.JsonPath;
import com.ocbc.staff.orchestrator.domain.graph.GraphNodeDefinition;
import com.ocbc.staff.orchestrator.domain.graph.TransitionDefinition;
import com.ocbc.staff.orchestrator.domain.runtime.WorkflowState;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Objects;

@Service
public class TransitionEvaluationService {

    public String determineNext(GraphNodeDefinition node, WorkflowState state) {
        if (node.transitions() == null || node.transitions().isEmpty()) {
            return null;
        }

        for (TransitionDefinition transition : node.transitions()) {
            if (matches(transition, state)) {
                return transition.next();
            }
        }
        throw new IllegalStateException("No transition matched for node: " + node.id());
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private boolean matches(TransitionDefinition transition, WorkflowState state) {
        String kind = transition.kind();
        if ("ALWAYS".equalsIgnoreCase(kind)) {
            return true;
        }
        if (!"STATE_VALUE".equalsIgnoreCase(kind)) {
            throw new IllegalArgumentException("Unsupported transition kind: " + kind);
        }

        Object actual;
        try {
            actual = JsonPath.read(state.asMap(), transition.path());
        } catch (Exception e) {
            actual = null;
        }

        String operator = transition.operator();
        Object expected = transition.value();

        return switch (operator) {
            case "EQ" -> Objects.equals(actual, expected);
            case "NE" -> !Objects.equals(actual, expected);
            case "IS_TRUE" -> Boolean.TRUE.equals(actual);
            case "IS_FALSE" -> Boolean.FALSE.equals(actual);
            case "EXISTS" -> actual != null;
            case "NOT_EXISTS" -> actual == null;
            case "GT" -> compare(actual, expected) > 0;
            case "GTE" -> compare(actual, expected) >= 0;
            case "LT" -> compare(actual, expected) < 0;
            case "LTE" -> compare(actual, expected) <= 0;
            case "SIZE_EQ" -> sizeOf(actual) == toInt(expected);
            case "SIZE_GT" -> sizeOf(actual) > toInt(expected);
            case "SIZE_GTE" -> sizeOf(actual) >= toInt(expected);
            default -> throw new IllegalArgumentException("Unsupported operator: " + operator);
        };
    }

    private int compare(Object actual, Object expected) {
        double left = toDouble(actual);
        double right = toDouble(expected);
        return Double.compare(left, right);
    }

    private double toDouble(Object value) {
        if (value == null) {
            return 0.0d;
        }
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        return Double.parseDouble(String.valueOf(value));
    }

    private int toInt(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private int sizeOf(Object actual) {
        if (actual == null) {
            return 0;
        }
        if (actual instanceof Collection<?> collection) {
            return collection.size();
        }
        if (actual.getClass().isArray()) {
            return java.lang.reflect.Array.getLength(actual);
        }
        return 0;
    }
}
