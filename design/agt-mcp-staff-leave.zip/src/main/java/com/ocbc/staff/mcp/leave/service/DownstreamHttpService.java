package com.ocbc.staff.mcp.leave.service;

import com.ocbc.staff.mcp.leave.config.StaffLeaveProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class DownstreamHttpService {
    private static final Logger log = LoggerFactory.getLogger(DownstreamHttpService.class);
    private final StaffLeaveProperties properties;

    public DownstreamHttpService(StaffLeaveProperties properties) {
        this.properties = properties;
    }

    public Map<String, Object> post(String url, Object payload) {
        log.info("[DOWNSTREAM_POST_REQUEST] url={} payload={}", url, payload);
        SimpleClientHttpRequestFactory rf = new SimpleClientHttpRequestFactory();
        rf.setConnectTimeout(properties.getTimeoutMs());
        rf.setReadTimeout(properties.getTimeoutMs());
        RestTemplate rt = new RestTemplate(rf);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity<Map> response = rt.exchange(url, HttpMethod.POST, new HttpEntity<>(payload, headers), Map.class);
        @SuppressWarnings("unchecked")
        Map<String, Object> body = response.getBody() == null ? new LinkedHashMap<>() : response.getBody();
        log.info("[DOWNSTREAM_POST_RESPONSE] url={} status={} payload={}", url, response.getStatusCode().value(), body);
        return body;
    }
}
