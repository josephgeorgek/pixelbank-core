package com.example.agtstaffintent;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class LlmIntentService {

    private final ChatClient chatClient;

    public LlmIntentService(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }

    public String extractIntent(String prompt) {
        return chatClient.prompt().user(prompt).call().content();
    }
}
