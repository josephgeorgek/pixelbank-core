package com.joseph.deepwiki.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "graph_nodes", indexes = @Index(name="idx_graph_nodes_wiki", columnList="wikiId"))
public class GraphNodeEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String wikiId;
    public String nodeId;
    public String label;
    public String nodeType;
    @Column(length = 2000) public String path;
    public String language;
    public String groupName;
    public long bytes;
    public int lineNumber;
    public String evidenceKind;
    public String confidence;
    public GraphNodeEntity() {}
}
