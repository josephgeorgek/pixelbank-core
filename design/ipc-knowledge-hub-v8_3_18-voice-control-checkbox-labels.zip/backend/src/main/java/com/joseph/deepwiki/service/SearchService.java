package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SearchService {
    public List<SearchHit> search(WikiResponse wiki, String query, int limit) {
        Set<String> terms = terms(query);
        return wiki.chunks().stream()
                .map(chunk -> toHit(chunk, terms))
                .filter(hit -> hit.score() > 0 || terms.isEmpty())
                .sorted(Comparator.comparingInt(SearchHit::score).reversed().thenComparing(SearchHit::path))
                .limit(limit <= 0 ? 10 : limit)
                .toList();
    }

    public List<CodeChunk> evidence(WikiResponse wiki, String query, int limit) {
        Set<String> terms = terms(query);
        return wiki.chunks().stream()
                .sorted(Comparator.comparingInt((CodeChunk chunk) -> score(chunk, terms)).reversed().thenComparing(CodeChunk::path))
                .limit(limit <= 0 ? 10 : limit)
                .toList();
    }

    private SearchHit toHit(CodeChunk chunk, Set<String> terms) {
        String preview = abbreviate(chunk.content().replace("\n", " "), 360);
        return new SearchHit(chunk.path(), chunk.language(), chunk.startLine(), chunk.endLine(), preview, score(chunk, terms), chunk.symbols());
    }

    private int score(CodeChunk chunk, Set<String> terms) {
        if (terms.isEmpty()) return chunk.path().toLowerCase(Locale.ROOT).contains("readme") ? 2 : 1;
        String haystack = (chunk.path() + "\n" + chunk.content() + "\n" + String.join(" ", chunk.symbols())).toLowerCase(Locale.ROOT);
        int score = 0;
        for (String term : terms) {
            if (chunk.path().toLowerCase(Locale.ROOT).contains(term)) score += 10;
            if (chunk.symbols().stream().anyMatch(s -> s.toLowerCase(Locale.ROOT).contains(term))) score += 8;
            if (haystack.contains(term)) score += 3;
        }
        return score;
    }

    private Set<String> terms(String query) {
        return Arrays.stream(Optional.ofNullable(query).orElse("").toLowerCase(Locale.ROOT).split("[^a-z0-9_]+"))
                .filter(s -> s.length() > 2)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private String abbreviate(String value, int max) {
        return value.length() <= max ? value : value.substring(0, max) + "…";
    }
}
