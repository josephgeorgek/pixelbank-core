package com.example.agtstaffintent.service;

import org.springframework.stereotype.Component;

@Component
public class PromptNormalizer {

    public String normalize(String input) {
        String value = input == null ? "" : input.toLowerCase();
        value = value.replaceAll("[^a-z0-9\s-]", " ");
        value = value.replaceAll("\bhip\b", " hip issue request ticket case ");
        value = value.replaceAll("\s+", " ").trim();
        return value;
    }
}
