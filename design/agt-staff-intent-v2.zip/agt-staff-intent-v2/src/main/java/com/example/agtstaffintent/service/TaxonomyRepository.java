package com.example.agtstaffintent.service;

import com.example.agtstaffintent.domain.IntentTaxonomy;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
public class TaxonomyRepository {

    private final ObjectMapper objectMapper;
    private List<IntentTaxonomy> taxonomies = List.of();

    public TaxonomyRepository(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    void init() throws IOException {
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources = resolver.getResources("classpath*:taxonomy/*.json");
        List<IntentTaxonomy> loaded = new ArrayList<>();
        for (Resource resource : resources) {
            try (InputStream inputStream = resource.getInputStream()) {
                loaded.add(objectMapper.readValue(inputStream, new TypeReference<>() {}));
            }
        }
        this.taxonomies = Collections.unmodifiableList(loaded);
    }

    public List<IntentTaxonomy> findAll() {
        return taxonomies;
    }

    public IntentTaxonomy requireByIntent(String intent) {
        return taxonomies.stream()
                .filter(taxonomy -> taxonomy.intent().equals(intent))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown taxonomy intent: " + intent));
    }
}
