package com.company.workforce.fulfilment.service.model;

import java.util.List;

public record IntentTaxonomyContext(
        String domain,
        List<String> globalRules,
        List<IntentDefinition> intents
) {
}
