# Live Docs Knowledge Hub v8.3.18

React + Spring Boot 3.5 / Java 21 / Spring AI project for DeepWiki-style repository understanding.

v8 shifts from single-repo wiki into a readability-first **multi-repo architecture workspace**.


## v8.3.18 landing UX polish

This patch is intentionally landing-page focused. Existing repository indexing, wiki generation, diagrams, search, chat, MCP bridge, H2 persistence, and backend APIs are retained.

Changes included:

- Bumped frontend version and browser cache namespace to `v8_3_18`.
- Revamped only the landing page UX to match the attached clean white SaaS reference.
- Added a more premium header, hero, search console, direct URL panel, mini-tab row, and indexed workspace card styling.
- Retained backend-persisted indexed workspace cards using existing `GET /api/workspaces`.
- Retained GitHub search with checkbox selection and result limit of 3.
- Retained direct single/multi-repo URL paste and indexing.
- Retained browser recent-workspace cache as a fallback section.
- Kept indexing, wiki generation, diagrams, chat, MCP bridge, H2 persistence, and backend APIs functionally unchanged.

## v8 features

- OpenAI text reasoning via Spring AI `ChatClient`
- Async workspace indexing
- Multiple repo URLs separated by comma, whitespace, or new lines
- Combined repository summary at the top
- Repository overview before diagrams
- Index stats before graph-heavy sections
- Interaction component diagram across repos
- Inferred sequence diagram
- Combined workspace component diagram
- Individual repo architecture diagrams
- PR reviewers section using GitHub API when available
- Commit highlights section using GitHub API when available
- Existing single-repo wiki/search/chat/MCP bridge retained

## Important truth

The diagrams are source-grounded but still inferred from static analysis. They are not runtime tracing. Validate critical flows with logs, traces, and architecture owners.

For PR reviewers and richer commit data, provide a GitHub PAT. Public GitHub API calls may work without a token but are rate-limited and may not include private repository data.

## Run

```bash
cp .env.example .env
# put your real OpenAI key into .env
docker compose down -v
docker compose up --build
```

Open:

```text
http://localhost:3000
```

## Environment

```env
OPENAI_API_KEY=sk-your-real-key
SPRING_AI_OPENAI_MODEL=gpt-4o-mini
DEEPWIKI_MAX_FILES=260
DEEPWIKI_MAX_FILE_BYTES=160000
DEEPWIKI_CLONE_TIMEOUT_SECONDS=180
```

## Multi-repo input examples

```text
https://github.com/org/repo-a, https://github.com/org/repo-b
```

or:

```text
https://github.com/org/repo-a
https://github.com/org/repo-b
https://github.com/org/repo-c
```

Leave Branch blank unless you know the branch name.

## New workspace APIs

```text
POST /api/workspaces/index
GET  /api/workspaces/jobs/{jobId}
GET  /api/workspaces/{workspaceId}
GET  /api/workspaces
POST /api/workspaces/generate
```

Existing single-repo APIs remain:

```text
POST /api/wiki/index
GET  /api/wiki/jobs/{jobId}
GET  /api/wiki/{wikiId}/search?query=payment&limit=10
POST /api/wiki/chat
```


## v8.2 patch notes

### DeepWiki-style reading layout
The UI was changed away from the dark modern dashboard style and back toward a readable DeepWiki-like document layout:
- light background
- top header
- left navigation rail
- centered reading column
- right "On this page" rail
- sections ordered for readability

### OpenAI logging
`AiWikiWriter` now logs every OpenAI call path:
- `OPENAI_REQUEST`
- `OPENAI_RESPONSE`
- `OPENAI_CALL_SKIPPED`
- `OPENAI_CALL_FAILED`

Each log includes:
- `callId`
- operation name
- configured model
- prompt character count
- estimated prompt tokens
- estimated response tokens
- estimated total tokens
- latency in milliseconds
- full prompt and response on a single line

Token counts are estimated using `ceil(characters / 4)` because the current Spring AI `ChatClient.call().content()` path does not expose provider usage metadata directly. Upgrade to metadata-aware `ChatResponse` extraction if exact provider usage is required.


## v8.3.4 Backend-generated AI Sections

This package adds H2 file persistence and evidence-gated diagram generation.

### Persistence

H2 runs in file mode and is mounted through Docker volume `ipc_h2_data`.

H2 Console:

```text
http://localhost:8080/h2-console
```

JDBC URL:

```text
jdbc:h2:file:/data/ipc-knowledge-hub
```

User: `sa`, password blank.

Persisted tables include workspaces, wikis, code files, chunks, symbols, graph nodes, graph edges, diagram artifacts, index jobs, and key contributors.

### Diagram truth policy

Diagrams are generated only from repository evidence. Unsupported diagrams render an `INSUFFICIENT_EVIDENCE` node instead of fake arrows.

### Key Contributors

Reviewer and commit details are not listed. Only up to five contributor names are shown.

### OpenAI logs

OpenAI calls are still logged to console only. OpenAI logs are not persisted in H2.


## v8.3.4 Fix

- AI documentation sections are generated during workspace indexing, not by frontend ad-hoc chat calls.
- Purpose and Scope, Dev 2 Dev Info, and Architecture are stored in the workspace response and persisted with H2.
- Removed the repeated Dev 2 Dev Info section.
- Changed browser cache namespace to avoid stale workspaces with missing AI-generated fields.
