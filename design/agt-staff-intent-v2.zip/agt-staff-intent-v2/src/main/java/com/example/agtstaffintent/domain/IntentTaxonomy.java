package com.example.agtstaffintent.domain;

import java.util.List;
import java.util.Map;

public record IntentTaxonomy(
        String intent,
        String description,
        String persona,
        List<String> synonyms,
        List<String> keywords,
        List<String> negativeKeywords,
        List<String> requiredKeywordsAny,
        Map<String, String> entityHints,
        List<String> rules,
        List<String> examples,
        List<ServiceCandidate> serviceCandidates
) {
}
