package com.example.agtstaffintent.domain;

import java.util.List;
import java.util.Map;

public record IntentResponse(
        String prompt,
        String userRole,
        String selectedIntent,
        Double confidence,
        String rationale,
        Map<String, Object> entities,
        List<ServiceCandidate> serviceCandidates,
        List<RankedIntentView> similarityTopK,
        List<RankedIntentView> shortlistedIntents
) {

    public record RankedIntentView(
            String intent,
            String persona,
            double similarityScore,
            List<String> matchedSignals,
            List<String> rejectedSignals,
            boolean shortlisted,
            List<ServiceCandidate> serviceCandidates
    ) {
    }
}
