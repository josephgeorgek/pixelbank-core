package com.ocbc.staff.mcp.leave.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ocbc.staff.mcp.leave.model.ToolModels.*;
import com.ocbc.staff.mcp.leave.service.StaffLeaveToolService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/mcp")
public class McpController {
    private final StaffLeaveToolService toolService;
    private final ObjectMapper objectMapper;

    public McpController(StaffLeaveToolService toolService, ObjectMapper objectMapper) {
        this.toolService = toolService;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/tools")
    public List<ToolDescriptor> tools() {
        return List.of(
            new ToolDescriptor("list_pending_medical_leaves",
                "List pending medical leave applications for a manager. Handles inquiry/listing and returns normalized leave rows.",
                Map.of("managerId","string","status","string","certificateRequired","boolean","fetchAll","boolean","maxRecords","integer")),
            new ToolDescriptor("get_medical_leave_documents",
                "Fetch document metadata for leave cases.",
                Map.of("leaveIds","array<string>")),
            new ToolDescriptor("approve_medical_leaves",
                "Approve one or more medical leave applications. Can filter to only match=true records.",
                Map.of("approverId","string","approvalMode","string","leaveApplications","array<object>"))
        );
    }

    @PostMapping("/tools/execute")
    public ToolExecuteResponse execute(@Valid @RequestBody ToolExecuteRequest request) {
        ToolExecuteResponse response = new ToolExecuteResponse();
        response.setServerName("agt-mcp-staff-leave");
        response.setToolName(request.getToolName());
        response.setExecutedAt(Instant.now());
        try {
            Object result = switch (request.getToolName()) {
                case "list_pending_medical_leaves" -> toolService.listPendingMedicalLeaves(
                    objectMapper.convertValue(request.getArguments(), ListPendingMedicalLeavesArgs.class));
                case "get_medical_leave_documents" -> toolService.getMedicalLeaveDocuments(
                    objectMapper.convertValue(request.getArguments(), GetMedicalLeaveDocumentsArgs.class));
                case "approve_medical_leaves" -> toolService.approveMedicalLeaves(
                    objectMapper.convertValue(request.getArguments(), ApproveMedicalLeavesArgs.class));
                default -> throw new IllegalArgumentException("Unsupported toolName: " + request.getToolName());
            };
            response.setSuccess(true);
            response.setResult(result);
            return response;
        } catch (Exception ex) {
            response.setSuccess(false);
            response.setError(ex.getMessage());
            return response;
        }
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, Object> bad(IllegalArgumentException ex) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("status", 400);
        out.put("error", "Bad Request");
        out.put("message", ex.getMessage());
        out.put("timestamp", Instant.now().toString());
        return out;
    }
}
