package com.ocbc.staff.orchestrator.model;

public enum NodeStatus {
    PENDING, RUNNING, COMPLETED, FAILED, SKIPPED
}
